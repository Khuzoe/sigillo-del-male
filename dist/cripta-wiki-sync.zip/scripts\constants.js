export const MODULE_ID = "cripta-wiki-sync";
export const MODULE_TITLE = "Cripta Wiki Sync";
export const DEFAULT_SITE_BASE_URL = "https://khuzoe.github.io/sigillo-del-male";
export const DISCORD_WORKER_URL = "https://sigillo-api.khuzoe.workers.dev";
export const DEFAULT_CAMPAIGN_ID = "cripta-di-sangue";
export const DEFAULT_AUTO_DEVICE_LOGIN_CODES = [
    "dm | DM-9KQ4-W7HP",
    "gm | DM-9KQ4-W7HP",
    "gamemaster | DM-9KQ4-W7HP",
    "garun | GARUN-LNHU-JS9D",
    "ga run | GARUN-LNHU-JS9D",
    "randra | RANDRA-FY5H-7EZ4",
    "ran dra | RANDRA-FY5H-7EZ4",
    "valdor | VALDOR-HEHH-RG96",
    "theldarion | THELDARI-F9NP-RWXR"
].join("\n");

export const SETTINGS = {
    SITE_BASE_URL: "siteBaseUrl",
    CAMPAIGN_ID: "campaignId",
    SHARED_NOTES: "sharedNotes",
    DRAFTS: "draftEntries",
    PERSONAL_NOTES: "personalNotes",
    DISCORD_TOKEN: "discordToken",
    DISCORD_USER: "discordUser",
    AUTO_DEVICE_LOGIN_CODES: "autoDeviceLoginCodes",
    INVENTORY_SYNC_SECRET: "inventorySyncSecret",
    AUTO_CHARACTER_SYNC: "autoCharacterSync",
    PLAYER_ACTOR_MAPPINGS: "playerActorMappings",
    COMPANION_MAPPINGS: "companionMappings"
};

export const MENUS = {
    AUTO_DEVICE_LOGIN: "autoDeviceLoginMenu",
    COMPANION_MAPPINGS: "companionMappingsMenu"
};

export const FLAGS = {
    LINK: "wikiLink"
};

export const SECTIONS = {
    HOME: "home",
    SESSIONS: "sessions",
    CHARACTERS: "characters",
    PLAYERS: "players",
    ITEMS: "items",
    BESTIARY: "bestiary"
};
