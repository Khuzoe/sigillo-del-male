import { DEFAULT_AUTO_DEVICE_LOGIN_CODES, DEFAULT_CAMPAIGN_ID, DISCORD_WORKER_URL, FLAGS, MENUS, MODULE_ID, MODULE_TITLE, SECTIONS, SETTINGS } from "./constants.js";
import { wikiStore } from "./services/wiki-store.js";
import { wikiDataService } from "./services/wiki-data-service.js";
import { CriptaWikiBrowserApp } from "./apps/wiki-browser-app.js";
import { CriptaWikiEntityApp } from "./apps/wiki-entity-app.js";
import { CriptaWikiSkillTreeApp } from "./apps/wiki-skill-tree-app.js";

const quickNoteDraftCache = new Map();
let characterSyncTimer = null;
let suppressCharacterSync = false;
const regenerationTurnKeys = new Set();
const TOKEN_SWITCHER_MODULE_ID = "khuzoe-token-switcher";
const TOKEN_SWITCHER_IMAGES_FLAG = "images";
const TOKEN_SWITCHER_SYNCED_PATHS_FLAG = "tokenSwitcherSyncedPaths";
const MANAGED_MEDIA_FLAG = "managedMedia";
const LOCAL_MEDIA_ROOT = "cripta-wiki-sync";
const MODULE_UPDATE_MANIFEST_URL = "https://khuzoe.github.io/sigillo-del-male/dist/module.json";
const MEDIA_EXISTS_CACHE_TTL = 60_000;
const LOCAL_FILE_EXISTS_CACHE_TTL = 10 * 60_000;
const MANAGED_MEDIA_NETWORK_LIMIT = 4;
const MANAGED_MEDIA_BOOTSTRAP_LIMIT = 3;
const ABILITY_ICON_SYNC_SIZE = 256;
const CHARACTER_IMAGE_SYNC_SIZE = 512;
let managedMediaNetworkActive = 0;
const managedMediaNetworkQueue = [];
const mediaExistsCache = new Map();
const mediaExistsPromises = new Map();
const localFileExistsCache = new Map();
const localDirectoryCache = new Map();
const ensuredFoundryDirectories = new Set();
const transformationOverrideCache = {
    loadedAt: 0,
    promise: null,
    data: []
};
const WIKI_DAMAGE_TYPE_LABELS = {
    acid: "Acido",
    bludgeoning: "Contundente",
    cold: "Freddo",
    fire: "Fuoco",
    force: "Forza",
    lightning: "Fulmine",
    necrotic: "Necrotico",
    piercing: "Perforante",
    poison: "Veleno",
    psychic: "Psichico",
    radiant: "Radiante",
    slashing: "Tagliente",
    thunder: "Tuono"
};
const WIKI_PLAYER_ID_ALIASES = {
    garun: ["garun", "ga run", "ga'run", "luca"],
    randra: ["randra", "ran dra", "ran'dra", "eli"],
    valdor: ["valdor", "sommo"],
    theldarion: ["theldarion", "theldarion tessaryn", "theldari", "dona"],
    apothecary: ["apothecary"]
};
const skillTreesCache = {
    loadedAt: 0,
    promise: null,
    data: null
};
const skillTreeStatesCache = {
    loadedAt: 0,
    promise: null,
    data: null
};
let skillTreeAbilitySyncTimer = null;

function registerSettings() {
    game.settings.registerMenu(MODULE_ID, MENUS.AUTO_DEVICE_LOGIN, {
        name: "Login automatico utenti",
        label: "Configura codici",
        hint: "Assegna un codice accesso a ogni utente Foundry della campagna.",
        icon: "fas fa-user",
        type: AutoDeviceLoginConfigApp,
        restricted: true
    });

    game.settings.registerMenu(MODULE_ID, MENUS.COMPANION_MAPPINGS, {
        name: "Actor personaggi e companion",
        label: "Configura actor",
        hint: "Assegna gli Actor ID dei personaggi e dei companion agli utenti Foundry. Se i personaggi sono configurati, la sync esporta solo quelli.",
        icon: "fas fa-paw",
        type: CompanionMappingsConfigApp,
        restricted: true
    });

    game.settings.register(MODULE_ID, SETTINGS.SITE_BASE_URL, {
        name: "URL base della wiki",
        hint: "Origine usata per leggere dati e CSS della wiki pubblicata.",
        scope: "world",
        config: true,
        restricted: true,
        type: String,
        default: "https://khuzoe.github.io/sigillo-del-male",
        onChange: () => wikiDataService.invalidate()
    });

    game.settings.register(MODULE_ID, SETTINGS.CAMPAIGN_ID, {
        name: "Campagna wiki",
        hint: "Identificativo campagna usato per dati, appunti, sondaggi e sync personaggi.",
        scope: "world",
        config: true,
        restricted: true,
        type: String,
        default: DEFAULT_CAMPAIGN_ID,
        onChange: () => wikiDataService.invalidate()
    });

    game.settings.register(MODULE_ID, SETTINGS.SHARED_NOTES, {
        name: "Archivio appunti condivisi",
        scope: "world",
        config: false,
        type: Object,
        default: {}
    });

    game.settings.register(MODULE_ID, SETTINGS.DRAFTS, {
        name: "Bozze generate da Foundry",
        scope: "world",
        config: false,
        type: Object,
        default: {
            entries: {}
        }
    });

    game.settings.register(MODULE_ID, SETTINGS.PERSONAL_NOTES, {
        name: "Appunti personali utente",
        scope: "client",
        config: false,
        type: Object,
        default: {}
    });

    game.settings.register(MODULE_ID, SETTINGS.DISCORD_TOKEN, {
        name: "Token accesso wiki",
        scope: "client",
        config: false,
        type: String,
        default: ""
    });

    game.settings.register(MODULE_ID, SETTINGS.DISCORD_USER, {
        name: "Utente wiki autenticato",
        scope: "client",
        config: false,
        type: Object,
        default: {}
    });

    game.settings.register(MODULE_ID, SETTINGS.AUTO_DEVICE_LOGIN_CODES, {
        name: "Mappa login automatico con codice",
        hint: "Dato interno configurato dal menu Login automatico utenti.",
        scope: "world",
        config: false,
        restricted: true,
        type: String,
        default: DEFAULT_AUTO_DEVICE_LOGIN_CODES
    });

    game.settings.register(MODULE_ID, SETTINGS.AUTO_CHARACTER_SYNC, {
        name: "Sincronizza personaggi automaticamente",
        hint: "Il GM attivo invia al worker una snapshot dei personaggi giocanti all'avvio e quando cambiano actor/oggetti.",
        scope: "world",
        config: true,
        restricted: true,
        type: Boolean,
        default: false
    });

    game.settings.register(MODULE_ID, SETTINGS.INVENTORY_SYNC_SECRET, {
        name: "Secret sync personaggi",
        hint: "Opzionale. Se il Worker ha INVENTORY_SYNC_SECRET, inserisci qui lo stesso valore per autorizzare il POST.",
        scope: "world",
        config: true,
        restricted: true,
        type: String,
        default: ""
    });

    game.settings.register(MODULE_ID, SETTINGS.COMPANION_MAPPINGS, {
        name: "Mappatura companion",
        hint: "Dato interno configurato dal menu Companion personaggi.",
        scope: "world",
        config: false,
        restricted: true,
        type: String,
        default: ""
    });

    game.settings.register(MODULE_ID, SETTINGS.PLAYER_ACTOR_MAPPINGS, {
        name: "Mappatura actor personaggi",
        hint: "Dato interno configurato dal menu Actor personaggi e companion.",
        scope: "world",
        config: false,
        restricted: true,
        type: String,
        default: ""
    });
}

class AutoDeviceLoginConfigApp extends FormApplication {
    static get defaultOptions() {
        return foundry.utils.mergeObject(super.defaultOptions, {
            id: "cripta-auto-device-login-config",
            title: "Login automatico utenti",
            template: `modules/${MODULE_ID}/templates/auto-device-login-config.hbs`,
            width: 620,
            height: "auto",
            closeOnSubmit: true
        });
    }

    getData() {
        const configured = parseAutoDeviceLoginConfig();
        const users = game.users
            .map((user) => ({
                id: user.id,
                name: user.name,
                code: configured.get(user.id) || configured.get(user.name) || ""
            }))
            .sort((left, right) => left.name.localeCompare(right.name, "it"));

        return { users };
    }

    async _updateObject(_event, formData) {
        const rows = game.users
            .map((user) => {
                const code = String(formData[`code.${user.id}`] || "").trim();
                return code ? `${user.id} | ${code}` : "";
            })
            .filter(Boolean);

        await game.settings.set(MODULE_ID, SETTINGS.AUTO_DEVICE_LOGIN_CODES, rows.join("\n"));
        ui.notifications.info("Codici login automatico aggiornati.");
    }
}

class CompanionMappingsConfigApp extends FormApplication {
    static get defaultOptions() {
        return foundry.utils.mergeObject(super.defaultOptions, {
            id: "cripta-companion-mappings-config",
            title: "Actor personaggi e companion",
            template: `modules/${MODULE_ID}/templates/companion-mappings-config.hbs`,
            width: 860,
            height: "auto",
            closeOnSubmit: true
        });
    }

    async getData() {
        const mappings = parseCompanionMappings();
        const playerMappings = parsePlayerActorMappings();
        const campaignPlayers = await loadCampaignPlayersForMappingConfig();
        const users = game.users
            .map((user) => {
                const accountId = getConfiguredAccountIdForUser(user, playerMappings);
                const mappedPlayer = getConfiguredPlayerMappingForUser(user, playerMappings);
                const suggestedPlayer = findCampaignPlayerForAccount(campaignPlayers, mappedPlayer?.ownerCharacterId, accountId);
                return {
                    id: user.id,
                    name: user.name,
                    isGM: user.isGM,
                    accountId,
                    characterId: mappedPlayer?.ownerCharacterId || suggestedPlayer?.id || "",
                    characterName: suggestedPlayer?.name || "",
                    actor: mappedPlayer?.actorRef || "",
                    companions: getConfiguredCompanionActorRefsForUser(user, mappings).join(", ")
                };
            })
            .sort((left, right) => {
                if (left.isGM !== right.isGM) return left.isGM ? 1 : -1;
                return left.name.localeCompare(right.name, "it");
            });

        return { users, campaignPlayers };
    }

    async _updateObject(_event, formData) {
        const rows = game.users
            .map((user) => {
                const accountId = String(formData[`account.${user.id}`] || "").trim();
                const characterId = slugify(formData[`character.${user.id}`] || "");
                const actorRef = normalizeActorRef(formData[`actor.${user.id}`] || "");
                const companionActorIds = String(formData[`companions.${user.id}`] || "")
                    .split(/[,;]/)
                    .map(normalizeActorRef)
                    .filter(Boolean);
                return compactObject({
                    userId: user.id,
                    userName: user.name,
                    accountId,
                    characterId,
                    actorId: actorRef,
                    companionActorIds
                });
            })
            .filter((row) => row.accountId || row.characterId || row.actorId || row.companionActorIds?.length);
        const playerRows = rows
            .filter((row) => row.characterId && row.actorId)
            .map((row) => ({
                userId: row.userId,
                userName: row.userName,
                accountId: row.accountId,
                characterId: row.characterId,
                actorId: row.actorId
            }));
        const companionRows = rows
            .filter((row) => row.characterId && row.companionActorIds?.length)
            .map((row) => ({
                userId: row.userId,
                userName: row.userName,
                accountId: row.accountId,
                characterId: row.characterId,
                companionActorIds: row.companionActorIds
            })
        );

        await game.settings.set(MODULE_ID, SETTINGS.PLAYER_ACTOR_MAPPINGS, JSON.stringify({
            version: 2,
            campaignId: getCampaignId(),
            rows: playerRows
        }));
        await game.settings.set(MODULE_ID, SETTINGS.COMPANION_MAPPINGS, JSON.stringify({
            version: 2,
            campaignId: getCampaignId(),
            rows: companionRows
        }));
        ui.notifications.info("Mappatura actor aggiornata.");
        scheduleCharacterSync("actorMappings");
    }
}

function openWikiBrowser(section) {
    return new CriptaWikiBrowserApp({ section }).render(true);
}

function resolveDocumentFromToken(tokenLike) {
    if (!tokenLike) return null;
    if (tokenLike.document) return tokenLike.document;
    return tokenLike;
}

function openWikiForDocument(document) {
    return new CriptaWikiEntityApp({ document }).render(true);
}

function escapeHtml(value) {
    return String(value || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function slugify(value) {
    return String(value || "")
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "") || "entity";
}

function normalizeWikiItemKey(value) {
    return String(value || "")
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/[^a-z0-9]+/g, "");
}

function getOpenWikiWindows() {
    return Object.values(ui.windows).filter((windowApp) =>
        windowApp instanceof CriptaWikiBrowserApp
        || windowApp instanceof CriptaWikiEntityApp
        || windowApp instanceof CriptaWikiSkillTreeApp
    );
}

function propagateAuthToken(token, user = null) {
    game.settings.set(MODULE_ID, SETTINGS.DISCORD_TOKEN, String(token || "")).catch(() => {});
    if (user) {
        game.settings.set(MODULE_ID, SETTINGS.DISCORD_USER, user).catch(() => {});
    }
    getOpenWikiWindows().forEach((windowApp) => {
        if (typeof windowApp.sendAuthToken === "function") {
            windowApp.sendAuthToken(token);
        }
    });
}

async function getValidAuthSession() {
    const token = String(game.settings.get(MODULE_ID, SETTINGS.DISCORD_TOKEN) || "").trim();
    if (!token) return null;

    try {
        const response = await fetch(withCampaign(`${DISCORD_WORKER_URL}/auth/discord/verify`), {
            method: "GET",
            headers: { Authorization: `Bearer ${token}` }
        });
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const data = await response.json();
        if (!data?.user) {
            throw new Error("Token non valido");
        }

        game.settings.set(MODULE_ID, SETTINGS.DISCORD_USER, data.user).catch(() => {});
        return data;
    } catch (_) {
        game.settings.set(MODULE_ID, SETTINGS.DISCORD_TOKEN, "").catch(() => {});
        game.settings.set(MODULE_ID, SETTINGS.DISCORD_USER, {}).catch(() => {});
        return null;
    }
}

function promptDeviceLogin() {
    new Dialog({
        title: "Login wiki",
        content: `
            <p>Accedi con il codice personale per usare gli appunti della wiki dentro Foundry.</p>
        `,
        buttons: {
            code: {
                icon: '<i class="fas fa-user"></i>',
                label: "Usa codice",
                callback: () => promptDeviceCodeLogin()
            },
            later: {
                icon: '<i class="fas fa-clock"></i>',
                label: "Piu tardi"
            }
        },
        default: "code"
    }).render(true);
}

function promptDeviceCodeLogin() {
    new Dialog({
        title: "Codice accesso",
        content: `
            <form>
                <div class="form-group">
                    <label>Codice personale</label>
                    <input type="text" name="deviceCode" autocomplete="off" placeholder="GARUN-X7K9-Q2M4">
                </div>
            </form>
        `,
        buttons: {
            login: {
                icon: '<i class="fas fa-user"></i>',
                label: "Accedi",
                callback: (html) => {
                    const code = html.find?.("[name='deviceCode']").val?.() || "";
                    loginWithDeviceCode(code).catch((error) => {
                        ui.notifications.error(error?.message || String(error || "Login non riuscito."));
                    });
                }
            },
            cancel: {
                icon: '<i class="fas fa-xmark"></i>',
                label: "Annulla"
            }
        },
        default: "login"
    }).render(true);
}

async function loginWithDeviceCode(code) {
    const cleanCode = String(code || "").trim();
    if (!cleanCode) {
        throw new Error("Inserisci un codice accesso.");
    }

    const response = await fetch(withCampaign(`${DISCORD_WORKER_URL}/auth/device/login`), {
        method: "POST",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ code: cleanCode, campaignId: getCampaignId() })
    });
    const data = await response.json().catch(() => null);
    if (!response.ok || !data?.token) {
        throw new Error(data?.error || `HTTP ${response.status}`);
    }

    propagateAuthToken(data.token, data.user || null);
    ui.notifications.info("Login con codice completato.");
}

function toNumberOrNull(value) {
    if (value === null || value === undefined || value === "") return null;
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
}

function toNumberFromValueOrObject(value) {
    if (value && typeof value === "object") {
        return toNumberOrNull(value.value ?? value.total ?? value.flat);
    }
    return toNumberOrNull(value);
}

function toLeadingNumberOrNull(value) {
    const match = String(value || "").trim().match(/^-?\d+(?:[.,]\d+)?/);
    if (!match) return null;
    const number = Number(match[0].replace(",", "."));
    return Number.isFinite(number) ? number : null;
}

function getPlainItemSystem(item) {
    return item?.toObject?.(false)?.system ?? item?.toObject?.()?.system ?? item?.system ?? {};
}

function getPrimaryActivityData(system) {
    const activities = system?.activities;
    if (!activities) return null;
    if (activities instanceof Map) return activities.values().next().value || null;
    if (Array.isArray(activities)) return activities[0] || null;
    if (typeof activities === "object") return Object.values(activities)[0] || null;
    return null;
}

function getActivityActivationData(system) {
    const activity = getPrimaryActivityData(system);
    return compactObject({
        type: activity?.activation?.type ?? system?.activation?.type,
        value: activity?.activation?.value ?? system?.activation?.value
    });
}

function getActivityRangeData(system) {
    const activity = getPrimaryActivityData(system);
    return compactObject({
        value: activity?.range?.value ?? system?.range?.value,
        units: activity?.range?.units ?? system?.range?.units
    });
}

function getActivityDurationData(system) {
    const activity = getPrimaryActivityData(system);
    return compactObject({
        value: activity?.duration?.value ?? system?.duration?.value,
        units: activity?.duration?.units ?? system?.duration?.units
    });
}

function compactObject(obj, options = {}) {
    const keepNullKeys = Array.isArray(options.keepNullKeys) ? options.keepNullKeys : [];
    return Object.fromEntries(Object.entries(obj).filter(([key, value]) => {
        if (value === undefined) return false;
        if (value === null) return keepNullKeys.includes(key);
        if (typeof value === "string") return value.trim() !== "";
        if (Array.isArray(value)) return value.length > 0;
        if (typeof value === "object") return Object.keys(value).length > 0;
        return true;
    }));
}

const CHARACTER_SYNC_ITEM_TYPES = new Set(["equipment", "weapon", "armor", "consumable", "tool", "loot", "backpack", "container", "feat"]);
const COMPANION_SYNC_ITEM_TYPES = new Set([...CHARACTER_SYNC_ITEM_TYPES, "feat"]);
const CHARACTER_SYNC_SPELL_MODES = new Set(["always", "atwill", "innate", "pact", "prepared"]);
const CHARACTER_SYNC_DESCRIPTION_LIMIT = 2400;
const ITEM_LOADOUT_ROLE_FLAG = "loadoutRole";
const ITEM_LOADOUT_SUBTYPE_FLAG = "loadoutSubtype";
const ITEM_LOADOUT_ROLE_OPTIONS = new Set(["inventory", "ability"]);
const ITEM_LOADOUT_SUBTYPE_OPTIONS = new Set(["attack"]);

function cleanFoundryDescription(value, maxLength = CHARACTER_SYNC_DESCRIPTION_LIMIT) {
    if (!value) return "";
    const cleaned = String(value)
        .replace(/\s(?:class|style|data-[\w-]+)="[^"]*"/gi, "")
        .replace(/\s(?:class|style|data-[\w-]+)='[^']*'/gi, "")
        .replace(/<script[\s\S]*?<\/script>/gi, "")
        .replace(/<style[\s\S]*?<\/style>/gi, "")
        .replace(/\s{2,}/g, " ")
        .trim();
    if (cleaned.length <= maxLength) return cleaned;
    return `${cleaned.slice(0, maxLength).trim()}...`;
}

function isUsefulSpell(item) {
    const system = item?.system ?? {};
    const level = toNumberOrNull(system.level);
    const preparation = system.preparation ?? {};
    if (preparation.prepared === true) return true;
    if (level === 0) return true;
    return CHARACTER_SYNC_SPELL_MODES.has(String(preparation.mode || "").toLowerCase());
}

function isUsefulCharacterItem(item) {
    if (!item) return false;
    if (item.type === "spell") return isUsefulSpell(item);
    return CHARACTER_SYNC_ITEM_TYPES.has(item.type);
}

function isUsefulCompanionItem(item) {
    if (!item) return false;
    if (item.type === "spell") return isUsefulSpell(item);
    return COMPANION_SYNC_ITEM_TYPES.has(item.type);
}

function getItemQuantity(item) {
    return item?.system?.quantity ?? item?.system?.qty ?? item?.system?.amount ?? 1;
}

function getItemDocumentId(item) {
    return item?.id || item?._id || item?.document?._id || "";
}

function getItemContainer(item) {
    const raw = item?.system?.container;
    if (raw === null || raw === undefined || raw === "") return null;
    if (typeof raw === "string") {
        const containerItem = item?.actor?.items?.get?.(raw);
        return compactObject({ id: raw, name: containerItem?.name }, { keepNullKeys: ["id"] });
    }
    if (typeof raw === "object") {
        return compactObject({ id: raw.id ?? raw.value ?? raw.uuid ?? null, name: raw.name }, { keepNullKeys: ["id"] });
    }
    return null;
}

function isItemAttuned(item) {
    return item?.system?.attuned === true;
}

function mapStatusItem(item) {
    return compactObject({
        id: item.id,
        name: item.name,
        type: item.type,
        quantity: getItemQuantity(item),
        container: getItemContainer(item),
        equipped: item?.system?.equipped,
        attuned: item?.system?.attuned,
        attunement: item?.system?.attunement
    }, { keepNullKeys: ["container"] });
}

function getItemProgress(item) {
    const raw = item?.getFlag?.(MODULE_ID, "progress")
        || item?.getFlag?.(MODULE_ID, "itemProgress")
        || item?.system?.progress;
    if (!raw || typeof raw !== "object") return null;
    const done = toNumberOrNull(raw.done ?? raw.value ?? raw.current ?? raw.completed);
    const total = toNumberOrNull(raw.total ?? raw.max ?? raw.target ?? raw.required);
    if (done === null || total === null || total <= 0) return null;
    const materials = normalizeItemProgressMaterials(raw.materials || raw.requiredMaterials || raw.requirements || raw.components);
    return compactObject({
        label: raw.label || "Progresso",
        done,
        total,
        unit: raw.unit || "",
        crafting: Boolean(raw.crafting || raw.isCrafting || materials.length),
        materials
    });
}

function normalizeItemProgressMaterials(materials) {
    const list = Array.isArray(materials)
        ? materials
        : Array.isArray(materials?.items)
            ? materials.items
            : [];
    return list.map((material) => {
        if (typeof material === "string") {
            const name = material.trim();
            return name ? { name, done: 0, required: 1, unit: "" } : null;
        }
        if (!material || typeof material !== "object") return null;
        const name = String(material.name || material.label || material.itemName || material.id || "").trim();
        const done = toNumberOrNull(material.done ?? material.value ?? material.current ?? material.available ?? material.owned) ?? 0;
        const required = toNumberOrNull(material.required ?? material.total ?? material.quantity ?? material.max ?? material.target) ?? 0;
        if (!name && required <= 0) return null;
        return compactObject({
            id: String(material.id || material.itemId || "").trim(),
            name: name || String(material.id || material.itemId || "Materiale").trim(),
            done: Math.max(0, done),
            required: Math.max(0, required),
            unit: String(material.unit || "").trim()
        });
    }).filter(Boolean);
}

function normalizeItemProgressDraft(raw) {
    if (!raw || typeof raw !== "object") return null;
    const done = toNumberOrNull(raw.done ?? raw.value ?? raw.current ?? raw.completed);
    const total = toNumberOrNull(raw.total ?? raw.max ?? raw.target ?? raw.required);
    if (done === null || total === null || total <= 0) return null;
    const materials = normalizeItemProgressMaterials(raw.materials || raw.requiredMaterials || raw.requirements || raw.components);
    return compactObject({
        label: String(raw.label || raw.unit || "Progresso").trim() || "Progresso",
        done: Math.max(0, done),
        total: Math.max(1, total),
        unit: String(raw.unit || "").trim(),
        crafting: Boolean(raw.crafting || raw.isCrafting || materials.length),
        materials
    });
}

function formatProgressNumber(value) {
    const number = toNumberOrNull(value);
    if (number === null) return "0";
    if (Number.isInteger(number)) return String(number);
    return String(Math.round(number * 100) / 100).replace(".", ",");
}

function renderItemProgressBar(progress) {
    const done = Math.max(0, toNumberOrNull(progress?.done) ?? 0);
    const total = Math.max(1, toNumberOrNull(progress?.total) ?? 1);
    const percent = Math.max(0, Math.min(100, (done / total) * 100));
    const label = `${formatProgressNumber(done)} / ${formatProgressNumber(total)}${progress?.unit ? ` ${escapeHtml(progress.unit)}` : ""}`;
    return `
        <div class="cripta-inventory-progress" title="${escapeHtml(progress?.label || "Progresso")}: ${escapeHtml(label)}">
            <div class="cripta-inventory-progress__fill" style="width: ${percent}%;"></div>
            <span>${escapeHtml(label)}</span>
        </div>
    `;
}

function findActorSheetItemRowNameTarget(row) {
    return row.querySelector(".item-name")
        || row.querySelector(".name")
        || row.querySelector(".item-title")
        || row.querySelector("[data-item-name]")
        || row;
}

function injectItemProgressBarsInActorSheet(app, html) {
    const actor = app?.actor || app?.document;
    if (!actor?.items) return;
    const root = html instanceof HTMLElement ? html : html?.[0];
    if (!root) return;

    root.querySelectorAll("[data-item-id]").forEach((row) => {
        if (row.querySelector(".cripta-inventory-progress")) return;
        const itemId = row.dataset.itemId || row.getAttribute("data-item-id");
        if (!itemId) return;
        const item = actor.items.get?.(itemId) || actor.items.find?.((entry) => entry.id === itemId);
        const progress = getItemProgress(item);
        if (!progress) return;
        const target = findActorSheetItemRowNameTarget(row);
        target.insertAdjacentHTML("beforeend", renderItemProgressBar(progress));
        row.classList.add("cripta-has-inventory-progress");
    });
}

function mapItemForCharacterSync(item, allItems = []) {
    const system = getPlainItemSystem(item);
    const loadoutRole = getItemLoadoutRole(item);
    const loadoutSubtype = getItemLoadoutSubtype(item);
    const itemId = getItemDocumentId(item);
    const transferId = getItemTransferId(item);
    const sourceId = getItemStableSourceId(item);
    const transferKey = getTransferableItemKey({ itemId, itemName: item.name, itemType: item.type, sourceId, transferId });
    const summary = compactObject({
        id: itemId,
        uuid: item.uuid || "",
        transferId,
        sourceId,
        transferKey,
        name: item.name,
        type: item.type,
        loadoutRole,
        loadoutSubtype,
        img: item.img,
        quantity: getItemQuantity(item),
        container: getItemContainer(item),
        currency: getItemCurrency(item),
        capacity: getItemCapacity(item, allItems),
        progress: getItemProgress(item),
        description: cleanFoundryDescription(system?.description?.value)
    }, { keepNullKeys: ["container"] });

    if (item.type === "spell") {
        return compactObject({
            ...summary,
            level: system.level,
            school: system.school,
            activation: getActivityActivationData(system),
            range: getActivityRangeData(system),
            duration: getActivityDurationData(system),
            prepared: system?.preparation?.prepared,
            concentration: Array.isArray(system?.properties) ? system.properties.includes("concentration") : false
        });
    }

    if (["equipment", "weapon", "armor", "consumable", "tool", "loot", "backpack"].includes(item.type)) {
        return compactObject({
            ...summary,
            rarity: system.rarity,
            identified: system.identified,
            equipped: system.equipped,
            attuned: system.attuned,
            attunement: system.attunement,
            activation: getActivityActivationData(system),
            range: getActivityRangeData(system),
            duration: getActivityDurationData(system),
            uses: compactObject({ max: system?.uses?.max, spent: system?.uses?.spent, value: system?.uses?.value })
        });
    }

    if (item.type === "feat") {
        return compactObject({
            ...summary,
            activation: getActivityActivationData(system),
            range: getActivityRangeData(system),
            duration: getActivityDurationData(system),
            uses: compactObject({ max: system?.uses?.max, spent: system?.uses?.spent, value: system?.uses?.value })
        });
    }

    return summary;
}

function getActorXp(actor) {
    const xp = actor?.system?.details?.xp ?? {};
    const current = toNumberOrNull(xp.value ?? xp.current);
    const nextLevel = toNumberOrNull(xp.max ?? xp.next);
    return compactObject({
        current,
        nextLevel,
        missingToLevel: current !== null && nextLevel !== null ? Math.max(nextLevel - current, 0) : null
    }, { keepNullKeys: ["current", "nextLevel", "missingToLevel"] });
}

function getActorSpellSlots(actor) {
    const spells = actor?.system?.spells ?? {};
    const perLevel = Object.entries(spells)
        .filter(([key]) => key === "pact" || /^spell\d+$/.test(key))
        .map(([key, slotData]) => {
            const total = toNumberOrNull(slotData?.max);
            const available = toNumberOrNull(slotData?.value);
            const explicitUsed = toNumberOrNull(slotData?.spent);
            const used = explicitUsed !== null ? explicitUsed : total !== null && available !== null ? Math.max(total - available, 0) : null;
            return compactObject({
                slot: key,
                level: key === "pact" ? "pact" : Number(key.replace("spell", "")),
                total,
                used,
                available
            });
        })
        .filter((slot) => (slot.total ?? 0) > 0 || (slot.used ?? 0) > 0 || (slot.available ?? 0) > 0);

    const totals = perLevel.reduce((acc, slot) => ({
        total: acc.total + (slot.total ?? 0),
        used: acc.used + (slot.used ?? 0),
        available: acc.available + (slot.available ?? 0)
    }), { total: 0, used: 0, available: 0 });

    return { perLevel, totals };
}

function getActorWeight(actor) {
    const encumbrance = actor?.system?.attributes?.encumbrance ?? {};
    const carried = toNumberOrNull(encumbrance.value ?? encumbrance.carried ?? encumbrance.total);
    const capacity = toNumberOrNull(encumbrance.max ?? encumbrance.capacity);
    const percent = toNumberOrNull(encumbrance.pct) ?? (carried !== null && capacity !== null && capacity > 0 ? (carried / capacity) * 100 : null);
    return compactObject({
        carried,
        capacity,
        percent,
        encumbered: typeof encumbrance.encumbered === "boolean" ? encumbrance.encumbered : undefined
    }, { keepNullKeys: ["carried", "capacity", "percent"] });
}

function getActorVitals(actor) {
    const attributes = actor?.system?.attributes ?? {};
    const hp = attributes.hp ?? {};
    return compactObject({
        hp: compactObject({
            value: toNumberOrNull(hp.value),
            max: toNumberOrNull(hp.max),
            temp: toNumberOrNull(hp.temp),
            tempmax: toNumberOrNull(hp.tempmax)
        }, { keepNullKeys: ["value", "max", "temp"] }),
        ac: toNumberOrNull(attributes.ac?.value ?? attributes.ac?.flat),
        initiative: toNumberOrNull(attributes.init?.total ?? attributes.init?.value),
        speed: attributes.movement || attributes.speed || null,
        prof: toNumberOrNull(attributes.prof)
    });
}

function getActorAbilities(actor) {
    const abilities = actor?.system?.abilities ?? {};
    return Object.fromEntries(Object.entries(abilities).map(([key, value]) => [key, compactObject({
        value: toNumberOrNull(value?.value),
        mod: toNumberOrNull(value?.mod),
        save: toNumberFromValueOrObject(value?.save)
    }, { keepNullKeys: ["value", "mod", "save"] })]));
}

function getActorResources(actor) {
    const resources = actor?.system?.resources ?? {};
    return Object.fromEntries(Object.entries(resources).map(([key, value]) => {
        const current = toNumberOrNull(value?.value);
        const max = toNumberOrNull(value?.max);
        return [key, compactObject({
            label: value?.label,
            value: current,
            max,
            sr: value?.sr,
            lr: value?.lr
        })];
    }).filter(([, value]) => {
        if (!Object.keys(value).length) return false;
        return Boolean(value.label) || (value.value ?? 0) > 0 || (value.max ?? 0) > 0;
    }));
}

function getActorCurrency(actor) {
    const currency = actor?.system?.currency ?? {};
    return Object.fromEntries(Object.entries(currency)
        .map(([key, value]) => [key, toNumberOrNull(value)])
        .filter(([, value]) => value !== null && value > 0));
}

function getItemCurrency(item) {
    const currency = item?.system?.currency
        ?? item?.system?.container?.currency
        ?? item?.system?.contents?.currency
        ?? {};
    return Object.fromEntries(Object.entries(currency)
        .map(([key, value]) => [key, toNumberFromValueOrObject(value)])
        .filter(([, value]) => value !== null && value > 0));
}

function getCurrencyWeight(currency) {
    if (!currency || typeof currency !== "object") return 0;
    const coinCount = Object.values(currency)
        .map(toNumberFromValueOrObject)
        .filter((value) => value !== null && value > 0)
        .reduce((sum, value) => sum + value, 0);
    return coinCount > 0 ? coinCount / 50 : 0;
}

function getItemWeight(item) {
    const system = item?.system ?? {};
    const quantity = Math.max(1, toNumberOrNull(system.quantity ?? system.qty ?? system.amount) ?? 1);
    const weight = system.weight;
    if (typeof weight === "object" && weight !== null) {
        const value = toNumberOrNull(weight.value ?? weight.total ?? weight.base);
        return value === null ? null : value * quantity;
    }
    const value = toNumberOrNull(weight);
    return value === null ? null : value * quantity;
}

function getContainedWeight(items, containerId) {
    const id = String(containerId || "").trim();
    if (!id) return null;
    const weights = (Array.isArray(items) ? items : [])
        .filter((item) => String(getItemContainer(item)?.id || "").trim() === id)
        .map(getItemWeight)
        .filter((value) => value !== null);
    return weights.length ? weights.reduce((sum, value) => sum + value, 0) : null;
}

function getItemCapacity(item, allItems = []) {
    const capacity = item?.system?.capacity ?? item?.system?.container?.capacity ?? {};
    if (!capacity || typeof capacity !== "object") return null;
    const weightCapacity = capacity.weight && typeof capacity.weight === "object" ? capacity.weight : null;
    const max = toNumberOrNull(weightCapacity?.value ?? weightCapacity?.max ?? capacity.max ?? capacity.value ?? capacity.capacity ?? capacity.total);
    const explicitUsed = toNumberOrNull(capacity.used ?? capacity.current ?? capacity.occupied ?? capacity.carried);
    const containedWeight = getContainedWeight(allItems, getItemDocumentId(item));
    const currencyWeight = getCurrencyWeight(getItemCurrency(item));
    const calculatedUsed = containedWeight !== null || currencyWeight > 0
        ? (containedWeight ?? 0) + currencyWeight
        : null;
    const used = explicitUsed ?? calculatedUsed;
    const unit = String(weightCapacity?.units || weightCapacity?.unit || capacity.units || capacity.unit || capacity.type || "lb").trim();
    if (max === null && used === null) return null;
    return compactObject({
        used,
        max,
        unit,
        type: capacity.type
    }, { keepNullKeys: ["used", "max"] });
}

function getActorDetails(actor) {
    const details = actor?.system?.details ?? {};
    return compactObject({
        level: toNumberOrNull(details.level),
        cr: toNumberOrNull(details.cr),
        type: typeof details.type === "string" ? details.type : details.type?.value,
        alignment: details.alignment,
        race: typeof details.race === "string" ? details.race : details.race?.name,
        class: typeof details.class === "string" ? details.class : details.class?.name
    });
}

function getActorTokenInfo(actor) {
    const token = actor?.prototypeToken ?? {};
    const texture = token.texture ?? {};
    return compactObject({
        img: texture.src || token.img,
        width: toNumberOrNull(token.width),
        height: toNumberOrNull(token.height),
        scale: toNumberOrNull(texture.scaleX)
    });
}

function mapActorForSync(actor, options = {}) {
    const usefulItemPredicate = options.usefulItemPredicate || isUsefulCharacterItem;
    const items = (actor.items?.contents ?? []).filter(usefulItemPredicate);
    return compactObject({
        id: actor.id,
        actorId: actor.id,
        characterId: options.ownerCharacterId,
        name: actor.name,
        displayName: options.displayName,
        type: actor.type,
        img: actor.img,
        token: getActorTokenInfo(actor),
        ownerCharacterId: options.ownerCharacterId,
        ownerAccountId: options.ownerAccountId,
        ownerDiscordId: options.ownerDiscordId,
        foundryName: actor.name,
        owners: game.users
            .filter((user) => !user.isGM && actor.testUserPermission(user, "OWNER"))
            .map((user) => ({ id: user.id, name: user.name })),
        details: getActorDetails(actor),
        vitals: getActorVitals(actor),
        xp: getActorXp(actor),
        abilities: getActorAbilities(actor),
        resources: getActorResources(actor),
        currency: getActorCurrency(actor),
        spellSlots: getActorSpellSlots(actor),
        equippedItems: items.filter((item) => item?.system?.equipped === true).map(mapStatusItem),
        attunementItems: items.filter(isItemAttuned).map(mapStatusItem),
        weight: getActorWeight(actor),
        inventory: items.map((item) => mapItemForCharacterSync(item, items))
    });
}

function parseCompanionMappings() {
    const raw = String(game.settings.get(MODULE_ID, SETTINGS.COMPANION_MAPPINGS) || "");
    const rows = parseStructuredActorMappingRows(raw);
    if (rows) {
        return rows
            .flatMap((row) => {
                const companionActorIds = normalizeActorIdList(row.companionActorIds || row.companions || row.actorIds || row.actorId);
                return companionActorIds.map((actorId) => compactObject({
                    actorId,
                    actorName: actorId,
                    ownerUserKey: row.userId || row.ownerUserKey,
                    ownerCharacterId: slugify(row.characterId || row.ownerCharacterId || ""),
                    ownerAccountId: row.accountId || row.ownerAccountId,
                    displayName: row.displayName
                }));
            })
            .filter((row) => row.actorId && row.ownerCharacterId);
    }
    return raw
        .split(/\r?\n/)
        .map((line) => line.trim())
        .filter((line) => line && !line.startsWith("#"))
        .flatMap(parseCompanionMappingLine)
        .filter((row) => row.actorName && (row.ownerCharacterId || row.ownerUserKey));
}

function parsePlayerActorMappings() {
    const raw = String(game.settings.get(MODULE_ID, SETTINGS.PLAYER_ACTOR_MAPPINGS) || "");
    const rows = parseStructuredActorMappingRows(raw);
    if (rows) {
        return rows
            .map((row) => compactObject({
                ownerUserKey: row.userId || row.ownerUserKey,
                actorRef: normalizeActorRef(row.actorId || row.actorRef),
                ownerCharacterId: slugify(row.characterId || row.ownerCharacterId || ""),
                ownerAccountId: row.accountId || row.ownerAccountId
            }))
            .filter((row) => row.ownerUserKey && row.actorRef && row.ownerCharacterId);
    }
    return raw
        .split(/\r?\n/)
        .map((line) => line.trim())
        .filter((line) => line && !line.startsWith("#"))
        .map((line) => {
            const parts = line.split("|").map((part) => String(part || "").trim());
            if (parts.length < 2 || !parts[0] || !parts[1]) return null;
            return compactObject({
                ownerUserKey: parts[0],
                actorRef: normalizeActorRef(parts[1]),
                ownerCharacterId: parts[2],
                ownerAccountId: parts[3]
            });
        })
        .filter(Boolean);
}

function parseStructuredActorMappingRows(raw) {
    const text = String(raw || "").trim();
    if (!text || !/^[\[{]/.test(text)) return null;
    try {
        const payload = JSON.parse(text);
        const rows = Array.isArray(payload) ? payload : payload?.rows;
        return Array.isArray(rows) ? rows.filter((row) => row && typeof row === "object") : [];
    } catch (error) {
        console.warn(`${MODULE_ID} | Mappatura actor JSON non valida.`, error);
        return [];
    }
}

function normalizeActorIdList(value) {
    if (Array.isArray(value)) return value.map(normalizeActorRef).filter(Boolean);
    return String(value || "")
        .split(/[,;]/)
        .map(normalizeActorRef)
        .filter(Boolean);
}

function normalizeActorRef(value) {
    const raw = String(value || "").trim();
    if (!raw) return "";
    const actorMatch = raw.match(/(?:^|\.)(Actor)\.([A-Za-z0-9]{8,})$/i);
    if (actorMatch?.[2]) return actorMatch[2];
    const uuidMatch = raw.match(/^Actor\.([A-Za-z0-9]{8,})(?:\.|$)/i);
    if (uuidMatch?.[1]) return uuidMatch[1];
    return raw;
}

function getConfiguredActor(value) {
    const actorId = normalizeActorRef(value);
    return actorId ? game.actors.get(actorId) : null;
}

async function loadCampaignPlayersForMappingConfig() {
    try {
        const response = await fetch(`${wikiDataService.getDataUrl("players.json")}?t=${Date.now()}`);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const payload = await response.json();
        const players = Array.isArray(payload) ? payload : (Array.isArray(payload?.data) ? payload.data : []);
        return players
            .map((player) => compactObject({
                id: slugify(player?.id || ""),
                name: player?.name || player?.id || "",
                accountId: compactAutoLoginKey(player?.accountId || "")
            }))
            .filter((player) => player.id);
    } catch (error) {
        console.warn(`${MODULE_ID} | Impossibile caricare players.json per configurazione actor.`, error);
        return [];
    }
}

function findCampaignPlayerForAccount(players, characterId, accountId) {
    const wantedCharacterId = slugify(characterId || "");
    const wantedAccountId = compactAutoLoginKey(accountId || "");
    return (Array.isArray(players) ? players : []).find((player) => wantedCharacterId && player.id === wantedCharacterId)
        || (Array.isArray(players) ? players : []).find((player) => wantedAccountId && compactAutoLoginKey(player.accountId) === wantedAccountId)
        || null;
}

function getConfiguredPlayerMappingForUser(user, mappings = parsePlayerActorMappings()) {
    const userKeys = getFoundryUserCompanionKeys(user);
    return mappings.find((entry) => {
        const ownerUserKey = compactAutoLoginKey(entry.ownerUserKey);
        const ownerAccountId = compactAutoLoginKey(entry.ownerAccountId);
        return (ownerUserKey && userKeys.has(ownerUserKey))
            || (ownerAccountId && userKeys.has(ownerAccountId));
    }) || null;
}

function getConfiguredAccountIdForUser(user, mappings = parsePlayerActorMappings()) {
    const mapping = getConfiguredPlayerMappingForUser(user, mappings);
    return compactAutoLoginKey(mapping?.ownerAccountId || getPreferredAccountIdForFoundryUser(user));
}

function getConfiguredPlayerActorRefForUser(user, mappings = parsePlayerActorMappings()) {
    const mapping = getConfiguredPlayerMappingForUser(user, mappings);
    return mapping?.actorRef || "";
}

function getConfiguredCompanionActorRefsForUser(user, mappings = parseCompanionMappings()) {
    const userKeys = getFoundryUserCompanionKeys(user);
    return mappings
        .filter((entry) => {
            const ownerUserKey = compactAutoLoginKey(entry.ownerUserKey);
            const ownerAccountId = compactAutoLoginKey(entry.ownerAccountId);
            return (ownerUserKey && userKeys.has(ownerUserKey))
                || (ownerAccountId && userKeys.has(ownerAccountId));
        })
        .map((entry) => entry.actorId || entry.actorName)
        .filter(Boolean);
}


function resolveConfiguredPlayerActors(mappings = parsePlayerActorMappings()) {
    const seen = new Set();
    return mappings
        .map((mapping) => {
            const actor = getConfiguredActor(mapping.actorRef);
            if (!actor || actor.type !== "character") {
                console.warn(`${MODULE_ID} | Actor personaggio configurato non trovato.`, { mapping });
                return null;
            }
            if (seen.has(actor.id)) return null;
            seen.add(actor.id);
            return { actor, mapping };
        })
        .filter(Boolean);
}

function getConfiguredCompanionNamesForUser(user, mappings = parseCompanionMappings()) {
    const userKeys = getFoundryUserCompanionKeys(user);
    const playerActorKeys = new Set(game.actors
        .filter((actor) => actor.type === "character" && actor.testUserPermission(user, "OWNER"))
        .flatMap((actor) => {
            const actorName = normalizeWikiItemKey(actor.name);
            const keys = [actor.id, actor.name, slugify(actor.name), actorName];
            Object.entries(WIKI_PLAYER_ID_ALIASES).forEach(([wikiId, aliases]) => {
                const aliasMatch = aliases.map(normalizeWikiItemKey).some((alias) => alias && actorName && (alias === actorName || actorName.includes(alias) || alias.includes(actorName)));
                if (aliasMatch) keys.push(wikiId);
            });
            return keys.map(compactAutoLoginKey).filter(Boolean);
        }));

    const names = [];
    mappings.forEach((mapping) => {
        const ownerUserKey = compactAutoLoginKey(mapping.ownerUserKey);
        const ownerAccountId = compactAutoLoginKey(mapping.ownerAccountId);
        const ownerCharacterId = compactAutoLoginKey(mapping.ownerCharacterId);
        const belongsToUser = (ownerUserKey && userKeys.has(ownerUserKey))
            || (ownerAccountId && userKeys.has(ownerAccountId))
            || (ownerCharacterId && playerActorKeys.has(ownerCharacterId));
        if (!belongsToUser) return;
        const actorRef = mapping.actorId || mapping.actorName;
        const label = mapping.displayName && mapping.displayName !== actorRef
            ? `${actorRef} => ${mapping.displayName}`
            : actorRef;
        if (label && !names.includes(label)) names.push(label);
    });

    return names;
}

function parseCompanionMappingLine(line) {
    const parts = line.split("|").map((part) => String(part || "").trim());
    if (parts.length >= 3) {
        const [actorName, ownerCharacterId, ownerAccountId, displayName] = parts;
        return [compactObject({ actorName, ownerCharacterId, ownerAccountId, displayName, format: "character" })];
    }

    if (parts.length !== 2) return [];

    const [first, second] = parts;
    if (!first || !second) return [];

    // Backward compatibility for the old short form: companion actor | owner characterId.
    if (findActorByMappingName(first) && !findActorByMappingName(second)) {
        return [compactObject({ actorName: first, ownerCharacterId: second, format: "character" })];
    }

    return splitCompanionNames(second).map((entry) => compactObject({
        actorName: entry.actorName,
        displayName: entry.displayName,
        ownerUserKey: first,
        format: "user"
    }));
}

function splitCompanionNames(value) {
    return String(value || "")
        .split(/[,;]/)
        .map((entry) => entry.trim())
        .filter(Boolean)
        .map((entry) => {
            const match = entry.match(/^(.*?)\s*(?:=>|->|\bas\b|\bcome\b)\s*(.*?)$/i);
            if (!match) return { actorName: entry };
            return {
                actorName: String(match[1] || "").trim(),
                displayName: String(match[2] || "").trim()
            };
        })
        .filter((entry) => entry.actorName);
}

function findActorByMappingName(name) {
    const normalized = normalizeWikiItemKey(name);
    return game.actors.find((actor) => actor.id === name)
        || game.actors.find((actor) => normalizeWikiItemKey(actor.name) === normalized)
        || game.actors.find((actor) => {
            const actorName = normalizeWikiItemKey(actor.name);
            return actorName && normalized && (actorName.includes(normalized) || normalized.includes(actorName));
        })
        || null;
}

function getDeviceCodeAccountId(code) {
    const normalized = String(code || "").trim();
    const match = normalized.match(/^([A-Za-z0-9]+)/);
    return match ? compactAutoLoginKey(match[1]) : "";
}

function getFoundryUserCompanionKeys(user) {
    const keys = new Set([
        user?.id,
        user?.name
    ].map(compactAutoLoginKey).filter(Boolean));

    const configured = parseAutoDeviceLoginConfig();
    const userKeys = [user?.id, user?.name].map((key) => String(key || "").trim()).filter(Boolean);
    for (const [configKey, code] of configured.entries()) {
        const matchesUser = userKeys.some((candidate) => autoLoginKeyMatches(configKey, candidate));
        if (!matchesUser) continue;
        const normalizedConfigKey = compactAutoLoginKey(configKey);
        const accountId = getDeviceCodeAccountId(code);
        if (normalizedConfigKey) keys.add(normalizedConfigKey);
        if (accountId) keys.add(accountId);
    }

    return keys;
}

function findFoundryUserByCompanionKey(value) {
    const target = compactAutoLoginKey(value);
    if (!target) return null;
    return game.users.find((user) => getFoundryUserCompanionKeys(user).has(target)) || null;
}

function getPreferredAccountIdForFoundryUser(user) {
    const configured = parseAutoDeviceLoginConfig();
    const userKeys = [user?.id, user?.name].map((key) => String(key || "").trim()).filter(Boolean);
    for (const [configKey, code] of configured.entries()) {
        if (!userKeys.some((candidate) => autoLoginKeyMatches(configKey, candidate))) continue;
        const accountId = getDeviceCodeAccountId(code);
        if (accountId) return accountId;
    }
    return compactAutoLoginKey(user?.name || user?.id);
}

async function resolveOwnerCharacterIdForCompanionMapping(mapping, companionActor, playerActors) {
    if (mapping.ownerCharacterId) return mapping.ownerCharacterId;

    console.warn(`${MODULE_ID} | Companion senza characterId configurato, non esportato.`, { companion: companionActor?.name, mapping });
    return "";
}

function isConfiguredCompanionActor(actor) {
    if (!actor) return false;
    return parseCompanionMappings().some((mapping) => {
        const mappedActor = getConfiguredActor(mapping.actorId || mapping.actorName);
        return mappedActor?.id === actor.id;
    });
}

function isConfiguredPlayerActor(actor) {
    if (!actor) return false;
    const configured = resolveConfiguredPlayerActors();
    return configured.some((entry) => entry.actor?.id === actor.id);
}

function getPlayerActorsForWikiSync() {
    const configured = resolveConfiguredPlayerActors()
        .map((entry) => entry.actor)
        .filter(Boolean);
    return configured;
}

function getConfiguredCharacterIdForActor(actor) {
    const actorId = String(actor?.id || "").trim();
    if (!actorId) return "";
    const mapping = parsePlayerActorMappings().find((entry) => normalizeActorRef(entry.actorRef) === actorId);
    return mapping?.ownerCharacterId || "";
}

function getConfiguredCompanionOwnerCharacterIdForActor(actor) {
    const actorId = String(actor?.id || "").trim();
    if (!actorId) return "";
    const mapping = parseCompanionMappings().find((entry) => {
        const mappedActor = getConfiguredActor(entry.actorId || entry.actorName);
        return mappedActor?.id === actorId;
    });
    return slugify(mapping?.ownerCharacterId || "");
}

async function buildCharacterSyncPayload() {
    const configuredPlayerActors = resolveConfiguredPlayerActors();
    const playerActorEntries = configuredPlayerActors;
    const playerActors = playerActorEntries.map((entry) => entry.actor);
    const actors = await Promise.all(playerActorEntries.map(async ({ actor, mapping }) => mapActorForSync(actor, {
        ownerCharacterId: mapping?.ownerCharacterId,
        ownerAccountId: mapping?.ownerAccountId
    })));
    const companions = (await Promise.all(parseCompanionMappings()
        .map(async (mapping) => {
            const actor = getConfiguredActor(mapping.actorId || mapping.actorName);
            if (!actor) return null;
            const ownerCharacterId = await resolveOwnerCharacterIdForCompanionMapping(mapping, actor, playerActors);
            if (!ownerCharacterId) return null;
            const ownerUser = mapping.ownerUserKey ? findFoundryUserByCompanionKey(mapping.ownerUserKey) : null;
            return mapActorForSync(actor, {
                displayName: mapping.displayName,
                ownerCharacterId,
                ownerAccountId: mapping.ownerAccountId || (ownerUser ? getPreferredAccountIdForFoundryUser(ownerUser) : undefined),
                ownerDiscordId: mapping.ownerDiscordId,
                usefulItemPredicate: isUsefulCompanionItem
            });
        }))).filter(Boolean);

    return {
        schemaVersion: 3,
        moduleId: MODULE_ID,
        world: { id: game.world.id, title: game.world.title },
        gm: { id: game.user.id, name: game.user.name },
        generatedAt: new Date().toISOString(),
        actors,
        companions
    };
}

function buildFoundryAssetRegistrySnapshot(payload) {
    const assets = [];
    const worldId = String(payload?.world?.id || game.world?.id || "").trim();
    const addAsset = (asset) => {
        const normalized = compactObject(asset);
        if (!normalized.entityType || !normalized.entityId || !normalized.slot) return;
        if (!String(normalized.value || "").trim()) return;
        const hashInput = {
            value: normalized.value,
            slot: normalized.slot,
            foundry: normalized.foundry || {}
        };
        assets.push({
            ...normalized,
            id: `${getCampaignId()}:${normalized.entityType}:${normalized.entityId}:${normalized.slot}`,
            hash: hashAssetValue(hashInput),
            updatedAt: payload?.generatedAt || new Date().toISOString()
        });
    };

    const addActorAssets = (actor, entityType) => {
        if (!actor) return;
        const entityId = entityType === "companion"
            ? buildCompanionMediaEntityId(actor.ownerCharacterId || "", actor.actorId || actor.id || "", actor.foundryName || actor.name || "")
            : slugify(actor.ownerCharacterId || actor.id || actor.name);
        const actorRef = {
            worldId,
            actorId: actor.id,
            actorName: actor.foundryName || actor.name,
            uuid: actor.id ? `Actor.${actor.id}` : ""
        };
        addAsset({
            entityType,
            entityId,
            slot: "avatar",
            label: `${actor.name || actor.foundryName || entityId} - Avatar`,
            value: actor.img,
            foundry: actorRef
        });
        addAsset({
            entityType,
            entityId,
            slot: "token",
            label: `${actor.name || actor.foundryName || entityId} - Token`,
            value: actor.token?.img,
            foundry: actorRef
        });
        (Array.isArray(actor.inventory) ? actor.inventory : []).forEach((item) => {
            addItemAssets(actor, item, actorRef);
        });
    };

    const addItemAssets = (actor, item, actorRef) => {
        if (!item) return;
        const itemType = item.type === "feat" || item.type === "spell" ? "ability" : "item";
        const ownerId = slugify(actor.ownerCharacterId || actor.id || actor.name || "actor");
        const itemKey = slugify(`${ownerId}-${item.type || "item"}-${item.name || item.id || "entry"}`);
        const foundry = {
            ...actorRef,
            itemId: item.id,
            itemName: item.name,
            uuid: actor.id && item.id ? `Actor.${actor.id}.Item.${item.id}` : actorRef.uuid
        };
        addAsset({
            entityType: itemType,
            entityId: itemKey,
            slot: "image",
            label: `${actor.name || actor.foundryName || ownerId} - ${item.name || "Elemento"} - Icona`,
            value: item.img,
            foundry
        });
        addAsset({
            entityType: itemType,
            entityId: itemKey,
            slot: "description",
            label: `${actor.name || actor.foundryName || ownerId} - ${item.name || "Elemento"} - Descrizione`,
            value: item.description,
            foundry
        });
    };

    (Array.isArray(payload?.actors) ? payload.actors : []).forEach((actor) => addActorAssets(actor, "player"));
    (Array.isArray(payload?.companions) ? payload.companions : []).forEach((actor) => addActorAssets(actor, "companion"));
    return assets;
}

function hashAssetValue(value) {
    const text = stableAssetStringify(value);
    let hash = 2166136261;
    for (let i = 0; i < text.length; i += 1) {
        hash ^= text.charCodeAt(i);
        hash = Math.imul(hash, 16777619);
    }
    return `fnv1a:${(hash >>> 0).toString(16).padStart(8, "0")}`;
}

function stableAssetStringify(value) {
    if (value === null || value === undefined) return "";
    if (typeof value !== "object") return String(value);
    if (Array.isArray(value)) return `[${value.map(stableAssetStringify).join(",")}]`;
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stableAssetStringify(value[key])}`).join(",")}}`;
}

function canSyncCharacters() {
    if (!game.user?.isGM) return false;
    if (game.users.activeGM?.id && game.users.activeGM.id !== game.user.id) return false;
    return true;
}

async function syncCharactersToWorker({ notify = false } = {}) {
    if (!canSyncCharacters()) return false;
    const payload = await buildCharacterSyncPayload();
    payload.assetRegistry = {
        schemaVersion: 1,
        generatedAt: payload.generatedAt,
        assets: buildFoundryAssetRegistrySnapshot(payload)
    };
    const secret = String(game.settings.get(MODULE_ID, SETTINGS.INVENTORY_SYNC_SECRET) || "").trim();
    payload.campaignId = getCampaignId();
    const response = await fetch(withCampaign(`${DISCORD_WORKER_URL}/api/inventory`), {
        method: "POST",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            ...(secret ? { "X-Cripta-Inventory-Secret": secret } : {})
        },
        body: JSON.stringify(payload)
    });
    const data = await response.json().catch(() => null);
    if (!response.ok || data?.ok === false) throw new Error(data?.error || `HTTP ${response.status}`);
    if (notify) ui.notifications.info(`Personaggi sincronizzati (${payload.actors.length}, companion ${payload.companions?.length || 0}).`);
    console.info(`${MODULE_ID} | Personaggi sincronizzati.`, {
        actors: payload.actors.length,
        companions: payload.companions?.length || 0,
        assets: payload.assetRegistry.assets.length,
        assetRegistry: data?.assetRegistry || null,
        savedAt: data?.savedAt
    });
    return true;
}

function scheduleCharacterSync(reason = "update") {
    if (suppressCharacterSync) return;
    if (!canSyncCharacters()) return;
    const enabled = game.settings.get(MODULE_ID, SETTINGS.AUTO_CHARACTER_SYNC);
    if (!enabled) return;
    window.clearTimeout(characterSyncTimer);
    characterSyncTimer = window.setTimeout(() => {
        syncCharactersToWorker().catch((error) => {
            console.warn(`${MODULE_ID} | Sync personaggi fallito (${reason}).`, error);
        });
    }, 6000);
}

function getStoredWikiUser() {
    try {
        const user = game.settings.get(MODULE_ID, SETTINGS.DISCORD_USER) || {};
        const id = String(user.id || user.discordId || "").trim();
        return id ? { ...user, id } : null;
    } catch (_) {
        return null;
    }
}

async function requestNotesApi(path, options = {}) {
    const token = String(game.settings.get(MODULE_ID, SETTINGS.DISCORD_TOKEN) || "").trim();
    if (!token) throw new Error("Login wiki richiesto.");

    const url = new URL(`${DISCORD_WORKER_URL}/${path.replace(/^\/+/, "")}`);
    Object.entries(options.query || {}).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== "") url.searchParams.set(key, value);
    });
    url.searchParams.set("campaign", getCampaignId());

    const response = await fetch(url.toString(), {
        method: options.method || "GET",
        headers: {
            Accept: "application/json",
            ...(options.body ? { "Content-Type": "application/json" } : {}),
            Authorization: `Bearer ${token}`
        },
        body: options.body ? JSON.stringify({ ...options.body, campaignId: getCampaignId() }) : undefined
    });
    const data = await response.json().catch(() => null);
    if (!response.ok) throw new Error(data?.error || `HTTP ${response.status}`);
    return data;
}

function resolveAbilityOverrideImageUrl(image) {
    const value = String(image || "").trim();
    if (!value) return "";
    if (/^(https?:|data:|blob:)/i.test(value)) return value;
    if (value.startsWith("media/")) return `${DISCORD_WORKER_URL}/${value.replace(/^\/+/, "")}`;
    return value;
}

function renderAbilityOverrideDescription(value) {
    const raw = String(value || "").trim();
    if (!raw) return "";
    if (/<[^>]+>/.test(raw)) return raw;
    return raw
        .split(/\n{2,}/)
        .map((paragraph) => paragraph.trim())
        .filter(Boolean)
        .map((paragraph) => `<p>${escapeHtml(paragraph).replace(/\n/g, "<br>")}</p>`)
        .join("");
}

function normalizeOverrideCompareValue(value) {
    return String(value || "")
        .replace(/\r\n/g, "\n")
        .replace(/\s+/g, " ")
        .trim();
}

function normalizeOverrideImageValue(value) {
    const raw = String(value || "").trim();
    if (!raw) return "";
    const workerBase = DISCORD_WORKER_URL.replace(/\/+$/, "");
    return raw
        .replace(workerBase, "")
        .replace(/^https?:\/\/khuzoe\.github\.io\/sigillo-del-male\/assets\//i, "")
        .replace(/^\/+/, "")
        .trim();
}

function describeOverrideChanges(changes) {
    return changes.map((change) => change.label).join(", ");
}

async function selectWikiOverridesToApply({ title, description, entries }) {
    if (!entries.length) return [];
    if (entries.length === 1) return entries;

    const rows = entries.map((entry, index) => `
        <label class="cripta-override-select-row">
            <input type="checkbox" name="override" value="${index}" checked>
            <span>
                <strong>${escapeHtml(entry.label)}</strong>
                <small>${escapeHtml(entry.detail || "")}</small>
                <em>${escapeHtml(describeOverrideChanges(entry.changes || []))}</em>
            </span>
        </label>
    `).join("");

    let settled = false;
    return new Promise((resolve) => {
        const finish = (value) => {
            if (settled) return;
            settled = true;
            resolve(value);
        };
        const dialog = new Dialog({
            title,
            content: `
                <form class="cripta-override-select">
                    <p>${escapeHtml(description || "Seleziona gli elementi da sincronizzare dal sito verso Foundry.")}</p>
                    <div class="cripta-override-select-toolbar">
                        <button type="button" data-override-select-all>Seleziona tutto</button>
                        <button type="button" data-override-select-none>Deseleziona tutto</button>
                    </div>
                    <div class="cripta-override-select-list">
                        ${rows}
                    </div>
                </form>
                <style>
                    .cripta-override-select p { margin: 0 0 0.75rem; }
                    .cripta-override-select-toolbar { display: flex; gap: 0.5rem; margin-bottom: 0.75rem; }
                    .cripta-override-select-toolbar button {
                        border: 1px solid rgba(184, 139, 43, 0.7);
                        border-radius: 6px;
                        background: rgba(0, 0, 0, 0.25);
                        color: #f0dfb6;
                        padding: 0.25rem 0.6rem;
                    }
                    .cripta-override-select-list { display: grid; gap: 0.45rem; max-height: 420px; overflow: auto; padding-right: 0.25rem; }
                    .cripta-override-select-row {
                        display: grid;
                        grid-template-columns: auto 1fr;
                        gap: 0.6rem;
                        align-items: start;
                        padding: 0.55rem 0.65rem;
                        border: 1px solid rgba(184, 139, 43, 0.35);
                        border-radius: 8px;
                        background: rgba(0, 0, 0, 0.18);
                    }
                    .cripta-override-select-row input { margin-top: 0.2rem; }
                    .cripta-override-select-row strong,
                    .cripta-override-select-row small,
                    .cripta-override-select-row em { display: block; }
                    .cripta-override-select-row small { opacity: 0.78; margin-top: 0.15rem; }
                    .cripta-override-select-row em { color: #f0c84a; font-style: normal; margin-top: 0.2rem; }
                </style>
            `,
            buttons: {
                apply: {
                    icon: '<i class="fas fa-check"></i>',
                    label: "Applica selezionati",
                    callback: (html) => {
                        const root = html instanceof HTMLElement ? html : html[0];
                        const selected = Array.from(root?.querySelectorAll?.('input[name="override"]:checked') || [])
                            .map((input) => entries[Number(input.value)])
                            .filter(Boolean);
                        finish(selected);
                    }
                },
                cancel: {
                    icon: '<i class="fas fa-xmark"></i>',
                    label: "Annulla",
                    callback: () => finish(null)
                }
            },
            render: (html) => {
                const root = html instanceof HTMLElement ? html : html[0];
                root?.querySelector?.("[data-override-select-all]")?.addEventListener("click", () => {
                    root.querySelectorAll('input[name="override"]').forEach((input) => { input.checked = true; });
                });
                root?.querySelector?.("[data-override-select-none]")?.addEventListener("click", () => {
                    root.querySelectorAll('input[name="override"]').forEach((input) => { input.checked = false; });
                });
            },
            close: () => finish(null)
        }, {
            width: 620,
            classes: ["cripta-override-select-dialog"]
        });
        dialog.render(true);
    });
}

function findActorForAbilityOverride(override) {
    const actorId = normalizeActorRef(override?.actorId || "");
    const actorName = normalizeWikiItemKey(override?.actorName || override?.characterName || "");
    return (actorId ? game.actors.get(actorId) : null)
        || game.actors.find((actor) => actor.type === "character" && normalizeWikiItemKey(actor.name) === actorName)
        || game.actors.find((actor) => actor.type === "character" && actorName && normalizeWikiItemKey(actor.name).includes(actorName))
        || null;
}

function findActorAbilityItem(actor, override) {
    if (!actor) return null;
    const abilityId = String(override?.abilityId || "").trim();
    const abilityName = normalizeWikiItemKey(override?.abilityName || "");
    return (abilityId ? actor.items.get(abilityId) : null)
        || actor.items.find((item) => item.type === "feat" && normalizeWikiItemKey(item.name) === abilityName)
        || null;
}

function findActorInventoryItem(actor, override) {
    if (!actor) return null;
    const transferId = String(override?.transferId || "").trim();
    const transferKey = String(override?.transferKey || "").trim();
    const sourceId = normalizeWikiItemKey(override?.sourceId || "");
    const itemId = String(override?.itemId || "").trim();
    const itemName = normalizeWikiItemKey(override?.itemName || "");
    return actor.items.find((item) => transferId && getItemTransferId(item) === transferId)
        || actor.items.find((item) => transferKey && getItemOverrideIdentityForItem(actor, item).transferKey === transferKey)
        || actor.items.find((item) => sourceId && normalizeWikiItemKey(getItemStableSourceId(item)) === sourceId)
        || (itemId ? actor.items.get(itemId) : null)
        || actor.items.find((item) => itemName && normalizeWikiItemKey(item.name) === itemName)
        || null;
}

async function applyAbilityOverridesFromWiki({ notify = false } = {}) {
    if (!game.user?.isGM) {
        ui.notifications.warn("Solo il GM puo applicare override abilita dalla wiki.");
        return false;
    }

    const payload = await requestNotesApi("api/data/ability-overrides");
    const overrides = Array.isArray(payload?.data) ? payload.data : [];
    if (!overrides.length) {
        ui.notifications.info("Nessun override abilita trovato nella wiki.");
        return true;
    }

    const candidates = [];
    let skipped = 0;
    for (const override of overrides) {
        const actor = findActorForAbilityOverride(override);
        const item = findActorAbilityItem(actor, override);
        if (!actor || !item) {
            skipped += 1;
            console.warn(`${MODULE_ID} | Override abilita non applicato: actor/item non trovato.`, override);
            continue;
        }

        const patch = {};
        const imageRemote = String(override.image || "").trim();
        const image = resolveAbilityOverrideImageUrl(imageRemote);
        const description = renderAbilityOverrideDescription(override.description);
        const hasProgressOverride = Object.prototype.hasOwnProperty.call(override, "progress");
        const progressOverride = hasProgressOverride ? normalizeItemProgressDraft(override.progress) : undefined;
        const changes = [];
        if (image && normalizeOverrideImageValue(image) !== normalizeOverrideImageValue(item.img)) {
            patch.img = imageRemote;
            changes.push({ field: "image", label: "Icona" });
        }
        const currentDescription = item.system?.description?.value || "";
        if (description && normalizeOverrideCompareValue(description) !== normalizeOverrideCompareValue(currentDescription)) {
            patch["system.description.value"] = description;
            changes.push({ field: "description", label: "Descrizione" });
        }
        if (hasProgressOverride) {
            const currentProgress = getItemProgress(item);
            if (progressOverride) {
                if (JSON.stringify(currentProgress || null) !== JSON.stringify(progressOverride)) {
                    changes.push({ field: "progress", label: "Progresso" });
                }
            } else if (currentProgress) {
                changes.push({ field: "progress", label: "Rimuovi progresso" });
            }
        }
        if (!Object.keys(patch).length && !changes.some((change) => change.field === "progress")) {
            skipped += 1;
            continue;
        }

        candidates.push({
            label: `${actor.name} - ${item.name}`,
            detail: "Abilita",
            changes,
            apply: async () => {
                const nextPatch = { ...patch };
                if (nextPatch.img) {
                    const identity = getAbilityOverrideIdentityForItem(actor, item);
                    const effectiveImage = await resolveAndRegisterManagedMedia(item, "image", {
                        remote: nextPatch.img,
                        local: item.img,
                        entityType: "ability",
                        entityId: identity.key,
                        actor,
                        item,
                        downloadFallback: true
                    });
                    if (effectiveImage) nextPatch.img = effectiveImage;
                    else delete nextPatch.img;
                }
                if (Object.keys(nextPatch).length) await item.update(nextPatch);
                if (hasProgressOverride) {
                    if (progressOverride) await item.setFlag(MODULE_ID, "progress", progressOverride);
                    else await item.setFlag(MODULE_ID, "progress", { label: "Progresso", done: 0, total: 0, disabled: true });
                }
                return item;
            }
        });
    }

    const selected = await selectWikiOverridesToApply({
        title: "Applica override abilita",
        description: "Seleziona quali abilita rendere uguali al sito.",
        entries: candidates
    });
    if (selected === null) return false;

    let updated = 0;
    for (const entry of selected) {
        await entry.apply();
        updated += 1;
    }
    skipped += candidates.length - selected.length;

    if (notify) ui.notifications.info(`Override abilita applicati: ${updated}. Saltati: ${skipped}.`);
    console.info(`${MODULE_ID} | Override abilita wiki applicati.`, { updated, skipped });
    return true;
}

async function applyItemOverridesFromWiki({ notify = false } = {}) {
    if (!game.user?.isGM) {
        ui.notifications.warn("Solo il GM puo applicare override inventario dalla wiki.");
        return false;
    }

    const payload = await requestNotesApi("api/data/item-overrides");
    const overrides = Array.isArray(payload?.data) ? payload.data : [];
    if (!overrides.length) {
        ui.notifications.info("Nessun override inventario trovato nella wiki.");
        return true;
    }

    const candidates = [];
    let skipped = 0;
    for (const override of overrides) {
        const actor = findActorForAbilityOverride(override);
        const item = findActorInventoryItem(actor, override);
        if (!actor || !item) {
            skipped += 1;
            console.warn(`${MODULE_ID} | Override inventario non applicato: actor/item non trovato.`, override);
            continue;
        }

        const patch = {};
        const imageRemote = String(override.image || "").trim();
        const image = resolveAbilityOverrideImageUrl(imageRemote);
        const managedImageRemote = normalizeManagedRemotePath(imageRemote);
        const currentManagedImage = getManagedMediaState(item, "image");
        const needsManagedImageRegistration = Boolean(managedImageRemote)
            && normalizeManagedRemotePath(currentManagedImage?.remote) !== managedImageRemote;
        const description = renderAbilityOverrideDescription(override.description);
        const changes = [];
        if (image && normalizeOverrideImageValue(image) !== normalizeOverrideImageValue(item.img)) {
            patch.img = imageRemote;
            changes.push({ field: "image", label: "Icona" });
        }
        if (needsManagedImageRegistration && !changes.some((change) => change.field === "image")) {
            changes.push({ field: "managedMedia", label: "Path R2" });
        }
        const currentDescription = item.system?.description?.value || "";
        if (description && normalizeOverrideCompareValue(description) !== normalizeOverrideCompareValue(currentDescription)) {
            patch["system.description.value"] = description;
            changes.push({ field: "description", label: "Descrizione" });
        }
        if (!Object.keys(patch).length && !needsManagedImageRegistration) {
            skipped += 1;
            continue;
        }

        candidates.push({
            label: `${actor.name} - ${item.name}`,
            detail: "Inventario",
            changes,
            apply: async () => {
                const nextPatch = { ...patch };
                if (imageRemote) {
                    const identity = getItemOverrideIdentityForItem(actor, item);
                    const effectiveImage = await resolveAndRegisterManagedMedia(item, "image", {
                        remote: imageRemote,
                        local: item.img,
                        entityType: "item",
                        entityId: identity.key,
                        actor,
                        item,
                        downloadFallback: true
                    });
                    if (nextPatch.img) {
                        if (effectiveImage) nextPatch.img = effectiveImage;
                        else delete nextPatch.img;
                    }
                }
                if (!Object.keys(nextPatch).length) return null;
                return item.update(nextPatch);
            }
        });
    }

    const selected = await selectWikiOverridesToApply({
        title: "Applica override inventario",
        description: "Seleziona quali oggetti rendere uguali al sito.",
        entries: candidates
    });
    if (selected === null) return false;

    let updated = 0;
    for (const entry of selected) {
        await entry.apply();
        updated += 1;
    }
    skipped += candidates.length - selected.length;

    if (notify) ui.notifications.info(`Override inventario applicati: ${updated}. Saltati: ${skipped}.`);
    console.info(`${MODULE_ID} | Override inventario wiki applicati.`, { updated, skipped });
    return true;
}

function getAbilityOverrideIdentityForItem(actor, item) {
    const actorId = String(actor?.id || "").trim();
    const actorName = String(actor?.name || "").trim();
    const abilityId = String(item?.id || "").trim();
    const abilityName = String(item?.name || "").trim();
    return {
        key: `${slugify(actorId || actorName || "personaggio")}:${slugify(abilityId || abilityName || "abilita")}`,
        actorId,
        actorName,
        abilityId,
        abilityName
    };
}

function getItemOverrideIdentityForItem(actor, item) {
    const actorId = String(actor?.id || "").trim();
    const actorName = String(actor?.name || "").trim();
    const itemId = String(item?.id || "").trim();
    const itemName = String(item?.name || "").trim();
    const itemType = String(item?.type || "").trim();
    const transferId = getItemTransferId(item);
    const sourceId = getItemStableSourceId(item);
    const transferKey = getTransferableItemKey({ itemId, itemName, itemType, sourceId, transferId });
    return {
        key: `${slugify(actorId || actorName || "personaggio")}:${slugify(itemId || itemName || "oggetto")}`,
        actorId,
        actorName,
        itemUuid: String(item?.uuid || "").trim(),
        transferId,
        sourceId,
        transferKey,
        itemId,
        itemName,
        itemType
    };
}

function getItemTransferId(item) {
    return String(item?.getFlag?.(MODULE_ID, "transferId") || item?.flags?.[MODULE_ID]?.transferId || "").trim();
}

async function ensureItemTransferId(item) {
    const existing = getItemTransferId(item);
    if (existing) return existing;
    const id = `item-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
    await item?.setFlag?.(MODULE_ID, "transferId", id);
    return id;
}

function getItemStableSourceId(item) {
    return String(
        item?.getFlag?.("core", "sourceId")
        || item?.flags?.core?.sourceId
        || item?.system?.source?.uuid
        || item?.system?.source?.id
        || item?.flags?.[MODULE_ID]?.wikiItemId
        || ""
    ).trim();
}

function getTransferableItemKey({ itemId = "", itemName = "", itemType = "", sourceId = "", transferId = "" } = {}) {
    const instance = normalizeWikiItemKey(transferId);
    if (instance) return `instance:${instance}`;
    const stableSource = normalizeWikiItemKey(sourceId);
    if (stableSource) return `source:${stableSource}`;
    const name = normalizeWikiItemKey(itemName);
    const type = normalizeWikiItemKey(itemType);
    if (name && type) return `name:${type}:${name}`;
    if (name) return `name:${name}`;
    const id = normalizeWikiItemKey(itemId);
    return id ? `id:${id}` : "";
}

async function resolveWikiCharacterIdForActor(actor) {
    const actorName = normalizeWikiItemKey(actor?.name);
    if (!actorName) return slugify(actor?.id || "personaggio");
    const knownMatch = Object.entries(WIKI_PLAYER_ID_ALIASES).find(([, aliases]) =>
        aliases.map(normalizeWikiItemKey).some((alias) => alias && (alias === actorName || actorName.includes(alias) || alias.includes(actorName)))
    );
    if (knownMatch?.[0]) return knownMatch[0];
    const findPlayerMatch = (players) => (Array.isArray(players) ? players : []).find((player) => {
        const keys = [
            player?.id,
            player?.name,
            player?.foundryName,
            player?.inventory_api_name,
            ...(Array.isArray(player?.inventory_api_aliases) ? player.inventory_api_aliases : [])
        ].map(normalizeWikiItemKey).filter(Boolean);
        return keys.some((key) => key === actorName || key.includes(actorName) || actorName.includes(key));
    });

    try {
        const data = await wikiDataService.load();
        const match = findPlayerMatch(data?.indexPlayers);
        if (match?.id) return slugify(match.id);
    } catch (error) {
        console.warn(`${MODULE_ID} | Indice wiki non disponibile per risolvere id personaggio, provo players.json.`, { actor: actor?.name, error });
    }

    try {
        if (typeof wikiDataService.getDataUrl === "function") {
            const response = await fetch(`${wikiDataService.getDataUrl("players.json")}?t=${Date.now()}`);
            if (response.ok) {
                const payload = await response.json();
                const players = Array.isArray(payload) ? payload : (Array.isArray(payload?.data) ? payload.data : []);
                const match = findPlayerMatch(players);
                if (match?.id) return slugify(match.id);
            }
        }
    } catch (error) {
        console.warn(`${MODULE_ID} | Impossibile risolvere id wiki personaggio, uso fallback.`, { actor: actor?.name, error });
    }
    return slugify(actor?.name || actor?.id || "personaggio");
}

function findExistingAbilityOverrideRecord(records, identity) {
    const normalize = normalizeWikiItemKey;
    return (Array.isArray(records) ? records : []).find((record) => {
        if (!record || typeof record !== "object") return false;
        if (record.key && record.key === identity.key) return true;
        const sameActor = Boolean(record.actorId && identity.actorId && record.actorId === identity.actorId)
            || Boolean(record.actorName && identity.actorName && normalize(record.actorName) === normalize(identity.actorName));
        const sameAbility = Boolean(record.abilityId && identity.abilityId && record.abilityId === identity.abilityId)
            || Boolean(record.abilityName && identity.abilityName && normalize(record.abilityName) === normalize(identity.abilityName));
        return sameActor && sameAbility;
    }) || null;
}

function findExistingItemOverrideRecord(records, identity) {
    const normalize = normalizeWikiItemKey;
    return (Array.isArray(records) ? records : []).find((record) => {
        if (!record || typeof record !== "object") return false;
        if (record.key && record.key === identity.key) return true;
        const sameActor = Boolean(record.actorId && identity.actorId && record.actorId === identity.actorId)
            || Boolean(record.actorName && identity.actorName && normalize(record.actorName) === normalize(identity.actorName));
        if (record.transferId && identity.transferId && record.transferId === identity.transferId) return true;
        if (sameActor && record.transferKey && identity.transferKey && record.transferKey === identity.transferKey) return true;
        if (sameActor && record.sourceId && identity.sourceId && normalize(record.sourceId) === normalize(identity.sourceId)) return true;
        const sameItem = Boolean(record.itemId && identity.itemId && record.itemId === identity.itemId)
            || Boolean(record.itemName && identity.itemName && normalize(record.itemName) === normalize(identity.itemName));
        return sameActor && sameItem;
    }) || null;
}

function extractWorkerMediaPath(value) {
    const raw = String(value || "").trim();
    if (!raw) return "";
    const clean = raw.split(/[?#]/)[0].replace(/^\/+/, "");
    if (clean.startsWith("media/")) return clean;
    try {
        const url = new URL(raw);
        const workerUrl = new URL(DISCORD_WORKER_URL);
        if (url.origin !== workerUrl.origin) return "";
        const path = url.pathname.replace(/^\/+/, "");
        return path.startsWith("media/") ? path : "";
    } catch (_) {
        return "";
    }
}

function buildPlayerMediaPath(characterId, variant = "avatar") {
    const suffix = variant === "token" ? "-token" : "-avatar";
    const filename = `${slugify(characterId || "personaggio")}${suffix}.webp`;
    const campaignId = getCampaignId();
    return `media/campaigns/${campaignId}/players/${filename}`;
}

function buildReadableAssetSlug(...parts) {
    const seen = new Set();
    const slugs = parts
        .map((part) => slugify(part || ""))
        .filter(Boolean)
        .filter((slug) => {
            if (seen.has(slug)) return false;
            seen.add(slug);
            return true;
        });
    return slugs.join("-") || "asset";
}

function buildCompanionMediaEntityId(ownerCharacterId, actorId, actorName = "") {
    return buildReadableAssetSlug(ownerCharacterId || "personaggio", actorName || "companion", actorId || "");
}

function buildCompanionMediaPath(ownerCharacterId, actorId, variant = "avatar", actorName = "") {
    const entityId = buildCompanionMediaEntityId(ownerCharacterId, actorId, actorName);
    const suffix = variant === "token" ? "-token" : "-avatar";
    const folder = `campaigns/${getCampaignId()}/companions/${slugify(ownerCharacterId || "personaggio")}`;
    return `media/${folder}/${entityId}${suffix}.webp`;
}

function buildCampaignScopedOverrideFolder(kind, ownerId) {
    return `${kind}/${slugify(ownerId || "personaggio")}`;
}

function buildCampaignScopedMediaPath(folder, filename) {
    return `media/campaigns/${getCampaignId()}/${folder}/${filename}`;
}

function isCurrentCampaignMediaPath(mediaPath) {
    const raw = String(mediaPath || "").trim().replace(/^\/+/, "");
    return raw.startsWith(`media/campaigns/${getCampaignId()}/`);
}

function runManagedMediaNetworkTask(task) {
    return new Promise((resolve, reject) => {
        managedMediaNetworkQueue.push({ task, resolve, reject });
        drainManagedMediaNetworkQueue();
    });
}

function drainManagedMediaNetworkQueue() {
    while (managedMediaNetworkActive < MANAGED_MEDIA_NETWORK_LIMIT && managedMediaNetworkQueue.length) {
        const job = managedMediaNetworkQueue.shift();
        managedMediaNetworkActive += 1;
        Promise.resolve()
            .then(job.task)
            .then(job.resolve, job.reject)
            .finally(() => {
                managedMediaNetworkActive -= 1;
                drainManagedMediaNetworkQueue();
            });
    }
}

async function workerMediaPathExists(mediaPath) {
    const raw = String(mediaPath || "").trim().replace(/^\/+/, "");
    if (!raw) return false;
    const cacheKey = `${getCampaignId()}:${raw}`;
    const cached = mediaExistsCache.get(cacheKey);
    if (cached && Date.now() - cached.checkedAt < MEDIA_EXISTS_CACHE_TTL) return cached.exists;
    if (mediaExistsPromises.has(cacheKey)) return mediaExistsPromises.get(cacheKey);

    const promise = runManagedMediaNetworkTask(async () => {
        try {
            const url = new URL(`${DISCORD_WORKER_URL}/${raw}`);
            url.searchParams.set("campaign", getCampaignId());
            url.searchParams.set("exact", "1");
            const response = await fetch(url.toString(), { method: "GET", cache: "no-store" });
            const exists = response.ok;
            mediaExistsCache.set(cacheKey, { exists, checkedAt: Date.now() });
            return exists;
        } catch (_) {
            mediaExistsCache.set(cacheKey, { exists: false, checkedAt: Date.now() });
            return false;
        } finally {
            mediaExistsPromises.delete(cacheKey);
        }
    });
    mediaExistsPromises.set(cacheKey, promise);
    return promise;
}

function markWorkerMediaPathExists(mediaPath, exists = true) {
    const raw = normalizeManagedRemotePath(mediaPath);
    if (!raw) return;
    mediaExistsCache.set(`${getCampaignId()}:${raw}`, { exists: Boolean(exists), checkedAt: Date.now() });
}

function markUploadedWorkerMediaPath(mediaPath) {
    markWorkerMediaPathExists(mediaPath, true);
}

function shouldDownloadManagedFallback(options = {}) {
    return options.downloadFallback === true;
}

function shouldVerifyManagedRemote(options = {}) {
    return options.verifyRemote !== false;
}

function shouldAssumeManagedRemote(options = {}) {
    return options.assumeRemoteAvailable === true || options.verifyRemote === false;
}

function resolveManagedRemoteWithoutCheck(remotePath, localPath = "") {
    const remote = normalizeManagedRemotePath(remotePath);
    if (remote) return resolveWikiAssetUrl(remote);
    return localPath || "";
}

function isManagedFallbackDownloadEnabled(options = {}) {
    return shouldDownloadManagedFallback(options);
}

function normalizeManagedMediaOptions(options = {}) {
    return {
        ...options,
        downloadFallback: isManagedFallbackDownloadEnabled(options),
        verifyRemote: shouldVerifyManagedRemote(options),
        assumeRemoteAvailable: shouldAssumeManagedRemote(options)
    };
}

async function markManagedMediaRemoteIfKnown(remotePath, options = {}) {
    const remote = normalizeManagedRemotePath(remotePath);
    if (!remote) return false;
    if (options.assumeRemoteAvailable) {
        markWorkerMediaPathExists(remote, true);
        return true;
    }
    return workerMediaPathExists(remote);
}

async function getReusableCampaignMediaPath(mediaPath) {
    const raw = normalizeManagedRemotePath(mediaPath);
    if (!isCurrentCampaignMediaPath(raw)) return "";
    return await workerMediaPathExists(raw) ? raw : "";
}

async function copyLegacyMediaPathToCampaign(legacyPath, folder, filename) {
    const raw = normalizeManagedRemotePath(legacyPath) || String(legacyPath || "").trim();
    if (!raw || isCurrentCampaignMediaPath(raw)) return "";
    const targetPath = buildCampaignScopedMediaPath(folder, filename);
    if (await workerMediaPathExists(targetPath)) return targetPath;

    const sourceUrl = raw.startsWith("media/")
        ? `${DISCORD_WORKER_URL.replace(/\/+$/, "")}/${raw}`
        : raw;
    if (!/^https?:/i.test(sourceUrl)) return "";

    const response = await fetch(sourceUrl, { cache: "no-store" });
    if (!response.ok) return "";
    const sourceBlob = await response.blob();
    if (!sourceBlob?.size) return "";
    const blob = sourceBlob.type === "image/webp"
        ? sourceBlob
        : new Blob([await sourceBlob.arrayBuffer()], { type: "image/webp" });
    return await uploadRawMediaBlobToWorker(blob, filename, folder);
}

async function uploadRawMediaBlobToWorker(blob, filename, folder) {
    const token = String(game.settings.get(MODULE_ID, SETTINGS.DISCORD_TOKEN) || "").trim();
    if (!token) throw new Error("Login wiki richiesto.");

    const form = new FormData();
    form.set("folder", folder);
    form.set("filename", filename);
    form.set("campaignId", getCampaignId());
    form.set("file", new File([blob], filename, { type: "image/webp" }));

    const url = new URL(`${DISCORD_WORKER_URL}/media/upload`);
    url.searchParams.set("folder", folder);
    url.searchParams.set("campaign", getCampaignId());

    const response = await fetch(url.toString(), {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: form
    });
    const payload = await response.json().catch(() => null);
    if (!response.ok || payload?.ok === false) throw new Error(payload?.error || `HTTP ${response.status}`);
    validateWorkerMediaUploadPayload(payload, blob, filename);
    const uploadedPath = payload.path || payload.key || buildCampaignScopedMediaPath(folder, filename);
    markUploadedWorkerMediaPath(uploadedPath);
    return uploadedPath;
}

async function imagePathToSquareWebpBlob(imagePath, size) {
    const source = String(imagePath || "").trim();
    if (!source) throw new Error("Immagine mancante.");
    const image = await new Promise((resolve, reject) => {
        const element = new Image();
        if (/^https?:/i.test(source)) element.crossOrigin = "anonymous";
        element.onload = () => resolve(element);
        element.onerror = () => reject(new Error(`Immagine non leggibile: ${source}`));
        element.src = source;
    });
    const canvas = document.createElement("canvas");
    canvas.width = size;
    canvas.height = size;
    const context = canvas.getContext("2d", { alpha: true });
    context.clearRect(0, 0, size, size);

    const imageWidth = image.naturalWidth || image.width;
    const imageHeight = image.naturalHeight || image.height;
    if (!imageWidth || !imageHeight) throw new Error(`Dimensioni immagine non valide: ${source}`);
    const scale = Math.max(size / imageWidth, size / imageHeight);
    const drawWidth = imageWidth * scale;
    const drawHeight = imageHeight * scale;
    const x = (size - drawWidth) / 2;
    const y = (size - drawHeight) / 2;
    context.drawImage(image, x, y, drawWidth, drawHeight);

    return new Promise((resolve, reject) => {
        canvas.toBlob((webpBlob) => {
            if (!webpBlob) {
                reject(new Error("Conversione WebP fallita."));
                return;
            }
            resolve(webpBlob);
        }, "image/webp", 0.86);
    });
}

async function imagePathToWebpBlobPreserveSize(imagePath, quality = 0.96) {
    const source = String(imagePath || "").trim();
    if (!source) throw new Error("Immagine mancante.");
    const image = await new Promise((resolve, reject) => {
        const element = new Image();
        if (/^https?:/i.test(source)) element.crossOrigin = "anonymous";
        element.onload = () => resolve(element);
        element.onerror = () => reject(new Error(`Immagine non leggibile: ${source}`));
        element.src = source;
    });

    const imageWidth = image.naturalWidth || image.width;
    const imageHeight = image.naturalHeight || image.height;
    if (!imageWidth || !imageHeight) throw new Error(`Dimensioni immagine non valide: ${source}`);

    const canvas = document.createElement("canvas");
    canvas.width = imageWidth;
    canvas.height = imageHeight;
    const context = canvas.getContext("2d", { alpha: true });
    context.clearRect(0, 0, imageWidth, imageHeight);
    context.drawImage(image, 0, 0, imageWidth, imageHeight);

    return new Promise((resolve, reject) => {
        canvas.toBlob((webpBlob) => {
            if (!webpBlob) {
                reject(new Error("Conversione WebP fallita."));
                return;
            }
            resolve(webpBlob);
        }, "image/webp", quality);
    });
}

async function imagePathToWebpIconBlob(imagePath) {
    return imagePathToSquareWebpBlob(imagePath, ABILITY_ICON_SYNC_SIZE);
}

async function uploadAbilityIconBlobToWorker(blob, actor, item, characterFolder) {
    const token = String(game.settings.get(MODULE_ID, SETTINGS.DISCORD_TOKEN) || "").trim();
    if (!token) throw new Error("Login wiki richiesto.");

    const folder = buildCampaignScopedOverrideFolder("ability-overrides", actor?.name || characterFolder || actor?.id);
    const filename = `${slugify(item?.name || item?.id || "abilita")}.webp`;
    const form = new FormData();
    form.set("folder", folder);
    form.set("filename", filename);
    form.set("campaignId", getCampaignId());
    form.set("file", new File([blob], filename, { type: "image/webp" }));

    const url = new URL(`${DISCORD_WORKER_URL}/media/upload`);
    url.searchParams.set("folder", folder);
    url.searchParams.set("campaign", getCampaignId());

    const response = await fetch(url.toString(), {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: form
    });
    const payload = await response.json().catch(() => null);
    if (!response.ok || payload?.ok === false) throw new Error(payload?.error || `HTTP ${response.status}`);
    validateWorkerMediaUploadPayload(payload, blob, filename);
    const uploadedPath = payload.path || payload.key || buildCampaignScopedMediaPath(folder, filename);
    markUploadedWorkerMediaPath(uploadedPath);
    return uploadedPath;
}

async function uploadItemIconBlobToWorker(blob, actor, item, characterFolder) {
    const token = String(game.settings.get(MODULE_ID, SETTINGS.DISCORD_TOKEN) || "").trim();
    if (!token) throw new Error("Login wiki richiesto.");

    const folder = buildCampaignScopedOverrideFolder("item-overrides", actor?.name || characterFolder || actor?.id);
    const filename = `${slugify(item?.name || item?.id || "oggetto")}.webp`;
    const form = new FormData();
    form.set("folder", folder);
    form.set("filename", filename);
    form.set("campaignId", getCampaignId());
    form.set("file", new File([blob], filename, { type: "image/webp" }));

    const url = new URL(`${DISCORD_WORKER_URL}/media/upload`);
    url.searchParams.set("folder", folder);
    url.searchParams.set("campaign", getCampaignId());

    const response = await fetch(url.toString(), {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: form
    });
    const payload = await response.json().catch(() => null);
    if (!response.ok || payload?.ok === false) throw new Error(payload?.error || `HTTP ${response.status}`);
    validateWorkerMediaUploadPayload(payload, blob, filename);
    const uploadedPath = payload.path || payload.key || buildCampaignScopedMediaPath(folder, filename);
    markUploadedWorkerMediaPath(uploadedPath);
    return uploadedPath;
}

async function uploadPlayerImageBlobToWorker(blob, filename, folder = "players") {
    const token = String(game.settings.get(MODULE_ID, SETTINGS.DISCORD_TOKEN) || "").trim();
    if (!token) throw new Error("Login wiki richiesto.");

    const form = new FormData();
    form.set("folder", folder);
    form.set("filename", filename);
    form.set("campaignId", getCampaignId());
    form.set("file", new File([blob], filename, { type: "image/webp" }));

    const url = new URL(`${DISCORD_WORKER_URL}/media/upload`);
    url.searchParams.set("folder", folder);
    url.searchParams.set("campaign", getCampaignId());

    const response = await fetch(url.toString(), {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: form
    });
    const payload = await response.json().catch(() => null);
    if (!response.ok || payload?.ok === false) throw new Error(payload?.error || `HTTP ${response.status}`);
    validateWorkerMediaUploadPayload(payload, blob, filename);
    const uploadedPath = payload.path || payload.key || `media/${folder}/${filename}`;
    markUploadedWorkerMediaPath(uploadedPath);
    return uploadedPath;
}

function validateWorkerMediaUploadPayload(payload, blob, filename = "media.webp") {
    const expectedSize = Number(blob?.size || 0);
    const storedSize = Number(payload?.storedSize || payload?.size || 0);
    if (expectedSize > 0 && storedSize > 0 && expectedSize !== storedSize) {
        throw new Error(`Upload R2 non coerente per ${filename}: inviati ${expectedSize} byte, salvati ${storedSize} byte.`);
    }
    if (!payload?.key && !payload?.path) {
        throw new Error(`Upload R2 senza path/key per ${filename}.`);
    }
}

function normalizeManagedRemotePath(value) {
    const remote = extractWorkerMediaPath(value) || String(value || "").trim().split(/[?#]/)[0].replace(/^\/+/, "");
    if (!remote) return "";
    if (remote.startsWith("media/")) return remote;
    if (remote.startsWith("campaigns/")) return `media/${remote}`;
    return "";
}

function buildLocalMediaPathForRemote(remotePath) {
    const remote = normalizeManagedRemotePath(remotePath);
    if (!remote) return "";
    const relative = remote.replace(/^media\//, "");
    const worldId = slugify(game.world?.id || game.world?.title || "world");
    return `worlds/${worldId}/${LOCAL_MEDIA_ROOT}/${relative}`;
}

function normalizeFoundryLocalMediaPath(value) {
    const raw = String(value || "").trim().replace(/\\/g, "/").replace(/^\/+/, "");
    if (!raw || /^https?:|^data:|^blob:/i.test(raw) || normalizeManagedRemotePath(raw)) return "";
    return raw;
}

function getDirectoryPath(filePath) {
    const clean = String(filePath || "").replace(/\\/g, "/").replace(/^\/+|\/+$/g, "");
    const index = clean.lastIndexOf("/");
    return index > 0 ? clean.slice(0, index) : "";
}

function getFilename(filePath) {
    return String(filePath || "").replace(/\\/g, "/").split("/").pop() || "media.webp";
}

async function browseFoundryDataDirectory(directory) {
    const clean = String(directory || "").replace(/\\/g, "/").replace(/^\/+|\/+$/g, "");
    if (!clean) return null;
    const cached = localDirectoryCache.get(clean);
    if (cached && Date.now() - cached.checkedAt < LOCAL_FILE_EXISTS_CACHE_TTL) return cached.files;
    try {
        const result = await FilePicker.browse("data", clean);
        const files = new Set((result?.files || []).map((file) => String(file || "").replace(/\\/g, "/")));
        localDirectoryCache.set(clean, { files, checkedAt: Date.now() });
        return files;
    } catch (_) {
        localDirectoryCache.set(clean, { files: new Set(), checkedAt: Date.now() });
        return null;
    }
}

async function foundryDataFileExists(filePath) {
    const clean = String(filePath || "").trim().replace(/\\/g, "/").replace(/^\/+/, "");
    if (!clean || /^https?:|^data:|^blob:/i.test(clean)) return false;
    const cached = localFileExistsCache.get(clean);
    if (cached && Date.now() - cached.checkedAt < LOCAL_FILE_EXISTS_CACHE_TTL) return cached.exists;
    const directory = getDirectoryPath(clean);
    const filename = getFilename(clean);
    if (!directory || !filename) return false;
    const files = await browseFoundryDataDirectory(directory);
    if (files) {
        const exists = files.has(clean);
        localFileExistsCache.set(clean, { exists, checkedAt: Date.now() });
        return exists;
    }
    localFileExistsCache.set(clean, { exists: false, checkedAt: Date.now() });
    return false;
}

function markFoundryDataFileExists(filePath, exists = true) {
    const clean = String(filePath || "").trim().replace(/\\/g, "/").replace(/^\/+/, "");
    if (!clean) return;
    localFileExistsCache.set(clean, { exists: Boolean(exists), checkedAt: Date.now() });
    const directory = getDirectoryPath(clean);
    const cachedDirectory = localDirectoryCache.get(directory);
    if (cachedDirectory) {
        if (exists) cachedDirectory.files.add(clean);
        else cachedDirectory.files.delete(clean);
        cachedDirectory.checkedAt = Date.now();
    }
}

async function ensureFoundryDataDirectory(directory) {
    const clean = String(directory || "").replace(/\\/g, "/").replace(/^\/+|\/+$/g, "");
    if (!clean) return;
    const parts = clean.split("/").filter(Boolean);
    let current = "";
    for (const part of parts) {
        current = current ? `${current}/${part}` : part;
        if (ensuredFoundryDirectories.has(current)) continue;
        try {
            await FilePicker.createDirectory("data", current, {});
        } catch (_) {
            // Directory gia esistente o non creabile: il browse/upload seguente gestisce l'errore reale.
        }
        ensuredFoundryDirectories.add(current);
    }
}

async function downloadRemoteMediaToLocal(remotePath, localPath = buildLocalMediaPathForRemote(remotePath), options = {}) {
    const remote = normalizeManagedRemotePath(remotePath);
    const local = String(localPath || "").trim().replace(/\\/g, "/").replace(/^\/+/, "");
    if (!remote || !local) return "";
    if (!options.skipLocalCheck && await foundryDataFileExists(local)) return local;

    const blob = await runManagedMediaNetworkTask(async () => {
        const url = new URL(`${DISCORD_WORKER_URL.replace(/\/+$/, "")}/${remote}`);
        url.searchParams.set("campaign", getCampaignId());
        url.searchParams.set("exact", "1");
        const response = await fetch(url.toString(), { cache: "no-store" });
        markWorkerMediaPathExists(remote, response.ok);
        if (!response.ok) return null;
        return response.blob();
    });
    if (!blob?.size) return "";

    const directory = getDirectoryPath(local);
    const filename = getFilename(local);
    await ensureFoundryDataDirectory(directory);
    const type = blob.type || (filename.toLowerCase().endsWith(".webp") ? "image/webp" : "application/octet-stream");
    const file = new File([blob], filename, { type });
    const result = await FilePicker.upload("data", directory, file, {}, { notify: false });
    const uploadedLocalPath = String(result?.path || local).replace(/\\/g, "/");
    markFoundryDataFileExists(uploadedLocalPath, true);
    return uploadedLocalPath;
}

async function getManagedMediaEffectivePath(remotePath, localPath, options = {}) {
    const remote = normalizeManagedRemotePath(remotePath);
    if (remote && shouldAssumeManagedRemote(options)) return resolveWikiAssetUrl(remote);
    if (remote && await workerMediaPathExists(remote)) return resolveWikiAssetUrl(remote);
    if (localPath && await foundryDataFileExists(localPath)) return localPath;
    return "";
}

function getManagedMediaState(document, slot) {
    const media = document?.getFlag?.(MODULE_ID, MANAGED_MEDIA_FLAG) || {};
    return media?.[slot] || {};
}

async function setManagedMediaState(document, slot, patch) {
    if (!document?.setFlag || !slot) return null;
    const media = foundry.utils.deepClone(document.getFlag(MODULE_ID, MANAGED_MEDIA_FLAG) || {});
    const previous = media[slot] || {};
    const next = {
        ...previous,
        ...patch,
    };
    if (JSON.stringify(previous) === JSON.stringify(next)) return previous;
    media[slot] = {
        ...next,
        updatedAt: new Date().toISOString()
    };
    await document.setFlag(MODULE_ID, MANAGED_MEDIA_FLAG, media);
    return media[slot];
}

async function registerManagedMedia(document, slot, {
    remote,
    local = "",
    entityType = "",
    entityId = "",
    actor = null,
    item = null,
    name = "",
    downloadFallback = false,
    activateRemote = true
} = {}) {
    const remotePath = normalizeManagedRemotePath(remote);
    const previous = getManagedMediaState(document, slot);
    const localCandidates = [
        normalizeFoundryLocalMediaPath(local),
        normalizeFoundryLocalMediaPath(previous.local)
    ].filter(Boolean);
    let existingLocal = "";
    for (const candidate of localCandidates) {
        if (await foundryDataFileExists(candidate)) {
            existingLocal = candidate;
            break;
        }
    }
    const preferredLocal = existingLocal || buildLocalMediaPathForRemote(remotePath);
    let localPath = preferredLocal;
    if (remotePath && !existingLocal && downloadFallback) {
        localPath = await downloadRemoteMediaToLocal(remotePath, preferredLocal) || localPath;
    }
    const state = await setManagedMediaState(document, slot, {
        local: localPath || "",
        remote: remotePath || "",
        entityType,
        entityId: String(entityId || "").trim(),
        foundryActorId: actor?.id || item?.actor?.id || "",
        foundryItemId: item?.id || "",
        foundryUuid: item?.uuid || actor?.uuid || document?.uuid || "",
        name: name || item?.name || actor?.name || document?.name || "",
        aliases: Array.from(new Set([previous.name, previous.entityId].filter(Boolean)))
    });
    if (activateRemote && remotePath) await applyManagedRemotePathToDocument(document, slot, remotePath, localPath);
    return state;
}

async function resolveAndRegisterManagedMedia(document, slot, options = {}) {
    const normalizedOptions = normalizeManagedMediaOptions(options);
    if (!normalizeManagedRemotePath(options.remote)) {
        return resolveWikiAssetUrl(options.remote) || options.remote || options.local || "";
    }
    const state = await registerManagedMedia(document, slot, {
        ...normalizedOptions,
        activateRemote: false
    });
    return getManagedMediaEffectivePath(state?.remote, state?.local, normalizedOptions);
}

function getManagedMediaSlotLabel(slot) {
    const value = String(slot || "");
    if (value === "avatar") return "Avatar";
    if (value === "token") return "Token";
    if (value === "image" || value === "icon") return "Immagine";
    if (value.startsWith("transformation:")) return `Trasformazione ${value.slice("transformation:".length)}`;
    return value || "Media";
}

function getDocumentActiveMediaPath(document, slot) {
    const value = String(slot || "");
    if (document?.documentName === "Actor") {
        if (value === "avatar") return String(document.img || "");
        if (value === "token") return String(document.prototypeToken?.texture?.src || document.prototypeToken?.img || "");
    }
    if (document?.documentName === "Item" && (value === "image" || value === "icon")) {
        return String(document.img || "");
    }
    return "";
}

function getManagedMediaEntriesForDialog(document) {
    const media = document?.getFlag?.(MODULE_ID, MANAGED_MEDIA_FLAG) || {};
    return Object.entries(media)
        .filter(([, value]) => value && typeof value === "object" && (value.remote || value.local))
        .map(([slot, value]) => ({
            slot,
            label: getManagedMediaSlotLabel(slot),
            active: getDocumentActiveMediaPath(document, slot),
            remote: String(value.remote || ""),
            local: String(value.local || ""),
            entityType: String(value.entityType || ""),
            entityId: String(value.entityId || ""),
            updatedAt: String(value.updatedAt || "")
        }))
        .sort((left, right) => left.label.localeCompare(right.label, "it"));
}

function renderManagedMediaPathLine(label, value, { primary = false } = {}) {
    const path = String(value || "").trim();
    return `
        <div class="cripta-media-path-line${primary ? " is-primary" : ""}">
            <span>${escapeHtml(label)}</span>
            <code title="${escapeHtml(path)}">${path ? escapeHtml(path) : "-"}</code>
            ${path ? `<button type="button" data-copy-managed-media-path="${escapeHtml(path)}" title="Copia path"><i class="fas fa-copy"></i></button>` : ""}
        </div>
    `;
}

function renderManagedMediaPathsDialogContent(document, entries) {
    const rows = entries.map((entry) => `
        <section class="cripta-media-path-entry">
            <header>
                <strong>${escapeHtml(entry.label)}</strong>
                <small>${escapeHtml([entry.entityType, entry.entityId].filter(Boolean).join(" / "))}</small>
            </header>
            ${renderManagedMediaPathLine("DB/R2 canonico", entry.remote, { primary: true })}
            ${renderManagedMediaPathLine("Locale fallback", entry.local)}
            ${renderManagedMediaPathLine("Attivo in Foundry", entry.active)}
        </section>
    `).join("");

    return `
        <div class="cripta-media-paths-dialog">
            <p>I path DB/R2 sono quelli canonici della wiki; il locale e il path attivo servono come contesto e fallback.</p>
            ${entries.length ? '<button type="button" class="cripta-media-paths-use-r2" data-use-managed-media-r2><i class="fas fa-cloud"></i> Usa path R2 su questo elemento</button>' : ""}
            <div class="cripta-media-paths-list">
                ${rows || "<p>Nessun path media gestito su questo elemento.</p>"}
            </div>
        </div>
    `;
}

function openManagedMediaPathsDialog(document) {
    const entries = getManagedMediaEntriesForDialog(document);
    let dialog;
    dialog = new Dialog({
        title: `Path R2 - ${document?.name || "Elemento"}`,
        content: renderManagedMediaPathsDialogContent(document, entries),
        buttons: {
            close: {
                icon: '<i class="fas fa-xmark"></i>',
                label: "Chiudi"
            }
        },
        render: (html) => {
            const root = html instanceof HTMLElement ? html : html?.[0];
            root?.querySelectorAll?.("[data-copy-managed-media-path]").forEach((button) => {
                button.addEventListener("click", async () => {
                    const value = button.dataset.copyManagedMediaPath || "";
                    try {
                        await navigator.clipboard?.writeText(value);
                        ui.notifications.info("Path copiato.");
                    } catch (_) {
                        ui.notifications.warn(value);
                    }
                });
            });
            root?.querySelector?.("[data-use-managed-media-r2]")?.addEventListener("click", async () => {
                suppressCharacterSync = true;
                try {
                    const updated = await applyManagedRemotePathsForDocument(document);
                    ui.notifications.info(`Path R2 applicati: ${updated}.`);
                } finally {
                    suppressCharacterSync = false;
                }
                dialog.close();
                window.setTimeout(() => openManagedMediaPathsDialog(document), 100);
            });
        }
    }, {
        width: 720,
        classes: ["cripta-media-paths-window"]
    }).render(true);
}

function addManagedMediaHeaderButton(document, buttons) {
    if (!game.user?.isGM || !document || !buttons) return;
    if (!getManagedMediaEntriesForDialog(document).length) return;
    buttons.unshift({
        label: "Path R2",
        class: "cripta-managed-media-paths",
        icon: "fas fa-images",
        onclick: () => openManagedMediaPathsDialog(document)
    });
}

function addPlayerSkillTreeHeaderButton(actor, buttons) {
    if (!actor || !buttons) return;
    const entries = getPlayerSkillTreeEntriesForActor(actor);
    if (!entries.length) return;
    buttons.unshift({
        label: entries.length > 1 ? "Alberi" : "Albero",
        class: "cripta-open-skill-tree",
        icon: "fas fa-crown",
        onclick: () => openPlayerSkillTreeForActor(actor).catch((error) => {
            ui.notifications.warn(error?.message || String(error || "Albero abilita non disponibile."));
        })
    });
}

function getItemProgressMaterialsText(materials) {
    return normalizeItemProgressMaterials(materials)
        .map((material) => [
            material.name || material.id || "",
            material.done ?? 0,
            material.required ?? 0,
            material.unit || ""
        ].join(" | "))
        .join("\n");
}

function parseItemProgressMaterialsText(text) {
    return String(text || "")
        .split(/\r?\n/)
        .map((line) => line.trim())
        .filter(Boolean)
        .map((line) => {
            const parts = line.split("|").map((part) => part.trim());
            const name = parts[0] || "";
            const done = toNumberOrNull(parts[1]) ?? 0;
            const required = toNumberOrNull(parts[2]) ?? 0;
            const unit = parts[3] || "";
            if (!name && required <= 0) return null;
            return compactObject({
                name,
                done: Math.max(0, done),
                required: Math.max(0, required),
                unit
            });
        })
        .filter(Boolean);
}

function renderItemProgressDialogContent(item) {
    const progress = getItemProgress(item) || { label: "Progresso", done: 0, total: "", unit: "", materials: [] };
    return `
        <form class="cripta-item-progress-dialog">
            <div class="form-group">
                <label>Etichetta</label>
                <input type="text" name="label" value="${escapeHtml(progress.label || "Progresso")}">
            </div>
            <div class="form-group">
                <label>Fatto</label>
                <input type="number" step="0.01" min="0" name="done" value="${escapeHtml(String(progress.done ?? 0))}">
            </div>
            <div class="form-group">
                <label>Totale</label>
                <input type="number" step="0.01" min="0" name="total" value="${escapeHtml(String(progress.total ?? ""))}">
            </div>
            <div class="form-group">
                <label>Unita</label>
                <input type="text" name="unit" value="${escapeHtml(progress.unit || "")}">
            </div>
            <div class="form-group stacked">
                <label>Materiali richiesti</label>
                <textarea name="materials" rows="5" placeholder="Nome | ottenuti | richiesti | unita">${escapeHtml(getItemProgressMaterialsText(progress.materials))}</textarea>
                <p class="notes">Una riga per materiale. Gli oggetti con materiali vengono mostrati come craft nella wiki.</p>
            </div>
        </form>
    `;
}

function getDialogFormRoot(html) {
    const root = html instanceof HTMLElement ? html : html?.[0];
    return root?.querySelector?.(".cripta-item-progress-dialog") || root || null;
}

function collectItemProgressDialogDraft(html) {
    const form = getDialogFormRoot(html);
    if (!form) return null;
    const read = (name) => String(form.querySelector(`[name="${name}"]`)?.value || "").trim();
    const done = toNumberOrNull(read("done")) ?? 0;
    const total = toNumberOrNull(read("total"));
    if (total === null || total <= 0) return null;
    const materials = parseItemProgressMaterialsText(read("materials"));
    return compactObject({
        label: read("label") || "Progresso",
        done: Math.max(0, done),
        total: Math.max(1, total),
        unit: read("unit"),
        crafting: materials.length > 0,
        materials
    });
}

async function syncItemProgressOverrideToWiki(item, progress) {
    const actor = item?.actor;
    if (!game.user?.isGM || !actor || !item) return false;
    if (!isConfiguredPlayerActor(actor) && !isConfiguredCompanionActor(actor)) return false;

    await ensureItemTransferId(item);
    const payload = await requestNotesApi("api/data/item-overrides");
    const records = Array.isArray(payload?.data) ? payload.data : [];
    const expectedVersion = payload?.source === "kv" ? (payload.version ?? 0) : 0;
    const identity = getItemOverrideIdentityForItem(actor, item);
    const existing = findExistingItemOverrideRecord(records, identity);
    const nextProgress = progress ? normalizeItemProgressDraft(progress) : null;
    const record = {
        ...(existing || {}),
        id: existing?.id || identity.key,
        key: existing?.key || identity.key,
        actorId: identity.actorId,
        actorName: identity.actorName,
        itemUuid: identity.itemUuid,
        transferId: identity.transferId,
        sourceId: identity.sourceId,
        transferKey: identity.transferKey,
        itemId: identity.itemId,
        itemName: identity.itemName,
        itemType: identity.itemType,
        progress: nextProgress,
        updatedAt: new Date().toISOString()
    };
    const nextRecords = existing
        ? records.map((entry) => entry === existing ? record : entry)
        : [...records, record];
    nextRecords.sort((left, right) => {
        const actorSort = String(left.actorName || left.characterName || "").localeCompare(String(right.actorName || right.characterName || ""), "it");
        if (actorSort !== 0) return actorSort;
        return String(left.itemName || "").localeCompare(String(right.itemName || ""), "it");
    });
    await requestNotesApi("api/data/item-overrides", {
        method: "POST",
        body: {
            data: nextRecords,
            expectedVersion
        }
    });
    return true;
}

async function saveItemProgressFlag(item, progress) {
    if (!item) return;
    if (progress) await item.setFlag(MODULE_ID, "progress", progress);
    else await item.unsetFlag(MODULE_ID, "progress");
    try {
        await syncItemProgressOverrideToWiki(item, progress);
    } catch (error) {
        console.warn(`${MODULE_ID} | Progresso oggetto non sincronizzato verso wiki.`, { item: item.name, error });
        ui.notifications.warn(`Progresso salvato in Foundry, ma non aggiornato sul sito: ${error?.message || error}`);
    }
    if (isConfiguredPlayerActor(item.actor) || isConfiguredCompanionActor(item.actor)) scheduleCharacterSync("itemProgress");
}

function getItemLoadoutRole(item) {
    const value = String(item?.getFlag?.(MODULE_ID, ITEM_LOADOUT_ROLE_FLAG) || item?.flags?.[MODULE_ID]?.[ITEM_LOADOUT_ROLE_FLAG] || "").trim().toLowerCase();
    return ITEM_LOADOUT_ROLE_OPTIONS.has(value) ? value : "";
}

function getItemLoadoutSubtype(item) {
    const value = String(item?.getFlag?.(MODULE_ID, ITEM_LOADOUT_SUBTYPE_FLAG) || item?.flags?.[MODULE_ID]?.[ITEM_LOADOUT_SUBTYPE_FLAG] || "").trim().toLowerCase();
    return ITEM_LOADOUT_SUBTYPE_OPTIONS.has(value) ? value : "";
}

function renderItemLoadoutRoleDialogContent(item) {
    const role = getItemLoadoutRole(item);
    const subtype = getItemLoadoutSubtype(item);
    const selected = subtype === "attack" ? "attack" : role;
    const option = (value, label) => `<option value="${escapeHtml(value)}" ${selected === value ? "selected" : ""}>${escapeHtml(label)}</option>`;
    return `
        <form class="cripta-item-progress-dialog">
            <label>
                <span>Sezione sito</span>
                <select name="role">
                    ${option("", "Automatico Foundry")}
                    ${option("inventory", "Inventario")}
                    ${option("ability", "Abilita")}
                    ${option("attack", "Attacco")}
                </select>
            </label>
            <p class="notes">Usa Attacco per oggetti Foundry come Unarmed Attack che devono comparire tra le abilita del personaggio.</p>
        </form>
    `;
}

function collectItemLoadoutRoleDialogDraft(html) {
    const root = html instanceof HTMLElement ? html : html?.[0];
    const value = String(root?.querySelector?.('[name="role"]')?.value || "").trim();
    if (value === "attack") return { role: "ability", subtype: "attack" };
    if (value === "ability") return { role: "ability", subtype: "" };
    if (value === "inventory") return { role: "inventory", subtype: "" };
    return { role: "", subtype: "" };
}

async function saveItemLoadoutRoleFlags(item, draft) {
    if (!item) return;
    const role = String(draft?.role || "").trim();
    const subtype = String(draft?.subtype || "").trim();
    if (role) await item.setFlag(MODULE_ID, ITEM_LOADOUT_ROLE_FLAG, role);
    else await item.unsetFlag(MODULE_ID, ITEM_LOADOUT_ROLE_FLAG);
    if (subtype) await item.setFlag(MODULE_ID, ITEM_LOADOUT_SUBTYPE_FLAG, subtype);
    else await item.unsetFlag(MODULE_ID, ITEM_LOADOUT_SUBTYPE_FLAG);
    if (isConfiguredPlayerActor(item.actor) || isConfiguredCompanionActor(item.actor)) scheduleCharacterSync("itemLoadoutRole");
}

function openItemLoadoutRoleDialog(item) {
    if (!game.user?.isGM || !item) return;
    new Dialog({
        title: `Sezione sito - ${item.name || "Oggetto"}`,
        content: renderItemLoadoutRoleDialogContent(item),
        buttons: {
            save: {
                label: "Salva",
                callback: async (html) => {
                    await saveItemLoadoutRoleFlags(item, collectItemLoadoutRoleDialogDraft(html));
                    ui.notifications.info("Sezione sito dell'item aggiornata.");
                    return true;
                }
            },
            clear: {
                label: "Automatico",
                callback: async () => {
                    await saveItemLoadoutRoleFlags(item, { role: "", subtype: "" });
                    ui.notifications.info("Sezione sito dell'item ripristinata su automatico.");
                }
            },
            cancel: {
                label: "Annulla"
            }
        },
        default: "save"
    }, {
        width: 420
    }).render(true);
}

function openItemProgressDialog(item) {
    if (!game.user?.isGM || !item) return;
    new Dialog({
        title: `Progresso - ${item.name || "Oggetto"}`,
        content: renderItemProgressDialogContent(item),
        buttons: {
            save: {
                label: "Salva",
                callback: async (html) => {
                    const progress = collectItemProgressDialogDraft(html);
                    if (!progress) {
                        ui.notifications.warn("Imposta un totale maggiore di zero.");
                        return false;
                    }
                    await saveItemProgressFlag(item, progress);
                    ui.notifications.info("Progresso oggetto salvato.");
                    return true;
                }
            },
            clear: {
                label: "Rimuovi",
                callback: async () => {
                    await saveItemProgressFlag(item, null);
                    ui.notifications.info("Progresso oggetto rimosso.");
                }
            },
            cancel: {
                label: "Annulla"
            }
        },
        default: "save"
    }, {
        width: 520
    }).render(true);
}

function addItemProgressHeaderButton(item, buttons) {
    if (!game.user?.isGM || !item?.actor || !buttons) return;
    buttons.unshift({
        label: "Progresso",
        class: "cripta-item-progress",
        icon: "fas fa-bars-progress",
        onclick: () => openItemProgressDialog(item)
    });
}

function addItemLoadoutRoleHeaderButton(item, buttons) {
    if (!game.user?.isGM || !item?.actor || !buttons) return;
    const role = getItemLoadoutRole(item);
    const subtype = getItemLoadoutSubtype(item);
    const label = subtype === "attack" ? "Sito: Attacco" : role === "ability" ? "Sito: Abilita" : role === "inventory" ? "Sito: Inventario" : "Sito";
    buttons.unshift({
        label,
        class: "cripta-item-loadout-role",
        icon: subtype === "attack" ? "fas fa-hand-fist" : role === "ability" ? "fas fa-bolt" : "fas fa-layer-group",
        onclick: () => openItemLoadoutRoleDialog(item)
    });
}

function normalizeWikiDataList(payload) {
    return Array.isArray(payload?.data)
        ? payload.data
        : Array.isArray(payload)
            ? payload
            : [];
}

async function loadManagedMediaBootstrapCollection(collection) {
    try {
        const payload = await requestNotesApi(`api/data/${collection}`);
        return { collection, data: normalizeWikiDataList(payload), source: "kv" };
    } catch (_) {
        // Il bootstrap puo lavorare anche senza KV se esiste il JSON statico.
    }

    try {
        const response = await fetch(getSiteDataUrl(`${collection}.json`), {
            method: "GET",
            headers: { Accept: "application/json" },
            cache: "no-cache"
        });
        if (!response.ok) return { collection, data: [], source: "missing" };
        return { collection, data: normalizeWikiDataList(await response.json()), source: "static" };
    } catch (_) {
        return { collection, data: [], source: "missing" };
    }
}

function isDownloadableManagedMediaPath(path) {
    const remote = normalizeManagedRemotePath(path);
    return Boolean(remote && /\.(webp|png|jpe?g|gif)(?:[?#]|$)/i.test(remote));
}

function addManagedMediaPath(paths, value, source = "") {
    const remote = normalizeManagedRemotePath(value);
    if (!isDownloadableManagedMediaPath(remote)) return;
    if (!paths.has(remote)) paths.set(remote, { remote, sources: new Set() });
    if (source) paths.get(remote).sources.add(source);
}

function collectManagedMediaPathsFromString(paths, value, source = "") {
    const raw = String(value || "").trim();
    if (!raw) return;
    addManagedMediaPath(paths, raw, source);
    const mediaMatches = raw.match(/\b(?:media|campaigns)\/[^\s"'<>)]*/gi) || [];
    mediaMatches.forEach((match) => addManagedMediaPath(paths, match.replace(/[.,;:]+$/g, ""), source));
    const urlMatches = raw.match(/https?:\/\/[^\s"'<>)]*\/media\/[^\s"'<>)]*/gi) || [];
    urlMatches.forEach((match) => addManagedMediaPath(paths, match.replace(/[.,;:]+$/g, ""), source));
}

function collectManagedMediaPathsFromValue(paths, value, source = "") {
    if (!value) return;
    if (typeof value === "string") {
        collectManagedMediaPathsFromString(paths, value, source);
        return;
    }
    if (Array.isArray(value)) {
        value.forEach((entry, index) => collectManagedMediaPathsFromValue(paths, entry, `${source}[${index}]`));
        return;
    }
    if (typeof value === "object") {
        Object.entries(value).forEach(([key, entry]) => collectManagedMediaPathsFromValue(paths, entry, source ? `${source}.${key}` : key));
    }
}

function addExpectedConfiguredActorMediaPaths(paths) {
    getPlayerActorsForWikiSync().forEach((actor) => {
        const characterId = getConfiguredCharacterIdForActor(actor);
        if (!characterId) return;
        addManagedMediaPath(paths, buildPlayerMediaPath(characterId, "avatar"), `${actor.name}.avatar`);
        addManagedMediaPath(paths, buildPlayerMediaPath(characterId, "token"), `${actor.name}.token`);
    });

    parseCompanionMappings().forEach((mapping) => {
        const actor = getConfiguredActor(mapping.actorId || mapping.actorName);
        const ownerCharacterId = slugify(mapping.ownerCharacterId || "");
        if (!actor || !ownerCharacterId) return;
        addManagedMediaPath(paths, buildCompanionMediaPath(ownerCharacterId, actor.id, "avatar", actor.name), `${actor.name}.avatar`);
        addManagedMediaPath(paths, buildCompanionMediaPath(ownerCharacterId, actor.id, "token", actor.name), `${actor.name}.token`);
    });
}

async function collectManagedMediaBootstrapPaths() {
    const collections = [
        "players",
        "media-overrides",
        "ability-overrides",
        "item-overrides",
        "characters",
        "bestiary",
        "transformations"
    ];
    const paths = new Map();
    const loadedCollections = await Promise.all(collections.map((collection) => loadManagedMediaBootstrapCollection(collection)));
    loadedCollections.forEach((loaded) => collectManagedMediaPathsFromValue(paths, loaded.data, loaded.collection));

    game.actors.forEach((actor) => {
        collectManagedMediaPathsFromValue(paths, actor.getFlag?.(MODULE_ID, MANAGED_MEDIA_FLAG), `actor:${actor.name}`);
        collectManagedMediaPathsFromString(paths, actor.img, `actor:${actor.name}.img`);
        collectManagedMediaPathsFromString(paths, actor.prototypeToken?.texture?.src, `actor:${actor.name}.token`);
        actor.items?.forEach?.((item) => {
            collectManagedMediaPathsFromValue(paths, item.getFlag?.(MODULE_ID, MANAGED_MEDIA_FLAG), `item:${actor.name}.${item.name}`);
            collectManagedMediaPathsFromString(paths, item.img, `item:${actor.name}.${item.name}.img`);
        });
    });
    addExpectedConfiguredActorMediaPaths(paths);

    return { paths, loadedCollections };
}

async function runLimitedTasks(entries, limit, worker) {
    const results = new Array(entries.length);
    let nextIndex = 0;
    const workers = Array.from({ length: Math.min(Math.max(1, limit), entries.length) }, async () => {
        while (nextIndex < entries.length) {
            const index = nextIndex;
            nextIndex += 1;
            results[index] = await worker(entries[index], index);
        }
    });
    await Promise.all(workers);
    return results;
}

function getBootstrapCollectionData(loadedCollections, collection) {
    return loadedCollections.find((entry) => entry.collection === collection)?.data || [];
}

function findActorForWikiMediaRecord(record, { npcFlag = "", bestiaryFlag = "" } = {}) {
    const foundry = record?.foundry || {};
    const actorId = normalizeActorRef(foundry.actorId || record?.actorId || record?.foundryActorId || "");
    const actorUuid = String(foundry.actorUuid || record?.actorUuid || record?.foundryActorUuid || "").trim();
    if (actorId && game.actors.get(actorId)) return game.actors.get(actorId);
    if (actorUuid) {
        const byUuid = game.actors.find((actor) => actor.uuid === actorUuid);
        if (byUuid) return byUuid;
    }
    const recordId = String(record?.id || record?.entityId || "").trim();
    if (npcFlag && recordId) {
        const byFlag = game.actors.find((actor) => String(actor.getFlag?.(MODULE_ID, npcFlag) || "") === recordId);
        if (byFlag) return byFlag;
    }
    if (bestiaryFlag && recordId) {
        const byFlag = game.actors.find((actor) => String(actor.getFlag?.(MODULE_ID, bestiaryFlag) || "") === recordId);
        if (byFlag) return byFlag;
    }
    const names = [
        record?.name,
        record?.foundryName,
        ...(Array.isArray(record?.foundryName) ? record.foundryName : []),
        ...(Array.isArray(record?.aliases) ? record.aliases : [])
    ].map(normalizeWikiItemKey).filter(Boolean);
    return game.actors.find((actor) => names.includes(normalizeWikiItemKey(actor.name))) || null;
}

function findPlayerActorForBootstrap(record) {
    const entityId = normalizeWikiItemKey(record?.id || record?.entityId || record?.characterId || "");
    if (!entityId) return null;
    const mapping = parsePlayerActorMappings().find((entry) => normalizeWikiItemKey(entry.ownerCharacterId) === entityId);
    const mapped = getConfiguredActor(mapping?.actorRef);
    if (mapped) return mapped;
    return getPlayerActorsForWikiSync().find((actor) => normalizeWikiItemKey(getConfiguredCharacterIdForActor(actor)) === entityId) || null;
}

async function applyManagedRemotePathToDocument(document, slot, remote, local) {
    const remotePath = normalizeManagedRemotePath(remote);
    if (!document || !remotePath) return false;
    const activeRemotePath = resolveWikiAssetUrl(remotePath);

    if (slot === "avatar" && document.documentName === "Actor") {
        const current = String(document.img || "");
        if (current === activeRemotePath) return false;
        await document.update({ img: activeRemotePath });
        return true;
    }

    if (slot === "token" && document.documentName === "Actor") {
        const current = document.prototypeToken?.texture?.src || document.prototypeToken?.img || "";
        if (current === activeRemotePath) return false;
        await document.update({ "prototypeToken.texture.src": activeRemotePath });
        return true;
    }

    if ((slot === "image" || slot === "icon") && document.documentName === "Item") {
        const current = String(document.img || "");
        if (current === activeRemotePath) return false;
        await document.update({ img: activeRemotePath });
        return true;
    }

    return false;
}

async function applyManagedRemotePathsForDocument(document) {
    let updated = 0;
    for (const entry of getManagedMediaEntriesForDialog(document)) {
        if (await applyManagedRemotePathToDocument(document, entry.slot, entry.remote, entry.local)) updated += 1;
    }
    return updated;
}

async function applyManagedRemotePathsFromExistingFlags() {
    let updated = 0;
    for (const actor of game.actors || []) {
        updated += await applyManagedRemotePathsForDocument(actor);
        for (const item of actor.items || []) {
            updated += await applyManagedRemotePathsForDocument(item);
        }
    }
    return updated;
}

async function ensureManagedRemotePathsActive({ notify = false } = {}) {
    suppressCharacterSync = true;
    try {
        const updated = await applyManagedRemotePathsFromExistingFlags();
        if (notify) ui.notifications.info(`Path R2 attivati: ${updated}.`);
        if (updated) console.info(`${MODULE_ID} | Path R2 attivati dai flag managedMedia.`, { updated });
        return updated;
    } finally {
        suppressCharacterSync = false;
    }
}

async function registerManagedMediaBootstrapFlags(loadedCollections, localByRemote) {
    let registered = 0;
    let remoteActivated = 0;
    const registerIfPossible = async (document, slot, options) => {
        const remote = normalizeManagedRemotePath(options.remote);
        if (!document || !remote) return;
        const local = localByRemote.get(remote) || options.local || "";
        await registerManagedMedia(document, slot, {
            ...options,
            remote,
            local,
            downloadFallback: false,
            activateRemote: false
        });
        registered += 1;
        if (await applyManagedRemotePathToDocument(document, slot, remote, local)) remoteActivated += 1;
    };

    for (const record of getBootstrapCollectionData(loadedCollections, "players")) {
        const actor = findPlayerActorForBootstrap(record);
        if (!actor) continue;
        const images = record.images || record;
        await registerIfPossible(actor, "avatar", { remote: images.avatar || images.portrait, entityType: "player", entityId: record.id, actor, name: record.name });
        await registerIfPossible(actor, "token", { remote: images.token, entityType: "player", entityId: record.id, actor, name: record.name });
    }

    for (const record of getBootstrapCollectionData(loadedCollections, "media-overrides")) {
        const actor = record.entityType === "companion"
            ? resolveCompanionActorForMediaOverride(record)
            : await resolvePlayerActorForMediaOverride(record);
        if (!actor) continue;
        await registerIfPossible(actor, "avatar", { remote: record.images?.avatar || record.images?.portrait, entityType: record.entityType || "player", entityId: record.entityId || record.id, actor, name: record.name });
        await registerIfPossible(actor, "token", { remote: record.images?.token, entityType: record.entityType || "player", entityId: record.entityId || record.id, actor, name: record.name });
    }

    for (const record of getBootstrapCollectionData(loadedCollections, "ability-overrides")) {
        const actor = resolveActorFromAssetRecord(record);
        const item = actor ? resolveItemFromAssetRecord(actor, record) : null;
        await registerIfPossible(item, "image", { remote: record.image, entityType: "ability", entityId: record.key || record.id, actor, item, name: record.abilityName || record.itemName });
    }

    for (const record of getBootstrapCollectionData(loadedCollections, "item-overrides")) {
        const actor = resolveActorFromAssetRecord(record);
        const item = actor ? resolveItemFromAssetRecord(actor, record) : null;
        await registerIfPossible(item, "image", { remote: record.image, entityType: "item", entityId: record.key || record.id, actor, item, name: record.itemName });
    }

    for (const record of getBootstrapCollectionData(loadedCollections, "characters")) {
        const actor = findActorForWikiMediaRecord(record, { npcFlag: "wikiNpcId" });
        if (!actor) continue;
        await registerIfPossible(actor, "avatar", { remote: record.images?.avatar || record.images?.portrait, entityType: "npc", entityId: record.id, actor, name: record.name });
        await registerIfPossible(actor, "token", { remote: record.images?.token, entityType: "npc", entityId: record.id, actor, name: record.name });
    }

    for (const record of getBootstrapCollectionData(loadedCollections, "bestiary")) {
        const actor = findActorForWikiMediaRecord(record, { bestiaryFlag: "wikiBestiaryId" });
        if (!actor) continue;
        await registerIfPossible(actor, "avatar", { remote: record.image, entityType: "bestiary", entityId: record.id, actor, name: record.name });
        await registerIfPossible(actor, "token", { remote: record.tokenImage || record.image, entityType: "bestiary", entityId: record.id, actor, name: record.name });
    }

    for (const record of getBootstrapCollectionData(loadedCollections, "transformations")) {
        const actor = findActorForTransformation(normalizeTransformationOverrides([record])[0] || record);
        if (!actor) continue;
        await registerIfPossible(actor, `transformation:${record.id}`, { remote: record.tokenImage, entityType: "transformation", entityId: record.id, actor, name: record.name || record.creatureName });
    }

    return { registered, remoteActivated };
}

async function bootstrapManagedMediaFallbacksFromR2({ notify = false } = {}) {
    if (!game.user?.isGM) {
        ui.notifications.warn("Solo il GM puo popolare i fallback locali.");
        return false;
    }

    const confirmed = await Dialog.confirm({
        title: "Popola fallback locali",
        content: `
            <div>
                <p>Scarica in locale le immagini R2 gia referenziate dalla wiki e dai flag Foundry.</p>
                <p>Non carica nulla su R2, non scrive KV e non cancella file locali.</p>
            </div>
        `,
        yes: () => true,
        no: () => false,
        defaultYes: false
    });
    if (!confirmed) return false;

    const { paths, loadedCollections } = await collectManagedMediaBootstrapPaths();
    const entries = Array.from(paths.values()).sort((left, right) => left.remote.localeCompare(right.remote));
    let existing = 0;
    let downloaded = 0;
    let missing = 0;
    let failed = 0;
    const localByRemote = new Map();

    await runLimitedTasks(entries, MANAGED_MEDIA_BOOTSTRAP_LIMIT, async (entry) => {
        const localPath = buildLocalMediaPathForRemote(entry.remote);
        try {
            const hadLocal = await foundryDataFileExists(localPath);
            if (hadLocal) {
                localByRemote.set(entry.remote, localPath);
                existing += 1;
                return;
            }
            const result = await downloadRemoteMediaToLocal(entry.remote, localPath, { skipLocalCheck: true });
            if (result) {
                localByRemote.set(entry.remote, result);
                downloaded += 1;
            } else {
                missing += 1;
            }
        } catch (error) {
            failed += 1;
            console.warn(`${MODULE_ID} | Fallback locale non scaricato.`, { path: entry.remote, error });
        }
    });

    let bootstrapFlags = { registered: 0, remoteActivated: 0 };
    suppressCharacterSync = true;
    try {
        bootstrapFlags = await registerManagedMediaBootstrapFlags(loadedCollections, localByRemote);
        bootstrapFlags.remoteActivated += await applyManagedRemotePathsFromExistingFlags();
    } finally {
        suppressCharacterSync = false;
    }
    const registered = bootstrapFlags.registered || 0;
    const remoteActivated = bootstrapFlags.remoteActivated || 0;
    const message = `Fallback locali: ${downloaded} scaricati, ${existing} gia presenti, ${missing} mancanti, ${failed} errori, ${registered} flag aggiornati, ${remoteActivated} path Foundry su R2.`;
    if (notify) ui.notifications.info(message);
    console.info(`${MODULE_ID} | Bootstrap fallback locali completato.`, { downloaded, existing, missing, failed, registered, remoteActivated, total: entries.length });
    return true;
}

async function syncCharacterImagesToWiki({ actors = null, notify = false } = {}) {
    if (!game.user?.isGM) {
        if (notify) ui.notifications.warn("Solo il GM puo sincronizzare immagini personaggi verso la wiki.");
        return false;
    }

    const playerActors = Array.isArray(actors)
        ? actors
        : getPlayerActorsForWikiSync();
    let uploaded = 0;
    let existing = 0;
    let skipped = 0;
    const errors = [];

    for (const actor of playerActors) {
        const characterId = getConfiguredCharacterIdForActor(actor) || await resolveWikiCharacterIdForActor(actor);
        const imageJobs = [
            { variant: "avatar", source: actor.img },
            { variant: "token", source: actor?.prototypeToken?.texture?.src || actor?.prototypeToken?.img }
        ];

        for (const job of imageJobs) {
            const mediaPath = buildPlayerMediaPath(characterId, job.variant);
            const filename = `${slugify(characterId)}${job.variant === "token" ? "-token" : "-avatar"}.webp`;
            try {
                if (await workerMediaPathExists(mediaPath)) {
                    await registerManagedMedia(actor, job.variant, {
                        remote: mediaPath,
                        local: job.source,
                        entityType: "player",
                        entityId: characterId,
                        actor
                    });
                    existing += 1;
                    continue;
                }
                if (!String(job.source || "").trim()) {
                    skipped += 1;
                    continue;
                }
                const blob = job.variant === "avatar"
                    ? await imagePathToWebpBlobPreserveSize(job.source)
                    : await imagePathToSquareWebpBlob(job.source, CHARACTER_IMAGE_SYNC_SIZE);
                const uploadedPath = await uploadPlayerImageBlobToWorker(blob, filename);
                await registerManagedMedia(actor, job.variant, {
                    remote: uploadedPath,
                    local: job.source,
                    entityType: "player",
                    entityId: characterId,
                    actor
                });
                uploaded += 1;
            } catch (error) {
                skipped += 1;
                errors.push({ actor: actor.name, variant: job.variant, source: job.source, error: String(error?.message || error) });
            }
        }
    }

    const companionMappings = parseCompanionMappings();
    for (const mapping of companionMappings) {
        const actor = getConfiguredActor(mapping.actorId || mapping.actorName);
        const ownerCharacterId = slugify(mapping.ownerCharacterId || "");
        if (!actor || !ownerCharacterId) {
            skipped += 1;
            continue;
        }
        const imageJobs = [
            { variant: "avatar", source: actor.img },
            { variant: "token", source: actor?.prototypeToken?.texture?.src || actor?.prototypeToken?.img }
        ];

        for (const job of imageJobs) {
            const actorName = actor.name || actor.prototypeToken?.name || "companion";
            const mediaPath = buildCompanionMediaPath(ownerCharacterId, actor.id, job.variant, actorName);
            const entityId = buildCompanionMediaEntityId(ownerCharacterId, actor.id, actorName);
            const filename = `${entityId}${job.variant === "token" ? "-token" : "-avatar"}.webp`;
            try {
                if (await workerMediaPathExists(mediaPath)) {
                    await registerManagedMedia(actor, job.variant, {
                        remote: mediaPath,
                        local: job.source,
                        entityType: "companion",
                        entityId,
                        actor
                    });
                    existing += 1;
                    continue;
                }
                if (!String(job.source || "").trim()) {
                    skipped += 1;
                    continue;
                }
                const blob = job.variant === "avatar"
                    ? await imagePathToWebpBlobPreserveSize(job.source)
                    : await imagePathToSquareWebpBlob(job.source, CHARACTER_IMAGE_SYNC_SIZE);
                const uploadedPath = await uploadPlayerImageBlobToWorker(blob, filename, `companions/${ownerCharacterId}`);
                await registerManagedMedia(actor, job.variant, {
                    remote: uploadedPath,
                    local: job.source,
                    entityType: "companion",
                    entityId,
                    actor
                });
                uploaded += 1;
            } catch (error) {
                skipped += 1;
                errors.push({ actor: actor.name, variant: job.variant, source: job.source, error: String(error?.message || error) });
            }
        }
    }

    if (errors.length) console.warn(`${MODULE_ID} | Alcune immagini personaggio non sono state sincronizzate.`, errors);
    if (notify) ui.notifications.info(`Immagini personaggi sincronizzate. Caricate: ${uploaded}. Gia presenti: ${existing}. Saltate: ${skipped}.`);
    console.info(`${MODULE_ID} | Immagini personaggi sincronizzate verso wiki.`, { uploaded, existing, skipped, actors: playerActors.length });
    return true;
}

async function confirmBulkWikiMediaOperation({ title, total, description }) {
    const count = Number(total) || 0;
    if (count <= 0) return true;
    return Dialog.confirm({
        title,
        content: `
            <div>
                <p>${escapeHtml(description || "Questa azione puo generare chiamate verso Cloudflare/R2.")}</p>
                <p><strong>Elementi candidati:</strong> ${count}</p>
                <p>Procedi solo se vuoi davvero sincronizzare questi asset adesso.</p>
            </div>
        `,
        yes: () => true,
        no: () => false,
        defaultYes: false
    });
}

async function syncAbilityIconsToWiki({ notify = false } = {}) {
    if (!game.user?.isGM) {
        ui.notifications.warn("Solo il GM puo sincronizzare icone abilita verso la wiki.");
        return false;
    }

    const loaded = await requestNotesApi("api/data/ability-overrides");
    const records = Array.isArray(loaded?.data) ? loaded.data : [];
    const expectedVersion = loaded?.source === "kv" ? (loaded.version ?? 0) : 0;
    const nextRecords = records.slice();
    const playerActors = getPlayerActorsForWikiSync();
    const abilityCandidates = playerActors.flatMap((actor) => (
        actor.items.filter((item) => item.type === "feat" && String(item.img || "").trim())
    ));
    const confirmed = await confirmBulkWikiMediaOperation({
        title: "Sincronizza icone abilita",
        total: abilityCandidates.length,
        description: "Il modulo riusa gli override gia presenti e carica su R2 solo le icone abilita mancanti."
    });
    if (!confirmed) return false;

    let uploaded = 0;
    let reused = 0;
    let skipped = 0;
    let changed = 0;
    const errors = [];

    for (const actor of playerActors) {
        const characterFolder = getConfiguredCharacterIdForActor(actor) || await resolveWikiCharacterIdForActor(actor);
        const abilities = actor.items.filter((item) => item.type === "feat" && String(item.img || "").trim());
        for (const item of abilities) {
            const identity = getAbilityOverrideIdentityForItem(actor, item);
            const existing = findExistingAbilityOverrideRecord(nextRecords, identity);
            const existingImagePath = String(existing?.image || "").trim();
            const foundryImagePath = extractWorkerMediaPath(item.img);
            const folder = buildCampaignScopedOverrideFolder("ability-overrides", actor?.name || characterFolder || actor?.id);
            const filename = `${slugify(item?.name || item?.id || "abilita")}.webp`;
            let imagePath = await getReusableCampaignMediaPath(existingImagePath)
                || await copyLegacyMediaPathToCampaign(existingImagePath, folder, filename)
                || await getReusableCampaignMediaPath(foundryImagePath)
                || await copyLegacyMediaPathToCampaign(foundryImagePath, folder, filename);
            try {
                if (imagePath) {
                    reused += 1;
                } else {
                    const blob = await imagePathToWebpIconBlob(item.img);
                    imagePath = await uploadAbilityIconBlobToWorker(blob, actor, item, characterFolder);
                    uploaded += 1;
                }
            } catch (error) {
                skipped += 1;
                errors.push({ actor: actor.name, ability: item.name, error: String(error?.message || error) });
                continue;
            }
            await registerManagedMedia(item, "image", {
                remote: imagePath,
                local: item.img,
                entityType: "ability",
                entityId: identity.key,
                actor,
                item
            });

            const record = {
                ...(existing || {}),
                id: existing?.id || identity.key,
                key: existing?.key || identity.key,
                actorId: identity.actorId,
                actorName: identity.actorName,
                abilityId: identity.abilityId,
                abilityName: identity.abilityName,
                image: imagePath,
                updatedAt: existing?.image === imagePath && existing?.updatedAt ? existing.updatedAt : new Date().toISOString()
            };
            const existingIndex = nextRecords.findIndex((entry) => entry === existing || entry?.key === record.key || entry?.id === record.id);
            const hasChanged = JSON.stringify(existing || null) !== JSON.stringify(record);
            if (existingIndex >= 0) nextRecords[existingIndex] = record;
            else nextRecords.push(record);
            if (hasChanged) changed += 1;
        }
    }

    nextRecords.sort((left, right) => {
        const actorSort = String(left.actorName || left.characterName || "").localeCompare(String(right.actorName || right.characterName || ""), "it");
        if (actorSort !== 0) return actorSort;
        return String(left.abilityName || "").localeCompare(String(right.abilityName || ""), "it");
    });

    if (changed > 0) {
        await requestNotesApi("api/data/ability-overrides", {
            method: "POST",
            body: {
                data: nextRecords,
                expectedVersion
            }
        });
    }

    if (errors.length) console.warn(`${MODULE_ID} | Alcune icone abilita non sono state sincronizzate.`, errors);
    if (notify) ui.notifications.info(`Icone abilita sincronizzate. Caricate: ${uploaded}. Gia registrate: ${reused}. Saltate: ${skipped}.`);
    console.info(`${MODULE_ID} | Icone abilita sincronizzate verso wiki.`, { uploaded, reused, skipped, changed, actors: playerActors.length });
    return true;
}

async function syncInventoryItemIconsToWiki({ notify = false } = {}) {
    if (!game.user?.isGM) {
        ui.notifications.warn("Solo il GM puo sincronizzare icone inventario verso la wiki.");
        return false;
    }

    const loaded = await requestNotesApi("api/data/item-overrides");
    const records = Array.isArray(loaded?.data) ? loaded.data : [];
    const expectedVersion = loaded?.source === "kv" ? (loaded.version ?? 0) : 0;
    const nextRecords = records.slice();
    const playerActors = getPlayerActorsForWikiSync();
    const itemCandidates = playerActors.flatMap((actor) => (
        actor.items.filter((item) =>
            item
            && item.type !== "feat"
            && item.type !== "spell"
            && CHARACTER_SYNC_ITEM_TYPES.has(item.type)
            && String(item.img || "").trim()
        )
    ));
    const confirmed = await confirmBulkWikiMediaOperation({
        title: "Sincronizza icone inventario",
        total: itemCandidates.length,
        description: "Il modulo riusa gli override gia presenti e carica su R2 solo le icone inventario mancanti."
    });
    if (!confirmed) return false;

    let uploaded = 0;
    let reused = 0;
    let skipped = 0;
    let changed = 0;
    const errors = [];

    for (const actor of playerActors) {
        const characterFolder = getConfiguredCharacterIdForActor(actor) || await resolveWikiCharacterIdForActor(actor);
        const inventoryItems = actor.items.filter((item) =>
            item
            && item.type !== "feat"
            && item.type !== "spell"
            && CHARACTER_SYNC_ITEM_TYPES.has(item.type)
            && String(item.img || "").trim()
        );

        for (const item of inventoryItems) {
            const identity = getItemOverrideIdentityForItem(actor, item);
            const existing = findExistingItemOverrideRecord(nextRecords, identity);
            const existingImagePath = String(existing?.image || "").trim();
            const reusableExistingImagePath = await getReusableCampaignMediaPath(existingImagePath);
            const foundryImagePath = extractWorkerMediaPath(item.img);
            const folder = buildCampaignScopedOverrideFolder("item-overrides", actor?.name || characterFolder || actor?.id);
            const filename = `${slugify(item?.name || item?.id || "oggetto")}.webp`;
            let imagePath = reusableExistingImagePath
                || await copyLegacyMediaPathToCampaign(existingImagePath, folder, filename)
                || await getReusableCampaignMediaPath(foundryImagePath)
                || await copyLegacyMediaPathToCampaign(foundryImagePath, folder, filename);
            const hasSiteImage = existing?.imageSource === "site" && Boolean(imagePath);
            try {
                if (imagePath) {
                    reused += 1;
                } else {
                    const blob = await imagePathToWebpIconBlob(item.img);
                    imagePath = await uploadItemIconBlobToWorker(blob, actor, item, characterFolder);
                    uploaded += 1;
                }
            } catch (error) {
                skipped += 1;
                errors.push({ actor: actor.name, item: item.name, error: String(error?.message || error) });
                continue;
            }
            await registerManagedMedia(item, "image", {
                remote: imagePath,
                local: item.img,
                entityType: "item",
                entityId: identity.key,
                actor,
                item
            });

            const record = {
                ...(existing || {}),
                id: existing?.id || identity.key,
                key: existing?.key || identity.key,
                actorId: identity.actorId,
                actorName: identity.actorName,
                itemUuid: identity.itemUuid,
                transferId: identity.transferId,
                sourceId: identity.sourceId,
                transferKey: identity.transferKey,
                itemId: identity.itemId,
                itemName: identity.itemName,
                itemType: identity.itemType,
                image: imagePath,
                imageSource: hasSiteImage ? "site" : "foundry",
                updatedAt: existing?.image === imagePath && existing?.updatedAt ? existing.updatedAt : new Date().toISOString()
            };
            const existingIndex = nextRecords.findIndex((entry) => entry === existing || entry?.key === record.key || entry?.id === record.id);
            const hasChanged = JSON.stringify(existing || null) !== JSON.stringify(record);
            if (existingIndex >= 0) nextRecords[existingIndex] = record;
            else nextRecords.push(record);
            if (hasChanged) changed += 1;
        }
    }

    nextRecords.sort((left, right) => {
        const actorSort = String(left.actorName || left.characterName || "").localeCompare(String(right.actorName || right.characterName || ""), "it");
        if (actorSort !== 0) return actorSort;
        return String(left.itemName || "").localeCompare(String(right.itemName || ""), "it");
    });

    if (changed > 0) {
        await requestNotesApi("api/data/item-overrides", {
            method: "POST",
            body: {
                data: nextRecords,
                expectedVersion
            }
        });
    }

    if (errors.length) console.warn(`${MODULE_ID} | Alcune icone inventario non sono state sincronizzate.`, errors);
    if (notify) ui.notifications.info(`Icone inventario sincronizzate. Caricate: ${uploaded}. Gia registrate: ${reused}. Saltate: ${skipped}.`);
    console.info(`${MODULE_ID} | Icone inventario sincronizzate verso wiki.`, { uploaded, reused, skipped, changed, actors: playerActors.length });
    return true;
}

async function resolvePlayerActorForMediaOverride(record) {
    const actorId = normalizeActorRef(record?.actorId || "");
    if (actorId && game.actors.get(actorId)) return game.actors.get(actorId);
    const entityId = normalizeWikiItemKey(record?.entityId || record?.characterId || record?.ownerCharacterId || "");
    const mapping = parsePlayerActorMappings().find((entry) => normalizeWikiItemKey(entry.ownerCharacterId) === entityId);
    const mappedActor = getConfiguredActor(mapping?.actorRef);
    if (mappedActor) return mappedActor;
    return null;
}

function resolveCompanionActorForMediaOverride(record) {
    const actorId = normalizeActorRef(record?.actorId || "");
    if (actorId && game.actors.get(actorId)) return game.actors.get(actorId);
    const names = [
        record?.foundryName,
        record?.name,
        record?.entityId
    ].map(normalizeWikiItemKey).filter(Boolean);
    return game.actors.find((actor) => {
        const actorName = normalizeWikiItemKey(actor.name);
        return names.some((name) => actorName === name || actorName.includes(name) || name.includes(actorName));
    }) || null;
}

async function applyCharacterMediaOverridesFromWiki({ notify = false } = {}) {
    if (!game.user?.isGM) {
        ui.notifications.warn("Solo il GM puo applicare immagini personaggi dalla wiki.");
        return false;
    }

    const payload = await requestNotesApi("api/data/media-overrides");
    const overrides = Array.isArray(payload?.data) ? payload.data : [];
    if (!overrides.length) {
        ui.notifications.info("Nessun override immagini trovato nella wiki.");
        return true;
    }

    const candidates = [];
    let skipped = 0;
    for (const record of overrides) {
        const images = record?.images || {};
        const avatarRemote = String(images.avatar || images.portrait || "").trim();
        const tokenRemote = String(images.token || "").trim();
        const avatar = resolveWikiAssetUrl(avatarRemote);
        const token = resolveWikiAssetUrl(tokenRemote);
        if (!avatar && !token) {
            skipped += 1;
            continue;
        }

        const actor = record.entityType === "companion"
            ? resolveCompanionActorForMediaOverride(record)
            : await resolvePlayerActorForMediaOverride(record);
        if (!actor) {
            skipped += 1;
            console.warn(`${MODULE_ID} | Override immagini non applicato: actor non trovato.`, record);
            continue;
        }

        const patch = {};
        const changes = [];
        if (avatar && normalizeOverrideImageValue(avatar) !== normalizeOverrideImageValue(actor.img)) {
            patch.img = avatarRemote;
            changes.push({ field: "avatar", label: "Avatar" });
        }
        const currentToken = actor.prototypeToken?.texture?.src || "";
        if (token && normalizeOverrideImageValue(token) !== normalizeOverrideImageValue(currentToken)) {
            patch["prototypeToken.texture.src"] = tokenRemote;
            changes.push({ field: "token", label: "Token" });
        }
        if (!Object.keys(patch).length) {
            skipped += 1;
            continue;
        }

        candidates.push({
            label: actor.name,
            detail: record.entityType === "companion" ? "Companion" : "Personaggio",
            changes,
            apply: async () => {
                const nextPatch = { ...patch };
                const entityType = record.entityType === "companion" ? "companion" : "player";
                const entityId = record.entityId || record.characterId || record.id || actor.name || actor.id;
                if (nextPatch.img) {
                    const effectiveAvatar = await resolveAndRegisterManagedMedia(actor, "avatar", {
                        remote: nextPatch.img,
                        local: actor.img,
                        entityType,
                        entityId,
                        actor,
                        name: record.name || actor.name,
                        downloadFallback: true
                    });
                    if (effectiveAvatar) nextPatch.img = effectiveAvatar;
                    else delete nextPatch.img;
                }
                if (nextPatch["prototypeToken.texture.src"]) {
                    const effectiveToken = await resolveAndRegisterManagedMedia(actor, "token", {
                        remote: nextPatch["prototypeToken.texture.src"],
                        local: actor.prototypeToken?.texture?.src || "",
                        entityType,
                        entityId,
                        actor,
                        name: record.name || actor.name,
                        downloadFallback: true
                    });
                    if (effectiveToken) nextPatch["prototypeToken.texture.src"] = effectiveToken;
                    else delete nextPatch["prototypeToken.texture.src"];
                }
                if (!Object.keys(nextPatch).length) return null;
                return actor.update(nextPatch);
            }
        });
    }

    const selected = await selectWikiOverridesToApply({
        title: "Applica immagini sito",
        description: "Seleziona quali immagini rendere uguali al sito.",
        entries: candidates
    });
    if (selected === null) return false;

    let updated = 0;
    for (const entry of selected) {
        await entry.apply();
        updated += 1;
    }
    skipped += candidates.length - selected.length;

    if (notify) ui.notifications.info(`Immagini personaggi applicate: ${updated}. Saltate: ${skipped}.`);
    console.info(`${MODULE_ID} | Override immagini wiki applicati.`, { updated, skipped });
    return true;
}

function resolveActorFromAssetRecord(record) {
    const foundry = record?.foundry || {};
    const actorId = normalizeActorRef(foundry.actorId || record?.actorId || "");
    if (actorId && game.actors.get(actorId)) return game.actors.get(actorId);
    const actorName = normalizeWikiItemKey(foundry.actorName || record?.label || "");
    return game.actors.find((actor) => actorName && normalizeWikiItemKey(actor.name) === actorName) || null;
}

function resolveItemFromAssetRecord(actor, record) {
    if (!actor) return null;
    const foundry = record?.foundry || {};
    const transferId = String(record?.transferId || foundry.transferId || "").trim();
    const transferKey = String(record?.transferKey || foundry.transferKey || "").trim();
    const sourceId = normalizeWikiItemKey(record?.sourceId || foundry.sourceId || "");
    const itemId = String(foundry.itemId || record?.itemId || "").trim();
    const itemName = normalizeWikiItemKey(foundry.itemName || record?.label || "");
    return actor.items.find((item) => transferId && getItemTransferId(item) === transferId)
        || actor.items.find((item) => transferKey && getItemOverrideIdentityForItem(actor, item).transferKey === transferKey)
        || actor.items.find((item) => sourceId && normalizeWikiItemKey(getItemStableSourceId(item)) === sourceId)
        || (itemId ? actor.items.get(itemId) : null)
        || actor.items.find((item) => itemName && normalizeWikiItemKey(item.name) === itemName)
        || null;
}

function buildAssetJobCandidate(job) {
    const record = job?.record || {};
    const direction = String(job?.direction || "");
    const sourceState = direction === "site-to-foundry" ? record.siteState : record.foundryState;
    const targetState = direction === "site-to-foundry" ? record.foundryState : record.siteState;
    return {
        label: record.label || job.label || job.assetId || "Asset",
        detail: `${direction === "site-to-foundry" ? "Sito -> Foundry" : "Foundry -> Sito"} | ${record.entityType || ""} / ${record.slot || ""}`,
        changes: [{ label: `${String(sourceState?.value || "").slice(0, 80)} -> ${String(targetState?.value || "").slice(0, 80)}` }],
        job
    };
}

async function applyAssetJobToFoundry(job) {
    const record = job?.record || {};
    const actor = resolveActorFromAssetRecord(record);
    if (!actor) throw new Error("Actor Foundry non trovato.");
    const value = String(record.siteState?.value || "").trim();
    if (!value) throw new Error("Valore sito mancante.");
    const slot = String(record.slot || "").trim();
    const entityType = String(record.entityType || "").trim();
    const resolvedImage = resolveWikiAssetUrl(value);

    if ((entityType === "player" || entityType === "companion") && (slot === "avatar" || slot === "token")) {
        const local = slot === "avatar"
            ? actor.img
            : actor.prototypeToken?.texture?.src || "";
        const effectiveImage = await resolveAndRegisterManagedMedia(actor, slot, {
            remote: value,
            local,
            entityType,
            entityId: record.entityId || record.characterId || record.id || actor.id || actor.name,
            actor,
            name: record.label || actor.name,
            downloadFallback: true
        });
        const patch = slot === "avatar"
            ? { img: effectiveImage || "" }
            : { "prototypeToken.texture.src": effectiveImage || "" };
        if (!Object.values(patch).some(Boolean)) throw new Error("Immagine remota non disponibile e fallback locale assente.");
        await actor.update(patch);
        return;
    }

    const item = resolveItemFromAssetRecord(actor, record);
    if (!item) throw new Error("Item/abilita Foundry non trovato.");
    if (slot === "image" || slot === "icon") {
        const effectiveImage = await resolveAndRegisterManagedMedia(item, "image", {
            remote: value,
            local: item.img,
            entityType: entityType === "ability" ? "ability" : "item",
            entityId: record.entityId || record.id || item.id || item.name,
            actor,
            item,
            downloadFallback: true
        });
        if (!effectiveImage) throw new Error("Immagine remota non disponibile e fallback locale assente.");
        await item.update({ img: effectiveImage });
        return;
    }
    if (slot === "description") {
        await item.update({ "system.description.value": renderAbilityOverrideDescription(value) });
        return;
    }
    throw new Error(`Slot non supportato: ${slot}`);
}

function getCurrentFoundryAssetValue(record) {
    const actor = resolveActorFromAssetRecord(record);
    if (!actor) throw new Error("Actor Foundry non trovato per backup.");
    const slot = String(record?.slot || "").trim();
    const entityType = String(record?.entityType || "").trim();

    if ((entityType === "player" || entityType === "companion") && slot === "avatar") {
        return {
            actor,
            item: null,
            value: String(actor.img || "").trim()
        };
    }

    if ((entityType === "player" || entityType === "companion") && slot === "token") {
        return {
            actor,
            item: null,
            value: String(actor.prototypeToken?.texture?.src || "").trim()
        };
    }

    const item = resolveItemFromAssetRecord(actor, record);
    if (!item) throw new Error("Item/abilita Foundry non trovato per backup.");
    if (slot === "image" || slot === "icon") {
        return {
            actor,
            item,
            value: String(item.img || "").trim()
        };
    }
    if (slot === "description") {
        return {
            actor,
            item,
            value: String(item.system?.description?.value || "").trim()
        };
    }

    throw new Error(`Slot non supportato per backup: ${slot}`);
}

function buildAssetSyncBackupEntry(job) {
    const record = job?.record || {};
    const current = getCurrentFoundryAssetValue(record);
    const foundry = record.foundry || {};
    const now = new Date().toISOString();
    const previousValue = current.value;
    const incomingValue = String(record.siteState?.value || "").trim();
    return {
        id: `${getCampaignId()}:backup:${hashString(`${job?.id || record.id || ""}:${previousValue}:${now}`)}`,
        campaignId: getCampaignId(),
        jobId: job?.id || "",
        assetId: job?.assetId || record.id || "",
        direction: "site-to-foundry",
        entityType: record.entityType || "",
        entityId: record.entityId || "",
        slot: record.slot || "",
        label: record.label || job?.label || record.entityId || "",
        actorId: current.actor?.id || foundry.actorId || "",
        actorName: current.actor?.name || foundry.actorName || "",
        itemId: current.item?.id || foundry.itemId || "",
        itemName: current.item?.name || foundry.itemName || "",
        previousValue,
        incomingValue,
        previousHash: hashString(previousValue),
        incomingHash: hashString(incomingValue),
        createdAt: now,
        createdBy: game.user?.name || "GM"
    };
}

async function saveAssetSyncFoundryBackups(jobs) {
    const backupJobs = (Array.isArray(jobs) ? jobs : [])
        .filter((job) => job?.direction === "site-to-foundry");
    if (!backupJobs.length) return 0;

    const entries = [];
    for (const job of backupJobs) {
        const entry = buildAssetSyncBackupEntry(job);
        entries.push(entry);
    }
    if (!entries.length) return 0;

    const payload = await requestNotesApi("api/data/asset-sync-backups");
    const existing = Array.isArray(payload?.data) ? payload.data.slice() : [];
    const existingKeys = new Set(existing.map((entry) => `${entry.jobId}:${entry.previousHash}:${entry.incomingHash}`));
    const nextEntries = entries.filter((entry) => {
        const key = `${entry.jobId}:${entry.previousHash}:${entry.incomingHash}`;
        if (existingKeys.has(key)) return false;
        existingKeys.add(key);
        return true;
    });
    if (!nextEntries.length) return 0;

    await requestNotesApi("api/data/asset-sync-backups", {
        method: "POST",
        body: {
            data: [...existing, ...nextEntries],
            expectedVersion: payload?.source === "kv" ? (payload.version ?? 0) : 0
        }
    });
    return nextEntries.length;
}

async function resolveAssetJobImageForSite(record, actor, item, value) {
    const slot = String(record?.slot || "").trim();
    const entityType = String(record?.entityType || "").trim();
    const workerPath = extractWorkerMediaPath(value);
    if (await getReusableCampaignMediaPath(workerPath)) return workerPath;

    if ((entityType === "player" || entityType === "companion") && (slot === "avatar" || slot === "token")) {
        const isAvatar = slot === "avatar";
        const blob = isAvatar
            ? await imagePathToWebpBlobPreserveSize(value)
            : await imagePathToSquareWebpBlob(value, CHARACTER_IMAGE_SYNC_SIZE);
        if (entityType === "companion") {
            const ownerCharacterId = getConfiguredCompanionOwnerCharacterIdForActor(actor)
                || slugify(record?.ownerCharacterId || record?.characterId || "");
            const actorName = actor?.name || "companion";
            const entityId = buildCompanionMediaEntityId(ownerCharacterId, actor?.id || "", actorName);
            const filename = `${entityId}${slot === "token" ? "-token" : "-avatar"}.webp`;
            return uploadPlayerImageBlobToWorker(blob, filename, `companions/${ownerCharacterId || slugify(actorName)}`);
        }
        const characterId = getConfiguredCharacterIdForActor(actor) || await resolveWikiCharacterIdForActor(actor);
        const filename = `${slugify(characterId)}${slot === "token" ? "-token" : "-avatar"}.webp`;
        return uploadPlayerImageBlobToWorker(blob, filename);
    }

    const folderBase = entityType === "ability" ? "ability-overrides" : "item-overrides";
    const characterFolder = getConfiguredCharacterIdForActor(actor) || await resolveWikiCharacterIdForActor(actor);
    const folder = buildCampaignScopedOverrideFolder(folderBase, actor?.name || characterFolder || actor?.id);
    const filename = `${slugify(item?.name || item?.id || "asset")}.webp`;
    const copied = await copyLegacyMediaPathToCampaign(value, folder, filename);
    if (copied) return copied;
    const blob = await imagePathToWebpIconBlob(value);
    return uploadRawMediaBlobToWorker(blob, filename, folder);
}

function upsertRecord(records, matcher, buildRecord) {
    const existing = records.find(matcher);
    const next = buildRecord(existing || {});
    const index = existing ? records.indexOf(existing) : -1;
    if (index >= 0) records[index] = next;
    else records.push(next);
    return next;
}

async function applyAssetJobToSite(job, collectionDrafts) {
    const record = job?.record || {};
    const actor = resolveActorFromAssetRecord(record);
    if (!actor) throw new Error("Actor Foundry non trovato.");
    const item = ["ability", "item"].includes(String(record.entityType || "")) ? resolveItemFromAssetRecord(actor, record) : null;
    if (["ability", "item"].includes(String(record.entityType || "")) && !item) throw new Error("Item/abilita Foundry non trovato.");

    const slot = String(record.slot || "").trim();
    const entityType = String(record.entityType || "").trim();
    const sourceValue = String(record.foundryState?.value || "").trim();
    if (!sourceValue) throw new Error("Valore Foundry mancante.");
    const now = new Date().toISOString();

    if (entityType === "ability") {
        const draft = await getAssetJobCollectionDraft(collectionDrafts, "ability-overrides");
        const identity = getAbilityOverrideIdentityForItem(actor, item);
        const value = slot === "description" ? sourceValue : await resolveAssetJobImageForSite(record, actor, item, sourceValue);
        if (slot !== "description") {
            await registerManagedMedia(item, "image", {
                remote: value,
                local: sourceValue,
                entityType: "ability",
                entityId: identity.key,
                actor,
                item
            });
        }
        upsertRecord(draft.data, (entry) => findExistingAbilityOverrideRecord([entry], identity), (existing) => ({
            ...existing,
            id: existing.id || identity.key,
            key: existing.key || identity.key,
            actorId: identity.actorId,
            actorName: identity.actorName,
            abilityId: identity.abilityId,
            abilityName: identity.abilityName,
            ...(slot === "description" ? { description: value } : { image: value, imageSource: "foundry" }),
            updatedAt: now
        }));
        return;
    }

    if (entityType === "item") {
        const draft = await getAssetJobCollectionDraft(collectionDrafts, "item-overrides");
        const identity = getItemOverrideIdentityForItem(actor, item);
        const value = slot === "description" ? sourceValue : await resolveAssetJobImageForSite(record, actor, item, sourceValue);
        if (slot !== "description") {
            await registerManagedMedia(item, "image", {
                remote: value,
                local: sourceValue,
                entityType: "item",
                entityId: identity.key,
                actor,
                item
            });
        }
        upsertRecord(draft.data, (entry) => findExistingItemOverrideRecord([entry], identity), (existing) => ({
            ...existing,
            id: existing.id || identity.key,
            key: existing.key || identity.key,
            actorId: identity.actorId,
            actorName: identity.actorName,
            itemUuid: identity.itemUuid,
            transferId: identity.transferId,
            sourceId: identity.sourceId,
            transferKey: identity.transferKey,
            itemId: identity.itemId,
            itemName: identity.itemName,
            itemType: identity.itemType,
            ...(slot === "description" ? { description: value } : { image: value, imageSource: "foundry" }),
            updatedAt: now
        }));
        return;
    }

    if ((entityType === "player" || entityType === "companion") && (slot === "avatar" || slot === "token")) {
        const draft = await getAssetJobCollectionDraft(collectionDrafts, "media-overrides");
        const imagePath = await resolveAssetJobImageForSite(record, actor, null, sourceValue);
        const ownerCharacterId = entityType === "companion" ? getConfiguredCompanionOwnerCharacterIdForActor(actor) : "";
        const entityId = record.entityId || (entityType === "player"
            ? (getConfiguredCharacterIdForActor(actor) || await resolveWikiCharacterIdForActor(actor))
            : buildCompanionMediaEntityId(ownerCharacterId || record.ownerCharacterId || "", actor.id, actor.name));
        await registerManagedMedia(actor, slot, {
            remote: imagePath,
            local: sourceValue,
            entityType,
            entityId,
            actor
        });
        upsertRecord(draft.data, (entry) => entry?.entityType === entityType && entry?.entityId === entityId, (existing) => ({
            ...existing,
            id: existing.id || `${entityType}:${entityId}`,
            key: existing.key || `${entityType}:${entityId}`,
            entityType,
            entityId,
            ...(ownerCharacterId ? { characterId: ownerCharacterId, ownerCharacterId } : {}),
            actorId: actor.id,
            name: actor.name,
            foundryName: actor.name,
            images: {
                ...(existing.images || {}),
                [slot === "token" ? "token" : "avatar"]: imagePath,
                ...(slot === "avatar" ? { portrait: imagePath } : {})
            },
            updatedAt: now
        }));
        return;
    }

    throw new Error(`Tipo/slot non supportato: ${entityType}/${slot}`);
}

async function getAssetJobCollectionDraft(collectionDrafts, collection) {
    if (collectionDrafts.has(collection)) return collectionDrafts.get(collection);
    const payload = await requestNotesApi(`api/data/${collection}`);
    const draft = {
        collection,
        expectedVersion: payload?.source === "kv" ? (payload.version ?? 0) : 0,
        data: Array.isArray(payload?.data) ? payload.data.slice() : []
    };
    collectionDrafts.set(collection, draft);
    return draft;
}

async function saveAssetJobCollectionDrafts(collectionDrafts) {
    for (const draft of collectionDrafts.values()) {
        await requestNotesApi(`api/data/${draft.collection}`, {
            method: "POST",
            body: {
                data: draft.data,
                expectedVersion: draft.expectedVersion
            }
        });
    }
}

async function applyQueuedAssetSyncJobsFromWiki({ notify = false } = {}) {
    if (!game.user?.isGM) {
        ui.notifications.warn("Solo il GM puo applicare richieste asset.");
        return false;
    }

    const payload = await requestNotesApi("api/data/asset-sync-jobs");
    const jobs = Array.isArray(payload?.data) ? payload.data : [];
    const pending = jobs.filter((job) => job?.status === "pending");
    if (!pending.length) {
        ui.notifications.info("Nessuna richiesta asset in coda.");
        return true;
    }

    const selected = await selectWikiOverridesToApply({
        title: "Applica richieste asset",
        description: "Seleziona le richieste create dal sito da applicare ora. Ogni richiesta aggiorna una sola cosa.",
        entries: pending.map(buildAssetJobCandidate)
    });
    if (selected === null) return false;

    const selectedIds = new Set(selected.map((entry) => entry.job.id));
    const selectedJobs = jobs.filter((entry) => selectedIds.has(entry.id));
    let backupCount = 0;
    try {
        backupCount = await saveAssetSyncFoundryBackups(selectedJobs);
    } catch (error) {
        ui.notifications.error("Backup richieste asset non riuscito. Applicazione annullata per sicurezza.");
        console.warn(`${MODULE_ID} | Backup richieste asset non riuscito.`, error);
        return false;
    }

    const collectionDrafts = new Map();
    let applied = 0;
    let failed = 0;
    const nextJobs = jobs.map((job) => ({ ...job }));

    for (const job of nextJobs.filter((entry) => selectedIds.has(entry.id))) {
        try {
            if (job.direction === "site-to-foundry") await applyAssetJobToFoundry(job);
            else if (job.direction === "foundry-to-site") await applyAssetJobToSite(job, collectionDrafts);
            else throw new Error(`Direzione non supportata: ${job.direction}`);
            job.status = "applied";
            job.appliedAt = new Date().toISOString();
            job.appliedBy = game.user?.name || "GM";
            delete job.error;
            applied += 1;
        } catch (error) {
            job.status = "failed";
            job.error = String(error?.message || error);
            job.failedAt = new Date().toISOString();
            failed += 1;
            console.warn(`${MODULE_ID} | Richiesta asset fallita.`, { job, error });
        }
    }

    await saveAssetJobCollectionDrafts(collectionDrafts);
    await requestNotesApi("api/data/asset-sync-jobs", {
        method: "POST",
        body: {
            data: nextJobs,
            expectedVersion: payload?.source === "kv" ? (payload.version ?? 0) : 0
        }
    });

    if (notify) ui.notifications.info(`Richieste asset applicate: ${applied}. Fallite: ${failed}. Backup creati: ${backupCount}.`);
    console.info(`${MODULE_ID} | Richieste asset applicate.`, { applied, failed, backupCount });
    return true;
}

function getSiteBaseUrl() {
    const configured = String(game.settings.get(MODULE_ID, SETTINGS.SITE_BASE_URL) || "").trim();
    return (configured || "https://khuzoe.github.io/sigillo-del-male").replace(/\/+$/, "");
}

function getCampaignId() {
    const configured = String(game.settings.get(MODULE_ID, SETTINGS.CAMPAIGN_ID) || "").trim();
    return configured || DEFAULT_CAMPAIGN_ID;
}

function withCampaign(url) {
    const target = new URL(url);
    target.searchParams.set("campaign", getCampaignId());
    return target.toString();
}

function getSiteDataUrl(path) {
    const cleanPath = String(path || "").replace(/^\/+/, "").replace(/^assets\/data\//, "");
    const campaignId = getCampaignId();
    if (campaignId === DEFAULT_CAMPAIGN_ID) return `${getSiteBaseUrl()}/assets/data/${cleanPath}`;
    return `${getSiteBaseUrl()}/campaigns/${encodeURIComponent(campaignId)}/data/${cleanPath}`;
}

async function fetchPublicJson(url) {
    const response = await fetch(`${url}${url.includes("?") ? "&" : "?"}t=${Date.now()}`);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response.json();
}

function normalizeSkillTreesPayload(payload) {
    const data = payload?.data && typeof payload.data === "object" ? payload.data : payload;
    if (Array.isArray(data)) {
        return data.reduce((acc, entry) => {
            if (!entry || typeof entry !== "object") return acc;
            const key = String(entry.id || entry.key || entry.characterId || entry.ownerCharacterId || "").trim();
            const tree = entry.tree && typeof entry.tree === "object" ? entry.tree : entry;
            if (key && Array.isArray(tree.nodes)) acc[key] = { ...tree, id: key };
            return acc;
        }, {});
    }
    if (!data || typeof data !== "object") return {};
    return Object.entries(data).reduce((acc, [key, tree]) => {
        if (tree && typeof tree === "object" && Array.isArray(tree.nodes)) acc[key] = tree;
        return acc;
    }, {});
}

async function loadWikiSkillTrees({ force = false } = {}) {
    if (!force && skillTreesCache.data) return skillTreesCache.data;
    if (!force && skillTreesCache.promise) return skillTreesCache.promise;

    skillTreesCache.promise = (async () => {
        const workerUrl = new URL(`${DISCORD_WORKER_URL}/api/data/skill-trees`);
        workerUrl.searchParams.set("campaign", getCampaignId());
        try {
            const onlinePayload = await fetchPublicJson(workerUrl.toString());
            const onlineTrees = normalizeSkillTreesPayload(onlinePayload);
            if (Object.keys(onlineTrees).length) {
                skillTreesCache.data = onlineTrees;
                skillTreesCache.loadedAt = Date.now();
                return onlineTrees;
            }
        } catch (error) {
            console.warn(`${MODULE_ID} | Alberi abilita KV non disponibili, uso JSON statico.`, error);
        }

        const staticPayload = await fetchPublicJson(getSiteDataUrl("skills.json"));
        const staticTrees = normalizeSkillTreesPayload(staticPayload);
        skillTreesCache.data = staticTrees;
        skillTreesCache.loadedAt = Date.now();
        return staticTrees;
    })();

    try {
        return await skillTreesCache.promise;
    } finally {
        skillTreesCache.promise = null;
    }
}

function getCachedWikiSkillTrees() {
    return skillTreesCache.data || null;
}

async function loadWikiSkillTreeStates({ force = false } = {}) {
    const maxAgeMs = 60 * 1000;
    if (!force && skillTreeStatesCache.data && Date.now() - skillTreeStatesCache.loadedAt < maxAgeMs) {
        return skillTreeStatesCache.data;
    }
    if (force) {
        skillTreeStatesCache.data = null;
        skillTreeStatesCache.loadedAt = 0;
    }
    if (!force && skillTreeStatesCache.promise) return skillTreeStatesCache.promise;

    skillTreeStatesCache.promise = (async () => {
        const workerUrl = new URL(`${DISCORD_WORKER_URL}/api/data/skill-tree-states`);
        workerUrl.searchParams.set("campaign", getCampaignId());
        try {
            const payload = await fetchPublicJson(workerUrl.toString());
            const data = Array.isArray(payload?.data) ? payload.data : Array.isArray(payload) ? payload : [];
            skillTreeStatesCache.data = data.filter((entry) => entry && typeof entry === "object");
            skillTreeStatesCache.loadedAt = Date.now();
            return skillTreeStatesCache.data;
        } catch (error) {
            console.warn(`${MODULE_ID} | Stati alberi abilita non disponibili.`, error);
            skillTreeStatesCache.data = [];
            skillTreeStatesCache.loadedAt = Date.now();
            return skillTreeStatesCache.data;
        }
    })();

    try {
        return await skillTreeStatesCache.promise;
    } finally {
        skillTreeStatesCache.promise = null;
    }
}

function getActorSkillTreeCandidateIds(actor) {
    const actorName = normalizeWikiItemKey(actor?.name || "");
    const values = new Set([
        getConfiguredCharacterIdForActor(actor),
        actor?.name
    ].map((value) => String(value || "").trim()).filter(Boolean));

    Object.entries(WIKI_PLAYER_ID_ALIASES).forEach(([wikiId, aliases]) => {
        const matches = aliases
            .map(normalizeWikiItemKey)
            .some((alias) => alias && actorName && (alias === actorName || actorName.includes(alias) || alias.includes(actorName)));
        if (matches) values.add(wikiId);
    });

    return Array.from(values);
}

function getSkillTreeOwnerIds(tree) {
    return [
        tree?.characterId,
        tree?.ownerCharacterId,
        ...(Array.isArray(tree?.characterIds) ? tree.characterIds : []),
        ...(Array.isArray(tree?.ownerCharacterIds) ? tree.ownerCharacterIds : [])
    ].map((value) => String(value || "").trim()).filter(Boolean);
}

function getPlayerSkillTreeEntriesForActor(actor, allSkillTrees = getCachedWikiSkillTrees()) {
    if (!actor || actor.type !== "character" || !allSkillTrees || typeof allSkillTrees !== "object") return [];
    const candidates = getActorSkillTreeCandidateIds(actor);
    const normalizedCandidates = new Set(candidates.map(normalizeWikiItemKey).filter(Boolean));
    const slugCandidates = new Set(candidates.map(slugify).filter(Boolean));
    const entries = [];

    Object.entries(allSkillTrees).forEach(([key, tree]) => {
        if (!tree || typeof tree !== "object" || !Array.isArray(tree.nodes) || !tree.nodes.length) return;
        const owners = getSkillTreeOwnerIds(tree);
        if (owners.length) {
            if (owners.some((owner) => normalizedCandidates.has(normalizeWikiItemKey(owner)))) {
                entries.push({ key, tree });
            }
            return;
        }

        const normalizedKey = normalizeWikiItemKey(key);
        const keySlug = slugify(key);
        if (normalizedCandidates.has(normalizedKey)
            || slugCandidates.has(keySlug)
            || Array.from(slugCandidates).some((candidate) => keySlug.startsWith(`${candidate}-`) || keySlug.startsWith(`${candidate}_`))) {
            entries.push({ key, tree });
        }
    });

    return entries.sort((left, right) => {
        const leftOrder = Number(left.tree.order ?? 0);
        const rightOrder = Number(right.tree.order ?? 0);
        if (leftOrder !== rightOrder) return leftOrder - rightOrder;
        return String(left.tree.name || left.tree.title || left.key).localeCompare(String(right.tree.name || right.tree.title || right.key), "it");
    });
}

function findSkillTreeStateForActor(actor, treeKey, states) {
    const normalizedTreeKey = normalizeWikiItemKey(treeKey);
    const candidates = new Set(getActorSkillTreeCandidateIds(actor).map(normalizeWikiItemKey).filter(Boolean));
    return (Array.isArray(states) ? states : []).find((entry) => {
        if (normalizeWikiItemKey(entry?.treeKey || "") !== normalizedTreeKey) return false;
        const characterId = normalizeWikiItemKey(entry?.characterId || entry?.ownerCharacterId || entry?.playerId || "");
        return characterId && candidates.has(characterId);
    }) || null;
}

function getUnlockedSkillTreeNodeIds(tree, stateRecord) {
    const ids = new Set((tree?.nodes || [])
        .filter((node) => node?.state === "unlocked" || node?.unlocked === true)
        .map((node) => String(node.id)));
    const stateUnlocked = Array.isArray(stateRecord?.unlocked)
        ? stateRecord.unlocked
        : Array.isArray(stateRecord?.unlockedNodeIds)
            ? stateRecord.unlockedNodeIds
            : [];
    stateUnlocked.map(String).filter(Boolean).forEach((id) => ids.add(id));
    return ids;
}

function resolveSkillTreeNodeImage(node) {
    const raw = String(node?.icon || node?.img || node?.image || "").trim();
    if (!raw) return "icons/svg/aura.svg";
    if (/^(https?:|data:|\/)/i.test(raw) || raw.startsWith("media/")) return resolveWikiAssetUrl(raw);
    if (raw.startsWith("assets/")) return resolveWikiAssetUrl(raw);
    return `${DISCORD_WORKER_URL}/media/campaigns/${encodeURIComponent(getCampaignId())}/skill-trees/${raw.replace(/^\/+/, "")}`;
}

function renderSkillTreeNodeDescription(node, tree, level = 1) {
    const parts = [];
    const flavor = String(node?.flavor || "").trim();
    const desc = String(node?.desc || node?.description || "").trim();
    if (flavor) parts.push(`<p><em>${escapeHtml(flavor)}</em></p>`);
    if (desc) parts.push(/<[^>]+>/.test(desc) ? desc : `<p>${escapeHtml(desc)}</p>`);
    if (Number(node?.maxLevel || 1) > 1) {
        parts.push(`<p><strong>Livello albero:</strong> ${escapeHtml(level)} / ${escapeHtml(node.maxLevel)}</p>`);
    }
    parts.push(`<hr><p><strong>Origine:</strong> Albero abilita${tree?.name || tree?.title ? ` - ${escapeHtml(tree.name || tree.title)}` : ""}.</p>`);
    return parts.join("");
}

function buildFoundryItemFromSkillTreeNode(node, tree, treeKey, level = 1) {
    const name = String(node?.title || node?.name || `Abilita ${node?.id || ""}`).trim() || "Abilita";
    const item = buildFoundryActorItemFromWikiAbility({
        name,
        type: node?.itemType || "feat",
        iconImage: resolveSkillTreeNodeImage(node),
        activation: node?.activation || "",
        target: node?.target || "",
        range: node?.range || "",
        saveAbility: node?.saveAbility || "",
        saveDc: node?.saveDc || "",
        damageFormula: node?.damageFormula || "",
        damageType: node?.damageType || "",
        attackBonus: node?.attackBonus || "",
        flags: node?.flags || {}
    }, {});

    item.name = name;
    item.img = resolveSkillTreeNodeImage(node);
    item.system = item.system || {};
    item.system.description = item.system.description || { value: "", chat: "" };
    item.system.description.value = renderSkillTreeNodeDescription(node, tree, level);
    item.system.source = item.system.source || {};
    item.system.source.custom = "Albero abilita wiki";
    item.flags = {
        ...(item.flags || {}),
        [MODULE_ID]: {
            ...(item.flags?.[MODULE_ID] || {}),
            skillTree: {
                treeKey,
                nodeId: String(node?.id || ""),
                level,
                syncedAt: new Date().toISOString()
            }
        }
    };
    return item;
}

function findExistingSkillTreeItem(actor, treeKey, node) {
    const nodeId = String(node?.id || "");
    const nodeName = normalizeWikiItemKey(node?.title || node?.name || "");
    return actor?.items?.find?.((item) => {
        const flag = item.getFlag?.(MODULE_ID, "skillTree") || item.flags?.[MODULE_ID]?.skillTree;
        if (flag && String(flag.treeKey || "") === String(treeKey || "") && String(flag.nodeId || "") === nodeId) return true;
        return nodeName && normalizeWikiItemKey(item.name) === nodeName;
    }) || null;
}

async function syncUnlockedSkillTreeAbilitiesToFoundry({ notify = false, force = false } = {}) {
    if (!game.user?.isGM) {
        if (notify) ui.notifications.warn("Solo il GM puo aggiungere abilita dagli alberi.");
        return false;
    }

    const [skillTrees, states] = await Promise.all([
        loadWikiSkillTrees({ force }),
        loadWikiSkillTreeStates({ force })
    ]);
    const actors = game.actors.filter((actor) => actor.type === "character" && getPlayerSkillTreeEntriesForActor(actor, skillTrees).length);
    let created = 0;
    let skipped = 0;
    let actorsTouched = 0;

    for (const actor of actors) {
        const entries = getPlayerSkillTreeEntriesForActor(actor, skillTrees);
        const toCreate = [];
        for (const entry of entries) {
            const state = findSkillTreeStateForActor(actor, entry.key, states);
            const unlocked = getUnlockedSkillTreeNodeIds(entry.tree, state);
            const levels = state?.levels && typeof state.levels === "object" ? state.levels : {};
            for (const node of entry.tree.nodes || []) {
                if (!unlocked.has(String(node.id))) continue;
                if (findExistingSkillTreeItem(actor, entry.key, node)) {
                    skipped += 1;
                    continue;
                }
                const level = Number(levels[String(node.id)] || 1);
                toCreate.push(buildFoundryItemFromSkillTreeNode(node, entry.tree, entry.key, Number.isFinite(level) ? level : 1));
            }
        }
        if (toCreate.length) {
            await actor.createEmbeddedDocuments("Item", toCreate);
            created += toCreate.length;
            actorsTouched += 1;
        }
    }

    if (notify) ui.notifications.info(`Abilita alberi sincronizzate. Create: ${created}. Gia presenti: ${skipped}.`);
    console.info(`${MODULE_ID} | Abilita alberi sincronizzate.`, { created, skipped, actorsTouched });
    return true;
}

function getPreferredSkillTreeCharacterId(actor, treeEntry = null) {
    const configured = slugify(getConfiguredCharacterIdForActor(actor) || "");
    if (configured && configured !== "entity") return configured;

    const owner = getSkillTreeOwnerIds(treeEntry?.tree).map(slugify).find((value) => value && value !== "entity");
    if (owner) return owner;

    const actorName = normalizeWikiItemKey(actor?.name || "");
    const aliasMatch = Object.entries(WIKI_PLAYER_ID_ALIASES).find(([, aliases]) =>
        aliases.map(normalizeWikiItemKey).some((alias) => alias && actorName && (alias === actorName || actorName.includes(alias) || alias.includes(actorName)))
    );
    if (aliasMatch?.[0]) return slugify(aliasMatch[0]);

    return "";
}

async function openPlayerSkillTreeForActor(actor) {
    const skillTrees = await loadWikiSkillTrees();
    const entries = getPlayerSkillTreeEntriesForActor(actor, skillTrees);
    if (!entries.length) {
        ui.notifications.info("Questo personaggio non ha alberi abilita associati nella wiki.");
        return null;
    }

    const treeKey = entries[0].key || "default";
    const characterId = getPreferredSkillTreeCharacterId(actor, entries[0]) || await resolveWikiCharacterIdForActor(actor);
    return new CriptaWikiSkillTreeApp({
        characterId,
        title: `Albero - ${actor?.name || characterId}`,
        treeKey
    }).render(true);
}

function rerenderOpenActorSheetsForSkillTreeButtons() {
    Object.values(ui.windows || {}).forEach((app) => {
        if (!app?.actor || !app?.rendered) return;
        app.render(false);
    });
}

function resolveWikiAssetUrl(path) {
    const raw = String(path || "").trim();
    if (!raw) return "";
    const mediaPath = normalizeManagedRemotePath(raw);
    if (mediaPath) return `${DISCORD_WORKER_URL}/${mediaPath}`;
    if (/^(https?:|data:|\/)/i.test(raw)) return raw;
    return `${getSiteBaseUrl()}/assets/${raw.replace(/^assets\//, "").replace(/^\/+/, "")}`;
}

async function loadWikiItemsCatalog() {
    const normalizeCatalog = (payload) => {
        const items = Array.isArray(payload?.data)
            ? payload.data
            : Array.isArray(payload)
                ? payload
                : [];
        return items.filter((item) => item && typeof item === "object" && (item.id || item.name));
    };

    try {
        const response = await fetch(withCampaign(`${DISCORD_WORKER_URL}/api/data/items`), {
            method: "GET",
            headers: { Accept: "application/json" },
            cache: "no-cache"
        });
        if (!response.ok) throw new Error(`api/data/items HTTP ${response.status}`);
        const items = normalizeCatalog(await response.json());
        if (items.length) return items;
    } catch (error) {
        console.warn(`${MODULE_ID} | Catalogo oggetti KV non disponibile, uso JSON statico.`, error);
    }

    const response = await fetch(getSiteDataUrl("items.json"), {
        method: "GET",
        headers: { Accept: "application/json" },
        cache: "no-cache"
    });
    if (!response.ok) throw new Error(`items.json HTTP ${response.status}`);
    return normalizeCatalog(await response.json());
}

function getWikiItemAliases(item) {
    const aliases = [
        item.id,
        item.name,
        item.foundryName,
        item.unidentifiedName,
        ...(Array.isArray(item.foundryNames) ? item.foundryNames : []),
        ...(Array.isArray(item.aliases) ? item.aliases : [])
    ].filter(Boolean);
    if (item.owner && item.name && String(item.name).includes(":")) {
        const localName = String(item.name).split(":").slice(1).join(":").trim();
        if (localName) aliases.push(`${localName} di ${item.owner}`);
    }
    return Array.from(new Set(aliases)).filter(Boolean);
}

function getWikiItemFoundryNames(item) {
    return [
        item.foundryName,
        ...(Array.isArray(item.foundryNames) ? item.foundryNames : [])
    ].filter(Boolean);
}

function getPreferredFoundryItemName(item) {
    return getWikiItemFoundryNames(item)[0] || item.name || "Oggetto wiki";
}

function getExistingItemKeys() {
    const keys = new Set();
    game.items.forEach((item) => {
        const wikiId = item.getFlag?.(MODULE_ID, "wikiItemId");
        if (wikiId) keys.add(`id:${String(wikiId)}`);
        const flaggedNames = item.getFlag?.(MODULE_ID, "foundryNames");
        const names = [
            item.name,
            item.getFlag?.(MODULE_ID, "wikiItemName"),
            ...(Array.isArray(flaggedNames) ? flaggedNames : [])
        ];
        names.forEach((name) => {
            const key = normalizeWikiItemKey(name);
            if (key) keys.add(`name:${key}`);
        });
    });
    return keys;
}

function isWikiItemPresent(item, existingKeys = getExistingItemKeys()) {
    if (item.id && existingKeys.has(`id:${String(item.id)}`)) return true;
    return getWikiItemAliases(item).some((alias) => existingKeys.has(`name:${normalizeWikiItemKey(alias)}`));
}

function getWikiMissingItems(items) {
    const existingKeys = getExistingItemKeys();
    return items
        .filter((item) => !isWikiItemPresent(item, existingKeys))
        .sort((left, right) => String(left.name || "").localeCompare(String(right.name || ""), "it"));
}

function mapWikiItemTypeToFoundry(item) {
    const type = String(item?.type || "").toLowerCase();
    if (type.includes("arma")) return "weapon";
    if (type.includes("pozione") || type.includes("pergamena")) return "consumable";
    if (type.includes("bottino")) return "loot";
    if (type.includes("strumento")) return "tool";
    return "equipment";
}

function mapWikiRarityToFoundry(rarity) {
    const key = normalizeWikiItemKey(rarity);
    const map = {
        comune: "common",
        noncomune: "uncommon",
        raro: "rare",
        epico: "veryRare",
        moltoraro: "veryRare",
        leggendario: "legendary",
        artefatto: "artifact"
    };
    return map[key] || "";
}

function renderWikiItemDescription(item) {
    const parts = [];
    if (item.summary) parts.push(`<p>${escapeHtml(item.summary)}</p>`);
    const properties = Array.isArray(item.properties) ? item.properties.filter((property) => property && property.hidden !== true) : [];
    if (properties.length) {
        parts.push("<hr>");
        properties.forEach((property) => {
            const title = [property.name, property.charges ? `(${property.charges})` : ""].filter(Boolean).join(" ");
            if (title) parts.push(`<h3>${escapeHtml(title)}</h3>`);
            if (property.description) parts.push(`<p>${escapeHtml(property.description)}</p>`);
        });
    }
    if (item.notes) {
        parts.push("<hr>");
        parts.push(`<p><em>${escapeHtml(item.notes)}</em></p>`);
    }
    return parts.join("") || `<p>${escapeHtml(item.name || "Oggetto importato dalla wiki.")}</p>`;
}

function buildFoundryItemDataFromWiki(item, folder) {
    const type = mapWikiItemTypeToFoundry(item);
    const description = renderWikiItemDescription(item);
    const preferredFoundryName = getPreferredFoundryItemName(item);
    const foundryNames = Array.from(new Set([
        preferredFoundryName,
        ...getWikiItemFoundryNames(item)
    ].filter(Boolean)));
    const system = {
        description: {
            value: description,
            unidentified: item.unidentifiedDescription ? `<p>${escapeHtml(item.unidentifiedDescription)}</p>` : "",
            chat: ""
        },
        quantity: 1,
        rarity: mapWikiRarityToFoundry(item.rarity),
        identified: item.unidentified !== true,
        attunement: item.attunement === true ? "required" : "",
        attuned: false
    };

    return {
        name: preferredFoundryName,
        type,
        img: resolveWikiAssetUrl(item.image) || "icons/svg/item-bag.svg",
        folder: folder?.id || null,
        system,
        flags: {
            [MODULE_ID]: {
                wikiItemId: item.id || slugify(item.name),
                wikiItemName: item.name || "",
                preferredFoundryName,
                foundryNames,
                wikiItemUrl: withCampaign(`${getSiteBaseUrl()}/pages/oggetti.html#${encodeURIComponent(item.id || slugify(item.name))}`),
                importedAt: new Date().toISOString()
            }
        }
    };
}

async function getOrCreateWikiItemsFolder() {
    const existing = game.folders.find((folder) => folder.type === "Item" && folder.name === "Cripta Wiki Items");
    if (existing) return existing;
    return Folder.create({ name: "Cripta Wiki Items", type: "Item", sorting: "a" });
}

async function createFoundryItemsFromWiki(items) {
    const folder = await getOrCreateWikiItemsFolder();
    const created = [];
    for (const item of items) {
        const data = buildFoundryItemDataFromWiki(item, folder);
        created.push(await Item.create(data));
    }
    return created;
}

function renderMissingWikiItemsDialog(items) {
    const rows = items.map((item, index) => `
        <label class="cripta-import-item-row">
            <input type="checkbox" name="item" value="${index}" checked>
            ${item.image ? `<img src="${escapeHtml(resolveWikiAssetUrl(item.image))}" alt="">` : `<span class="cripta-import-item-icon"><i class="fas ${escapeHtml(item.icon || "fa-box-open")}"></i></span>`}
            <span>
                <strong>${escapeHtml(item.name || "Oggetto senza nome")}</strong>
                <small>${escapeHtml([
                    `Foundry: ${getPreferredFoundryItemName(item)}`,
                    item.type,
                    item.rarity,
                    item.status === "hidden" ? "Nascosto" : ""
                ].filter(Boolean).join(" | "))}</small>
            </span>
        </label>
    `).join("");

    return `
        <form class="cripta-import-items-form">
            <p>Oggetti presenti nella wiki ma non trovati nel mondo Foundry. Seleziona quelli da creare nella cartella <strong>Cripta Wiki Items</strong>.</p>
            <div class="cripta-import-items-list">${rows}</div>
        </form>
    `;
}

async function openWikiItemsImporter() {
    if (!game.user?.isGM) {
        ui.notifications.warn("Solo il GM puo importare oggetti dalla wiki.");
        return;
    }

    let items;
    try {
        items = getWikiMissingItems(await loadWikiItemsCatalog());
    } catch (error) {
        console.error(`${MODULE_ID} | Import oggetti wiki fallito.`, error);
        ui.notifications.error(`Impossibile leggere gli oggetti dalla wiki: ${error?.message || error}`);
        return;
    }

    if (!items.length) {
        ui.notifications.info("Nessun oggetto wiki mancante in Foundry.");
        return;
    }

    new Dialog({
        title: "Importa oggetti dalla wiki",
        content: renderMissingWikiItemsDialog(items),
        buttons: {
            create: {
                label: "Crea selezionati",
                icon: '<i class="fas fa-file-import"></i>',
                callback: async (html) => {
                    const form = html[0]?.querySelector("form");
                    const indexes = Array.from(new FormData(form).getAll("item")).map((value) => Number(value));
                    const selected = indexes.map((index) => items[index]).filter(Boolean);
                    if (!selected.length) {
                        ui.notifications.warn("Nessun oggetto selezionato.");
                        return;
                    }
                    try {
                        const created = await createFoundryItemsFromWiki(selected);
                        ui.notifications.info(`Creati ${created.length} oggetti dalla wiki.`);
                    } catch (error) {
                        console.error(`${MODULE_ID} | Creazione oggetti wiki fallita.`, error);
                        ui.notifications.error(`Creazione oggetti fallita: ${error?.message || error}`);
                    }
                }
            },
            cancel: {
                label: "Annulla"
            }
        },
        default: "create"
    }, {
        width: 720,
        height: "auto",
        classes: ["cripta-import-items-dialog"]
    }).render(true);
}

async function loadWikiBestiaryCatalog() {
    const normalizeCatalog = (payload) => {
        const creatures = Array.isArray(payload?.data)
            ? payload.data
            : Array.isArray(payload)
                ? payload
                : [];
        return creatures.filter((creature) => creature && typeof creature === "object" && (creature.id || creature.name));
    };

    try {
        const response = await fetch(withCampaign(`${DISCORD_WORKER_URL}/api/data/bestiary`), {
            method: "GET",
            headers: { Accept: "application/json" },
            cache: "no-cache"
        });
        if (!response.ok) throw new Error(`api/data/bestiary HTTP ${response.status}`);
        const creatures = normalizeCatalog(await response.json());
        if (creatures.length) return creatures;
    } catch (error) {
        console.warn(`${MODULE_ID} | Bestiario KV non disponibile, uso JSON statico.`, error);
    }

    const response = await fetch(getSiteDataUrl("bestiary.json"), {
        method: "GET",
        headers: { Accept: "application/json" },
        cache: "no-cache"
    });
    if (!response.ok) throw new Error(`bestiary.json HTTP ${response.status}`);
    return normalizeCatalog(await response.json());
}

function normalizeTransformationOverrides(payload) {
    const list = Array.isArray(payload?.data)
        ? payload.data
        : Array.isArray(payload)
            ? payload
            : [];
    return list
        .filter((entry) => entry && typeof entry === "object" && entry.enabled !== false && entry.tokenImage)
        .map((entry) => ({
            ...entry,
            id: entry.id || `${entry.characterId || entry.ownerAccountId || "player"}-${slugify(entry.creatureName || entry.name || entry.foundryName || "forma")}`,
            actorId: normalizeActorRef(entry.actorId || entry.actorRef || entry.foundryActorId || ""),
            entityId: String(entry.entityId || "").trim(),
            ownerCharacterId: slugify(entry.ownerCharacterId || ""),
            tokenImage: resolveWikiAssetUrl(entry.tokenImage),
            names: [
                entry.creatureName,
                entry.name,
                entry.foundryName,
                ...(Array.isArray(entry.foundryNames) ? entry.foundryNames : []),
                ...(Array.isArray(entry.aliases) ? entry.aliases : [])
            ].map(normalizeWikiItemKey).filter(Boolean),
            ownerAliases: [
                entry.characterId,
                entry.ownerCharacterId,
                entry.entityId,
                entry.actorId,
                entry.ownerAccountId,
                entry.ownerDiscordId,
                ...(Array.isArray(entry.ownerAliases) ? entry.ownerAliases : [])
            ].map(normalizeWikiItemKey).filter(Boolean),
            isCompanion: entry.isCompanion === true
                || String(entry.characterId || "").startsWith("companion-")
                || String(entry.entityType || "") === "companion",
            switcher: entry.switcher !== false,
            label: String(entry.label || entry.creatureName || entry.name || entry.foundryName || "").trim(),
            size: getTransformationTokenSize(entry)
        }))
        .filter((entry) => entry.tokenImage && entry.names.length && (entry.ownerAliases.length || entry.actorId));
}

async function loadWikiTransformationOverrides({ force = false, online = false } = {}) {
    const includeOnline = force || online === true;
    const maxAgeMs = includeOnline ? 60 * 1000 : 10 * 60 * 1000;
    if (!force && transformationOverrideCache.loadedAt && Date.now() - transformationOverrideCache.loadedAt < maxAgeMs) {
        return transformationOverrideCache.data;
    }
    if (!force && transformationOverrideCache.promise) return transformationOverrideCache.promise;

    transformationOverrideCache.promise = (async () => {
        let staticData = [];
        try {
            const response = await fetch(getSiteDataUrl("transformations.json"), {
                method: "GET",
                headers: { Accept: "application/json" },
                cache: "no-cache"
            });
            if (response.ok) staticData = normalizeTransformationOverrides(await response.json());
        } catch (error) {
            console.warn(`${MODULE_ID} | transformations.json non disponibile.`, error);
        }

        let onlineData = [];
        if (includeOnline) {
            try {
                const response = await fetch(withCampaign(`${DISCORD_WORKER_URL}/api/data/transformations`), {
                    method: "GET",
                    headers: { Accept: "application/json" },
                    cache: "no-cache"
                });
                if (response.ok) onlineData = normalizeTransformationOverrides(await response.json());
            } catch (error) {
                console.warn(`${MODULE_ID} | Trasformazioni KV non disponibili.`, error);
            }
        }

        const merged = new Map();
        [...staticData, ...onlineData].forEach((entry) => merged.set(entry.id, entry));
        transformationOverrideCache.data = Array.from(merged.values());
        transformationOverrideCache.loadedAt = Date.now();
        return transformationOverrideCache.data;
    })();

    try {
        return await transformationOverrideCache.promise;
    } finally {
        transformationOverrideCache.promise = null;
    }
}

function getExistingActorKeys() {
    const keys = new Set();
    game.actors.forEach((actor) => {
        const wikiId = actor.getFlag?.(MODULE_ID, "wikiBestiaryId");
        if (wikiId) keys.add(`id:${String(wikiId)}`);
        [actor.name, actor.getFlag?.(MODULE_ID, "wikiBestiaryName")]
            .filter(Boolean)
            .forEach((name) => keys.add(`name:${normalizeWikiItemKey(name)}`));
    });
    return keys;
}

function isWikiCreatureImportable(creature, existingKeys = getExistingActorKeys()) {
    if (creature.hidden === true || creature.discovered === false) return false;
    if (!creature.foundry || typeof creature.foundry !== "object") return false;
    if (creature.id && existingKeys.has(`id:${String(creature.id)}`)) return false;
    const names = [
        creature.name,
        creature.foundryName,
        ...(Array.isArray(creature.foundryName) ? creature.foundryName : []),
        ...(Array.isArray(creature.aliases) ? creature.aliases : [])
    ].filter(Boolean);
    return !names.some((name) => existingKeys.has(`name:${normalizeWikiItemKey(name)}`));
}

function getWikiMissingCreatures(creatures) {
    const existingKeys = getExistingActorKeys();
    return creatures
        .filter((creature) => isWikiCreatureImportable(creature, existingKeys))
        .sort((left, right) => String(left.name || "").localeCompare(String(right.name || ""), "it"));
}

function mapWikiCreatureSizeToFoundry(value) {
    const key = normalizeWikiItemKey(value);
    if (key.includes("minuscol")) return "tiny";
    if (key.includes("piccol")) return "sm";
    if (key.includes("grand")) return "lg";
    if (key.includes("enorme")) return "huge";
    if (key.includes("mastodont") || key.includes("gargant")) return "grg";
    return "med";
}

function buildFoundryActorDataFromWikiCreature(creature, folder) {
    const foundry = creature.foundry || {};
    const details = creature.details || {};
    const actorItems = Array.isArray(foundry.abilitiesList)
        ? foundry.abilitiesList.map((ability) => buildFoundryActorItemFromWikiAbility(ability, foundry))
        : [];
    const damageAbsorptions = getWikiPassiveAbsorptions(foundry.abilitiesList);
    const damageAbsorptionSet = new Set(damageAbsorptions);
    const damageImmunities = Array.from(new Set([
        ...normalizeWikiDamageTypeList(details.immunities),
        ...damageAbsorptions
    ]));
    const size = foundry.size || mapWikiCreatureSizeToFoundry(details.size);
    const actorImage = resolveWikiAssetUrl(creature.image) || "icons/svg/mystery-man.svg";
    const tokenImage = resolveWikiAssetUrl(creature.tokenImage || creature.image) || actorImage;

    return {
        name: creature.name || "Creatura wiki",
        type: "npc",
        img: actorImage,
        folder: folder?.id || null,
        system: {
            abilities: foundry.abilities || {},
            attributes: {
                ac: { flat: toLeadingNumberOrNull(foundry.ac) || 10, calc: "flat" },
                hp: {
                    value: Number(foundry.hp?.value) || 1,
                    max: Number(foundry.hp?.value) || 1,
                    formula: String(foundry.hp?.formula || "")
                },
                movement: {
                    walk: Number(foundry.movement?.walk) || 30,
                    fly: Number(foundry.movement?.fly) || 0,
                    swim: Number(foundry.movement?.swim) || 0,
                    climb: Number(foundry.movement?.climb) || 0,
                    burrow: 0,
                    units: "ft",
                    hover: false
                },
                prof: Number(foundry.prof) || null
            },
            details: {
                cr: String(foundry.cr || ""),
                biography: { value: details.description ? `<p>${escapeHtml(details.description)}</p>` : "" },
                source: "Sigillo del Male Wiki"
            },
            traits: {
                size,
                languages: { value: [], custom: String(foundry.languages || "") },
                di: { value: damageImmunities, custom: "" },
                dr: { value: normalizeWikiDamageTypeList(details.resistances).filter((type) => !damageAbsorptionSet.has(type)), custom: "" },
                dv: { value: normalizeWikiDamageTypeList(details.vulnerabilities).filter((type) => !damageAbsorptionSet.has(type)), custom: "" },
                da: { value: [], custom: "", bypasses: [] },
                ci: { value: [], custom: "" }
            },
            skills: foundry.skills || {}
        },
        prototypeToken: {
            name: creature.name || "Creatura wiki",
            displayName: 20,
            displayBars: 20,
            width: { tiny: 0.5, sm: 1, med: 1, lg: 2, huge: 3, grg: 4 }[size] || 1,
            height: { tiny: 0.5, sm: 1, med: 1, lg: 2, huge: 3, grg: 4 }[size] || 1,
            texture: { src: tokenImage },
            actorLink: false
        },
        items: actorItems,
        effects: [],
        flags: {
            ...(foundry.flags || {}),
            [MODULE_ID]: {
                ...(foundry.flags?.[MODULE_ID] || {}),
                wikiBestiaryId: creature.id || slugify(creature.name),
                wikiBestiaryName: creature.name || "",
                wikiBestiaryUrl: withCampaign(`${getSiteBaseUrl()}/pages/bestiary/creature.html?id=${encodeURIComponent(creature.id || slugify(creature.name))}`),
                importedAt: new Date().toISOString(),
                damageAbsorptions
            }
        }
    };
}

function getWikiPassiveAbsorptions(abilities) {
    return (Array.isArray(abilities) ? abilities : [])
        .map((ability) => buildWikiPassiveFlags(ability))
        .filter((passive) => passive.enabled && passive.id === "absorption" && passive.value)
        .map((passive) => passive.value)
        .filter((value, index, list) => list.indexOf(value) === index);
}

function buildFoundryActorItemFromWikiAbility(ability, foundry = {}) {
    if (ability?.foundryItem && typeof ability.foundryItem === "object") {
        const itemData = foundry.utils.deepClone(ability.foundryItem);
        delete itemData._id;
        delete itemData.folder;
        delete itemData.sort;
        itemData.name = itemData.name || ability.name || "Abilita";
        itemData.img = resolveWikiAssetUrl(ability.iconImage || ability.img) || itemData.img || "icons/svg/aura.svg";
        return itemData;
    }

    const description = buildWikiAbilityDescription(ability);
    const type = foundryItemTypeFromWikiAbility(ability);
    const effects = buildWikiPassiveEffects(ability, foundry);
    const system = {
        description: { value: description, chat: "" },
        source: { custom: "Sigillo del Male Wiki", revision: 1, rules: "2024" },
        uses: { spent: 0, max: "", recovery: [] },
        activities: buildWikiAbilityActivities(ability, type, effects),
        identifier: "",
        requirements: "",
        type: foundryItemSubtypeFromWikiAbility(type)
    };
    if (type === "weapon") {
        const damageParts = getWikiAbilityDamageParts(ability).filter((part) => part.formula);
        system.quantity = 1;
        system.weight = { value: 0, units: "lb" };
        system.price = { value: 0, denomination: "gp" };
        system.attunement = "";
        system.equipped = true;
        system.rarity = "";
        system.identified = true;
        system.range = buildWikiAbilityWeaponRange(ability);
        system.damage = {
            base: wikiDamageFormulaToDnd5ePart(damageParts[0]?.formula || ability.damageFormula || "", damageParts[0]?.type || ability.damageType || ""),
            versatile: {
                number: null,
                denomination: null,
                types: [],
                custom: { enabled: false },
                scaling: { number: 1 }
            }
        };
        system.unidentified = { description: "" };
        system.container = null;
        system.attuned = false;
        system.cover = null;
        system.crewed = false;
        system.ammunition = {};
        system.armor = { value: null };
        system.magicalBonus = null;
        system.properties = [];
        system.proficient = true;
        system.weaponType = "natural";
        system.actionType = inferWikiAbilityActionType(ability);
        system.attackBonus = ability.attackBonus || "";
    } else {
        system.activation = { type: ability.activation || activationFromWikiAbilitySection(ability.section), cost: 1, condition: "" };
        system.target = { value: null, width: null, units: "", type: ability.target || "" };
        system.range = { value: parseWikiAbilityRangeValue(ability.range), long: null, units: parseWikiAbilityRangeUnits(ability.range) };
        system.consume = { type: "", target: "", amount: null };
        system.actionType = inferWikiAbilityActionType(ability);
        system.attackBonus = ability.attackBonus || "";
        system.damage = {
            parts: buildFoundryDamagePartsFromWikiAbility(ability),
            versatile: ""
        };
        system.save = {
            ability: ability.saveAbility || ability.rider?.saveAbility || "",
            dc: Number(ability.saveDc || ability.rider?.saveDc) || null,
            scaling: ability.saveDc || ability.rider?.saveDc ? "flat" : ""
        };
        system.advancement = [];
        system.cover = null;
        system.crewed = false;
        system.enchant = {};
        system.prerequisites = { level: null, repeatable: false };
        system.properties = [];
    }
    const item = {
        name: ability.name || "Abilita",
        type,
        img: resolveWikiAssetUrl(ability.iconImage || ability.img) || "icons/svg/aura.svg",
        system,
        effects,
        flags: {
            "midi-qol": {},
            dae: {},
            dnd5e: { persistSourceMigration: true },
            [MODULE_ID]: {
                riders: buildWikiRiderFlags(ability),
                passive: buildWikiPassiveFlags(ability)
            },
            ...(ability.flags || {})
        }
    }
    return item;
}

function buildWikiAbilityDescription(ability) {
    const lines = [];
    const base = ability.description ? `<p>${escapeHtml(ability.description)}</p>` : "";
    const passive = buildWikiPassiveFlags(ability);
    if (passive.enabled && passive.value && passive.valueLabel) {
        const displayValue = passive.id === "absorption"
            ? (WIKI_DAMAGE_TYPE_LABELS[passive.value] || passive.value)
            : passive.value;
        lines.push(`${escapeHtml(passive.valueLabel)}: ${escapeHtml(displayValue)}.`);
    }
    if (passive.id === "regeneration" && passive.breakDamageTypes?.length) {
        const labels = passive.breakDamageTypes.map((type) => WIKI_DAMAGE_TYPE_LABELS[type] || type).join(", ");
        lines.push(`Interrotta fino al prossimo turno da: ${escapeHtml(labels)}.`);
    }
    if (!lines.length) return base;
    return [base, `<hr><p><strong>Effetti passivi.</strong> ${lines.join(" ")}</p>`].filter(Boolean).join("");
}

function buildWikiPassiveFlags(ability) {
    const passive = ability?.passive && typeof ability.passive === "object" ? ability.passive : {};
    const id = String(passive.id || "").trim();
    if (!id) return { enabled: false };
    return {
        enabled: true,
        id,
        automation: passive.automation || "manual",
        value: String(ability.passiveValue || "").trim(),
        valueLabel: ability.passiveValueLabel || passive.valueLabel || "",
        breakDamageTypes: normalizeWikiDamageTypeList(ability.passiveBreakDamageTypes)
    };
}

function buildWikiPassiveEffects(ability, foundry = {}) {
    const passive = buildWikiPassiveFlags(ability);
    if (!passive.enabled) return [];
    if (passive.id === "magic-resistance") {
        return [buildWikiTransferEffect("Magic Resistance", "icons/magic/defensive/shield-barrier-glowing-blue.webp", [
            { key: "flags.midi-qol.magicResistance.all", mode: 0, value: "1", priority: 20 }
        ])];
    }
    if (passive.id === "enlarge") {
        const changes = [
            { key: "system.traits.size", mode: 5, value: nextWikiFoundrySize(foundry.size), priority: 20 }
        ];
        if (passive.value) {
            changes.push(
                { key: "system.bonuses.mwak.damage", mode: 2, value: passive.value, priority: 20 },
                { key: "system.bonuses.rwak.damage", mode: 2, value: passive.value, priority: 20 }
            );
        }
        return [buildWikiTemporaryEffect("Enlarge", "icons/magic/control/buff-strength-muscle-damage.webp", changes, {
            seconds: 60,
            rounds: 10
        })];
    }
    if (passive.id === "absorption" && passive.value) {
        return [];
    }
    return [];
}

function nextWikiFoundrySize(size) {
    const order = ["tiny", "sm", "med", "lg", "huge", "grg"];
    const index = order.indexOf(size || "med");
    return order[Math.min(order.length - 1, Math.max(0, index) + 1)] || "lg";
}

function buildWikiTemporaryEffect(name, img, changes, duration = {}) {
    return {
        ...buildWikiTransferEffect(name, img, changes),
        transfer: false,
        duration: {
            startTime: null,
            seconds: duration.seconds ?? null,
            combat: null,
            rounds: duration.rounds ?? null,
            turns: duration.turns ?? null,
            startRound: null,
            startTurn: null
        }
    };
}

function normalizeWikiDamageTypeList(value) {
    const values = Array.isArray(value) ? value : String(value || "").split(/[;,|]/);
    return values
        .map((entry) => String(entry || "").trim().toLowerCase())
        .filter((entry) => Object.prototype.hasOwnProperty.call(WIKI_DAMAGE_TYPE_LABELS, entry))
        .filter((entry, index, list) => list.indexOf(entry) === index);
}

function buildWikiTransferEffect(name, img, changes) {
    return {
        _id: `effect${slugify(name).replace(/-/g, "").slice(0, 10).padEnd(10, "0")}`,
        name,
        img,
        origin: null,
        disabled: false,
        transfer: true,
        description: "",
        tint: "#ffffff",
        statuses: [],
        changes,
        duration: { startTime: null, seconds: null, combat: null, rounds: null, turns: null, startRound: null, startTurn: null },
        flags: {
            dae: { showIcon: true, specialDuration: [] },
            "midi-qol": {},
            core: { overlay: false }
        },
        type: "base",
        system: {},
        sort: 0
    };
}

function buildWikiRiderFlags(ability) {
    const rider = ability.rider || {};
    return {
        enabled: true,
        alwaysConditions: normalizeWikiConditionList(rider.alwaysConditions),
        failConditions: normalizeWikiConditionList(rider.failConditions),
        saveAbility: rider.saveAbility || "",
        saveDc: rider.saveDc || "",
        successMode: rider.successMode || "",
        failDamageParts: getWikiAbilityRiderDamageParts(ability).filter((part) => part.formula),
        advancedEffects: normalizeWikiAdvancedRiderEffects(rider.advancedEffects),
        notes: rider.notes || ""
    };
}

function normalizeWikiAdvancedRiderEffects(effects) {
    return (Array.isArray(effects) ? effects : [])
        .map((effect) => ({
            id: slugify(effect?.id || effect?.name || "advanced-effect"),
            name: String(effect?.name || "Effetto avanzato"),
            timing: String(effect?.timing || "hit"),
            kind: String(effect?.kind || "effect"),
            iconImage: effect?.iconImage || "",
            duration: effect?.duration || {},
            changes: normalizeWikiAdvancedEffectChanges(effect),
            damage: effect?.damage || null,
            endsOnDamageType: effect?.endsOnDamageType || ""
        }));
}

function normalizeWikiAdvancedEffectChanges(effect) {
    const id = String(effect?.id || "");
    return (Array.isArray(effect?.changes) ? effect.changes : []).map((change) => {
        const normalized = { ...change };
        const key = String(normalized.key || "");
        if (id === "half-speed" && key.startsWith("system.attributes.movement.") && String(normalized.value) === "0.5") {
            normalized.mode = 1;
        }
        return normalized;
    });
}

function foundryItemTypeFromWikiAbility(ability) {
    return isWikiAttackAbility(ability) ? "weapon" : (ability.type || "feat");
}

function foundryItemSubtypeFromWikiAbility(type) {
    if (type === "weapon") return { value: "natural", baseItem: "" };
    return { value: "", subtype: "" };
}

function isWikiAttackAbility(ability) {
    return ability?.kind === "attack" || ability?.type === "weapon" || Boolean(ability?.attackBonus);
}

function inferWikiAbilityActionType(ability) {
    if (isWikiAttackAbility(ability)) return isWikiRangedAttackAbility(ability) ? "rwak" : "mwak";
    if (ability.saveAbility || ability.rider?.saveAbility) return "save";
    if (ability.damageFormula || getWikiAbilityDamageParts(ability).some((part) => part.formula)) return "other";
    return "other";
}

function isWikiRangedAttackAbility(ability) {
    const range = String(ability?.range || "").toLowerCase();
    if (range.includes("/")) return true;
    const value = parseWikiAbilityRangeValue(range);
    return Number.isFinite(value) && value > 10;
}

function buildFoundryDamagePartsFromWikiAbility(ability) {
    const parts = getWikiAbilityDamageParts(ability)
        .filter((part) => part.formula)
        .map((part) => [part.formula, part.type || ""]);
    if (parts.length) return parts;
    return ability.damageFormula ? [[ability.damageFormula, ability.damageType || ""]] : [];
}

function buildWikiAbilityActivities(ability, type, effects) {
    if (type === "weapon") {
        const activities = { dnd5eactivity000: buildWikiAbilityAttackActivity(ability, effects) };
        if (hasWikiAbilitySaveRider(ability)) activities.dnd5eactivity001 = buildWikiAbilitySaveActivity(ability, effects, "dnd5eactivity001", { includeBaseDamage: false });
        return activities;
    }
    if (ability.saveAbility || ability.rider?.saveAbility) return { dnd5eactivity000: buildWikiAbilitySaveActivity(ability, effects) };
    return { dnd5eactivity000: buildWikiAbilityUtilityActivity(ability, effects) };
}

function buildWikiAbilityAttackActivity(ability, effects) {
    const ranged = isWikiRangedAttackAbility(ability);
    const attackAbility = ability.attackAbility === "custom" ? "" : (ability.attackAbility || "str");
    const damageParts = getWikiAbilityDamageParts(ability).filter((part) => part.formula);
    return {
        _id: "dnd5eactivity000",
        type: "attack",
        activation: buildWikiActivityActivation(ability),
        consumption: buildWikiActivityConsumption(),
        description: { chatFlavor: "" },
        duration: buildWikiInstantDuration(),
        effects: [],
        range: { units: ranged ? "ft" : "self", special: "", override: false, ...(ranged ? { value: parseWikiAbilityRangeValue(ability.range) || "" } : {}) },
        target: buildWikiSingleCreatureTarget(),
        uses: { spent: 0, max: "", recovery: [] },
        attack: {
            ability: attackAbility,
            bonus: ability.attackAbility === "custom" ? (ability.attackBonus || "") : (ability.attackBonusExtra || ""),
            critical: { threshold: null },
            flat: ability.attackAbility === "custom",
            type: { value: ranged ? "ranged" : "melee", classification: "weapon" }
        },
        damage: {
            critical: { bonus: "" },
            includeBase: true,
            parts: damageParts.slice(1).map((part) => wikiDamageFormulaToDnd5ePart(part.formula, part.type))
        },
        sort: 0,
        ...wikiMidiActivityDefaults(),
        attackMode: "oneHanded",
        ammunition: "",
        otherActivityUuid: ""
    };
}

function buildWikiAbilitySaveActivity(ability, effects, activityId = "dnd5eactivity000", options = {}) {
    const rider = ability.rider || {};
    const damageParts = [
        ...(options.includeBaseDamage === false ? [] : getWikiAbilityDamageParts(ability).filter((part) => part.formula)),
        ...getWikiAbilityRiderDamageParts(ability).filter((part) => part.formula)
    ];
    return {
        _id: activityId,
        type: "save",
        activation: buildWikiActivityActivation(ability),
        consumption: buildWikiActivityConsumption(),
        description: { chatFlavor: "" },
        duration: buildWikiInstantDuration(),
        effects: buildWikiSaveActivityEffectRefs(effects),
        range: { value: parseWikiAbilityRangeValue(ability.range) || "", units: parseWikiAbilityRangeUnits(ability.range) || "ft", special: "", override: false },
        target: buildWikiSingleCreatureTarget(),
        uses: { spent: 0, max: "", recovery: [] },
        damage: {
            onSave: rider.successMode === "negates" ? "none" : "half",
            parts: damageParts.map((part) => wikiDamageFormulaToDnd5ePart(part.formula, part.type)),
            critical: { allow: false }
        },
        save: {
            ability: [ability.saveAbility || rider.saveAbility || "con"],
            dc: { calculation: "", formula: String(ability.saveDc || rider.saveDc || "") }
        },
        sort: 0,
        ...wikiMidiActivityDefaults()
    };
}

function hasWikiAbilitySaveRider(ability) {
    const rider = ability.rider || {};
    return Boolean(
        rider.saveAbility
        || rider.saveDc
        || getWikiAbilityRiderDamageParts(ability).some((part) => part.formula)
        || normalizeWikiConditionList(rider.failConditions).length
    );
}

function buildWikiAbilityUtilityActivity(ability, effects) {
    return {
        _id: "dnd5eactivity000",
        type: "utility",
        activation: buildWikiActivityActivation(ability),
        consumption: buildWikiActivityConsumption(),
        description: { chatFlavor: "" },
        duration: buildWikiInstantDuration(),
        effects: effects.map((effect) => ({ _id: effect._id })),
        range: { units: "self", special: "", override: false },
        target: buildWikiSingleCreatureTarget(),
        uses: { spent: 0, max: "", recovery: [] },
        roll: { formula: "", name: "", prompt: false, visible: false },
        sort: 0,
        ...wikiMidiActivityDefaults(),
        otherActivityId: "none"
    };
}

function buildWikiSaveActivityEffectRefs(effects) {
    return [];
}

function buildWikiActivityActivation(ability) {
    return { type: ability.activation || activationFromWikiAbilitySection(ability.section), value: 1, condition: "", override: false };
}

function buildWikiActivityConsumption() {
    return { targets: [], scaling: { allowed: false, max: "" }, spellSlot: true };
}

function buildWikiInstantDuration() {
    return { concentration: false, units: "inst", special: "", override: false };
}

function buildWikiSingleCreatureTarget() {
    return {
        template: { count: "", contiguous: false, type: "", size: "", width: "", height: "", units: "" },
        affects: { count: "1", type: "creature", choice: false, special: "" },
        prompt: true,
        override: false
    };
}

function wikiMidiActivityDefaults() {
    return {
        useConditionText: "",
        useConditionReason: "",
        effectConditionText: "",
        macroData: { name: "", command: "" },
        ignoreTraits: { idi: false, idr: false, idv: false, ida: false },
        midiProperties: {
            ignoreTraits: [],
            triggeredActivityId: "none",
            triggeredActivityConditionText: "",
            triggeredActivityTargets: "targets",
            triggeredActivityRollAs: "self",
            forceDialog: false,
            confirmTargets: "default",
            autoTargetType: "any",
            autoTargetAction: "default",
            automationOnly: false,
            otherActivityCompatible: true,
            identifier: "",
            displayActivityName: false,
            rollMode: "default",
            chooseEffects: false,
            toggleEffect: false,
            ignoreFullCover: false
        },
        isOverTimeFlag: false,
        overTimeProperties: { saveRemoves: true, preRemoveConditionText: "", postRemoveConditionText: "" },
        otherActivityId: ""
    };
}

function buildWikiAbilityItemEffects(ability) {
    const rider = ability.rider || {};
    const effects = [];
    const always = normalizeWikiConditionList(rider.alwaysConditions);
    always.forEach((condition) => {
        effects.push({ ...buildWikiConditionEffect(`${ability.name || "Attack"} ${condition}`, [condition], "Applied on hit."), _applyOn: "hit" });
    });
    const failed = normalizeWikiConditionList(rider.failConditions);
    failed.forEach((condition) => {
        effects.push({ ...buildWikiConditionEffect(`${ability.name || "Effect"} ${condition}`, [condition], "Applied on a failed save."), _applyOn: "failedSave" });
    });
    return effects.map((effect, index) => ({ ...effect, _id: `effect${String(index + 1).padStart(10, "0")}` }));
}

function stripWikiInternalEffectMeta(effect) {
    const { _applyOn, ...cleanEffect } = effect;
    return cleanEffect;
}

function buildWikiConditionEffect(name, statuses, description) {
    return {
        name,
        img: wikiConditionEffectIcon(statuses),
        origin: null,
        disabled: false,
        transfer: false,
        description,
        tint: "#ffffff",
        statuses,
        changes: wikiConditionChanges(statuses),
        duration: { startTime: null, seconds: null, combat: null, rounds: null, turns: null, startRound: null, startTurn: null },
        flags: { dae: {}, "midi-qol": {} },
        type: "base",
        system: {},
        sort: 0
    };
}

function wikiConditionChanges(statuses) {
    if (!statuses.includes("grappled")) return [];
    return ["walk", "fly", "swim", "climb", "burrow"].map((movement) => ({
        key: `system.attributes.movement.${movement}`,
        mode: 5,
        value: "0",
        priority: 20
    }));
}

function wikiConditionEffectIcon(statuses) {
    if (statuses.includes("grappled") || statuses.includes("restrained")) return "icons/svg/net.svg";
    if (statuses.includes("prone")) return "icons/svg/falling.svg";
    if (statuses.includes("poisoned")) return "icons/svg/poison.svg";
    if (statuses.includes("frightened")) return "icons/svg/terror.svg";
    return "icons/svg/aura.svg";
}

function wikiDamageFormulaToDnd5ePart(formula, type) {
    const cleanFormula = String(formula || "").trim();
    const match = cleanFormula.match(/^(\d+)d(\d+)\s*([+-]\s*\d+)?$/i);
    if (match) {
        return {
            number: Number(match[1]),
            denomination: Number(match[2]),
            bonus: match[3] ? match[3].replace(/\s+/g, "") : "",
            types: type ? [type] : [],
            custom: { enabled: false, formula: "" },
            scaling: { mode: "whole", number: null, formula: "" }
        };
    }
    return {
        number: null,
        denomination: null,
        bonus: "",
        types: type ? [type] : [],
        custom: { enabled: Boolean(cleanFormula), formula: cleanFormula },
        scaling: { mode: "whole", number: null, formula: "" }
    };
}

function buildWikiAbilityWeaponRange(ability) {
    if (isWikiRangedAttackAbility(ability)) {
        return { value: parseWikiAbilityRangeValue(ability.range), long: null, units: parseWikiAbilityRangeUnits(ability.range) || "ft" };
    }
    return { value: null, long: null, units: "self", reach: parseWikiAbilityRangeValue(ability.range) || 5 };
}

function getWikiAbilityDamageParts(ability) {
    const parts = Array.isArray(ability?.damageParts) ? ability.damageParts : [];
    return parts.map((part) => ({
        formula: String(part?.formula || part?.damage || "").trim(),
        type: String(part?.type || part?.damageType || "").trim()
    }));
}

function getWikiAbilityRiderDamageParts(ability) {
    const parts = Array.isArray(ability?.rider?.failDamageParts) ? ability.rider.failDamageParts : [];
    return parts.map((part) => ({
        formula: String(part?.formula || part?.damage || "").trim(),
        type: String(part?.type || part?.damageType || "").trim()
    }));
}

function normalizeWikiConditionList(values) {
    const aliases = {
        accecato: "blinded",
        affascinato: "charmed",
        assordato: "deafened",
        spaventato: "frightened",
        afferrato: "grappled",
        incapacitato: "incapacitated",
        invisibile: "invisible",
        paralizzato: "paralyzed",
        pietrificato: "petrified",
        avvelenato: "poisoned",
        prono: "prone",
        trattenuto: "restrained",
        stordito: "stunned",
        "privo-di-sensi": "unconscious",
        indebolimento: "exhaustion"
    };
    return (Array.isArray(values) ? values : [])
        .map((value) => {
            const key = slugify(value);
            return aliases[key] || key;
        })
        .filter(Boolean)
        .filter((value, index, list) => list.indexOf(value) === index);
}

function parseWikiAbilityRangeValue(value) {
    return toLeadingNumberOrNull(value);
}

function parseWikiAbilityRangeUnits(value) {
    return String(value || "").trim() ? "ft" : "";
}

function activationFromWikiAbilitySection(section) {
    return {
        bonus: "bonus",
        reaction: "reaction",
        legendary: "legendary"
    }[section] || "action";
}

async function getOrCreateWikiCreaturesFolder() {
    const existing = game.folders.find((folder) => folder.type === "Actor" && folder.name === "Cripta Wiki Bestiario");
    if (existing) return existing;
    return Folder.create({ name: "Cripta Wiki Bestiario", type: "Actor", sorting: "a" });
}

async function createFoundryActorsFromWikiCreatures(creatures) {
    const folder = await getOrCreateWikiCreaturesFolder();
    const created = [];
    for (const creature of creatures) {
        const data = buildFoundryActorDataFromWikiCreature(creature, folder);
        const actor = await Actor.create(data);
        const entityId = creature.id || slugify(creature.name || actor.name || actor.id);
        const effectiveAvatar = await resolveAndRegisterManagedMedia(actor, "avatar", {
            remote: creature.image,
            local: actor.img,
            entityType: "bestiary",
            entityId,
            actor,
            name: creature.name || actor.name,
            downloadFallback: true
        });
        const effectiveToken = await resolveAndRegisterManagedMedia(actor, "token", {
            remote: creature.tokenImage || creature.image,
            local: actor.prototypeToken?.texture?.src || "",
            entityType: "bestiary",
            entityId,
            actor,
            name: creature.name || actor.name,
            downloadFallback: true
        });
        const patch = {};
        if (effectiveAvatar && effectiveAvatar !== actor.img) patch.img = effectiveAvatar;
        if (effectiveToken && effectiveToken !== actor.prototypeToken?.texture?.src) patch["prototypeToken.texture.src"] = effectiveToken;
        if (Object.keys(patch).length) await actor.update(patch);
        created.push(actor);
    }
    return created;
}

function mapFoundrySizeToWikiSize(value) {
    const key = String(value || "").toLowerCase();
    const map = {
        tiny: "Minuscola",
        sm: "Piccola",
        small: "Piccola",
        med: "Media",
        medium: "Media",
        lg: "Grande",
        large: "Grande",
        huge: "Enorme",
        grg: "Mastodontica",
        gargantuan: "Mastodontica"
    };
    return map[key] || "Media";
}

function mapFoundryTypeToWikiType(value) {
    const raw = typeof value === "object" && value ? (value.value || value.custom || value.subtype || "") : value;
    const key = normalizeWikiItemKey(raw);
    const map = {
        aberration: "Aberrazione",
        beast: "Bestia",
        celestial: "Celestiale",
        construct: "Costrutto",
        dragon: "Drago",
        elemental: "Elementale",
        fey: "Folletto",
        fiend: "Immondo",
        giant: "Gigante",
        humanoid: "Umanoide",
        monstrosity: "Mostruosita",
        ooze: "Melma",
        plant: "Pianta",
        undead: "Non morto"
    };
    return map[key] || String(raw || "Creatura").trim();
}

function mapFoundryDamageListToWikiLabels(values) {
    return (Array.isArray(values) ? values : [])
        .map((value) => WIKI_DAMAGE_TYPE_LABELS[String(value || "").trim().toLowerCase()] || String(value || "").trim())
        .filter(Boolean);
}

function mapFoundryConditionListToWikiLabels(values) {
    const labels = {
        blinded: "Accecato",
        charmed: "Affascinato",
        deafened: "Assordato",
        frightened: "Spaventato",
        grappled: "Afferrato",
        incapacitated: "Incapacitato",
        invisible: "Invisibile",
        paralyzed: "Paralizzato",
        petrified: "Pietrificato",
        poisoned: "Avvelenato",
        prone: "Prono",
        restrained: "Trattenuto",
        stunned: "Stordito",
        unconscious: "Privo di sensi",
        exhaustion: "Indebolimento"
    };
    return (Array.isArray(values) ? values : [])
        .map((value) => labels[String(value || "").trim().toLowerCase()] || String(value || "").trim())
        .filter(Boolean);
}

function stripFoundryHtml(value) {
    const html = String(value || "").trim();
    if (!html) return "";
    const element = document.createElement("div");
    element.innerHTML = html;
    return String(element.textContent || element.innerText || "").replace(/\s+/g, " ").trim();
}

function getFoundryDescriptionHtml(document) {
    return String(document?.system?.description?.value || document?.system?.details?.biography?.value || "").trim();
}

function getActorMovementValue(actor, key) {
    const value = actor?.system?.attributes?.movement?.[key];
    if (typeof value === "object" && value) return Number(value.value) || 0;
    return Number(value) || 0;
}

function getActorSensesData(actor) {
    const senses = actor?.system?.attributes?.senses || {};
    return Object.fromEntries(Object.entries(senses)
        .filter(([, value]) => Number(typeof value === "object" && value ? value.value : value) > 0)
        .map(([key, value]) => [key, Number(typeof value === "object" && value ? value.value : value) || 0]));
}

function getActorTraitsList(actor, key) {
    const trait = actor?.system?.traits?.[key];
    if (Array.isArray(trait?.value)) return trait.value;
    if (trait?.value instanceof Set) return Array.from(trait.value);
    return [];
}

function buildWikiAbilityFromFoundryItem(item) {
    const itemData = item.toObject();
    const activities = Object.values(itemData.system?.activities || {});
    const primaryActivity = activities[0] || {};
    const descriptionHtml = getFoundryDescriptionHtml(itemData);
    const type = String(itemData.type || "");
    const kind = primaryActivity.type === "attack"
        ? "attack"
        : primaryActivity.type === "save"
            ? "save"
            : type === "spell"
                ? "spell"
                : "passive";

    return {
        id: slugify(item.name || item.id || "abilita"),
        name: item.name || "Abilita",
        kind,
        type,
        iconImage: item.img || "",
        description: stripFoundryHtml(descriptionHtml),
        foundryItem: itemData
    };
}

function buildWikiBestiaryEntryFromActor(actor, imagePath = "", tokenImagePath = "") {
    const actorData = actor.toObject();
    const system = actorData.system || {};
    const prototypeToken = actorData.prototypeToken || {};
    const attributes = system.attributes || {};
    const details = system.details || {};
    const abilitiesList = actor.items
        .filter((item) => ["feat", "weapon", "spell"].includes(item.type))
        .map(buildWikiAbilityFromFoundryItem);
    const hp = attributes.hp || {};
    const acValue = attributes.ac?.flat ?? attributes.ac?.value ?? attributes.ac?.calc ?? "";
    const size = system.traits?.size || (prototypeToken.width >= 3 ? "huge" : "med");
    const descriptionHtml = getFoundryDescriptionHtml(actorData);

    const entry = {
        id: slugify(actor.name || actor.id || "creatura"),
        name: actor.name || "Creatura Foundry",
        image: imagePath || extractWorkerMediaPath(actor.img) || actor.img || "",
        tokenImage: tokenImagePath || extractWorkerMediaPath(prototypeToken.texture?.src) || prototypeToken.texture?.src || "",
        imageAdjust: { x: 50, y: 50 },
        details: {
            description: stripFoundryHtml(descriptionHtml) || `Voce generata da Foundry per ${actor.name}.`,
            dndType: mapFoundryTypeToWikiType(details.type),
            size: mapFoundrySizeToWikiSize(system.traits?.size),
            traits: [],
            drops: [],
            resistances: mapFoundryDamageListToWikiLabels(getActorTraitsList(actor, "dr")),
            immunities: mapFoundryDamageListToWikiLabels(getActorTraitsList(actor, "di")),
            vulnerabilities: mapFoundryDamageListToWikiLabels(getActorTraitsList(actor, "dv")),
            conditionImmunities: mapFoundryConditionListToWikiLabels(getActorTraitsList(actor, "ci"))
        },
        foundryName: [actor.name].filter(Boolean),
        foundry: {
            source: "foundry-export",
            actorId: actor.id,
            actorUuid: actor.uuid,
            exportedAt: new Date().toISOString(),
            ac: String(acValue || ""),
            hp: {
                value: Number(hp.max || hp.value) || 1,
                formula: String(hp.formula || "")
            },
            cr: String(details.cr ?? ""),
            prof: Number(attributes.prof) || null,
            size: system.traits?.size || size,
            type: details.type || "",
            movement: {
                walk: getActorMovementValue(actor, "walk") || 30,
                fly: getActorMovementValue(actor, "fly"),
                swim: getActorMovementValue(actor, "swim"),
                climb: getActorMovementValue(actor, "climb")
            },
            senses: getActorSensesData(actor),
            languages: system.traits?.languages?.custom || "",
            abilities: system.abilities || {},
            skills: system.skills || {},
            abilitiesList,
            flags: {
                [MODULE_ID]: {
                    exportedFromActorId: actor.id,
                    exportedFromActorUuid: actor.uuid
                }
            }
        }
    };

    ["resistances", "immunities", "vulnerabilities", "conditionImmunities"].forEach((key) => {
        if (!entry.details[key]?.length) delete entry.details[key];
    });
    return entry;
}

async function uploadBestiaryActorImage(actor, source, folder, filename) {
    const raw = String(source || "").trim();
    if (!raw) return "";
    const existingMediaPath = extractWorkerMediaPath(raw);
    if (existingMediaPath) return existingMediaPath;
    const blob = await imagePathToSquareWebpBlob(raw, CHARACTER_IMAGE_SYNC_SIZE);
    const token = String(game.settings.get(MODULE_ID, SETTINGS.DISCORD_TOKEN) || "").trim();
    if (!token) throw new Error("Login wiki richiesto.");

    const form = new FormData();
    form.set("folder", folder);
    form.set("filename", filename);
    form.set("campaignId", getCampaignId());
    form.set("file", new File([blob], filename, { type: "image/webp" }));

    const url = new URL(`${DISCORD_WORKER_URL}/media/upload`);
    url.searchParams.set("folder", folder);
    url.searchParams.set("campaign", getCampaignId());

    const response = await fetch(url.toString(), {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: form
    });
    const payload = await response.json().catch(() => null);
    if (!response.ok || payload?.ok === false) throw new Error(payload?.error || `HTTP ${response.status}`);
    const uploadedPath = payload.path || payload.key || `media/${folder}/${filename}`;
    markUploadedWorkerMediaPath(uploadedPath);
    return uploadedPath;
}

function findBestiaryEntryForActor(records, actor) {
    const actorName = normalizeWikiItemKey(actor?.name || "");
    return (Array.isArray(records) ? records : []).find((entry) => {
        if (!entry || typeof entry !== "object") return false;
        const names = [
            entry.name,
            entry.foundryName,
            ...(Array.isArray(entry.foundryName) ? entry.foundryName : []),
            ...(Array.isArray(entry.aliases) ? entry.aliases : [])
        ].map(normalizeWikiItemKey).filter(Boolean);
        return names.includes(actorName);
    }) || null;
}

function buildWikiNpcEntryFromActor(actor, images = {}) {
    const actorData = actor.toObject();
    const system = actorData.system || {};
    const details = system.details || {};
    const description = stripFoundryHtml(getFoundryDescriptionHtml(actorData));
    const id = slugify(actor.name || actor.id || "npc");
    const typeLabel = mapFoundryTypeToWikiType(details.type);
    const race = [
        mapFoundrySizeToWikiSize(system.traits?.size),
        typeLabel
    ].filter(Boolean).join(" ");
    const tokenImage = images.token
        || extractWorkerMediaPath(actor.prototypeToken?.texture?.src || actor.prototypeToken?.img)
        || actor.prototypeToken?.texture?.src
        || actor.prototypeToken?.img
        || "assets/img/logo.webp";
    const avatarImage = images.avatar
        || extractWorkerMediaPath(actor.img)
        || actor.img
        || "assets/img/logo.webp";
    const imageSet = {
        token: tokenImage,
        avatar: avatarImage
    };
    if (images.idle) imageSet.idle = images.idle;
    if (images.hover) imageSet.hover = images.hover;

    return {
        id,
        name: actor.name || "NPC Foundry",
        type: "npc",
        role: details.type?.value || typeLabel || "NPC",
        status: "ignoto",
        hidden: false,
        quote: description ? description.split(/\n+/)[0].slice(0, 180) : "",
        images: imageSet,
        summary: {
            race,
            height: "",
            weight: ""
        },
        blocks: [
            {
                id: "biografia",
                type: "text",
                title: "Biografia",
                icon: "fa-book-open",
                hidden: false,
                text: description || `Voce generata da Foundry per ${actor.name}.`
            }
        ],
        foundry: {
            source: "foundry-export",
            actorId: actor.id,
            actorUuid: actor.uuid,
            exportedAt: new Date().toISOString()
        }
    };
}

async function uploadNpcActorImage(actor, source, folder, filename) {
    const raw = String(source || "").trim();
    if (!raw) return "";
    const existingMediaPath = extractWorkerMediaPath(raw)
        || (raw.startsWith("/media/") ? raw.replace(/^\/+/, "") : "");
    const imageSource = existingMediaPath
        ? `${DISCORD_WORKER_URL.replace(/\/+$/, "")}/${existingMediaPath}`
        : raw;
    const blob = await imagePathToWebpBlobPreserveSize(imageSource, 0.96);
    return uploadRawMediaBlobToWorker(blob, filename, folder);
}

function findNpcEntryForActor(records, actor) {
    const actorName = normalizeWikiItemKey(actor?.name || "");
    const actorId = String(actor?.id || "");
    const actorUuid = String(actor?.uuid || "");
    return (Array.isArray(records) ? records : []).find((entry) => {
        if (!entry || typeof entry !== "object") return false;
        if (actorId && entry.foundry?.actorId === actorId) return true;
        if (actorUuid && entry.foundry?.actorUuid === actorUuid) return true;
        const names = [
            entry.name,
            ...(Array.isArray(entry.aliases) ? entry.aliases : [])
        ].map(normalizeWikiItemKey).filter(Boolean);
        return names.includes(actorName);
    }) || null;
}

async function exportActorToWikiNpc(actor, { updateExisting = false } = {}) {
    if (!game.user?.isGM) {
        ui.notifications.warn("Solo il GM puo creare NPC nella wiki.");
        return false;
    }
    if (!actor || actor.type !== "npc") {
        ui.notifications.warn("Apri la scheda di un NPC per esportarlo nella sezione NPC.");
        return false;
    }

    const loaded = await requestNotesApi("api/data/characters");
    const records = Array.isArray(loaded?.data) ? loaded.data : [];
    const expectedVersion = loaded?.source === "kv" ? (loaded.version ?? 0) : 0;
    const existing = findNpcEntryForActor(records, actor);
    if (existing && !updateExisting) {
        const confirmed = await Dialog.confirm({
            title: "NPC gia presente",
            content: `<p><strong>${escapeHtml(existing.name || actor.name)}</strong> sembra gia presente nella wiki. Vuoi aggiornarlo con i dati dell'actor Foundry?</p>`,
            yes: () => true,
            no: () => false,
            defaultYes: false
        });
        if (!confirmed) {
            ui.notifications.info("Export NPC annullato.");
            return false;
        }
    }

    const slug = slugify(existing?.id || actor.name || actor.id || "npc");
    const folder = `characters/${slug}`;
    const tokenSource = actor.prototypeToken?.texture?.src || actor.prototypeToken?.img || actor.img;
    const images = {
        idle: existing?.images?.idle || "",
        avatar: existing?.images?.avatar || "",
        hover: existing?.images?.hover || "",
        token: existing?.images?.token || ""
    };

    try {
        images.token = await uploadNpcActorImage(actor, tokenSource, folder, "token.webp") || images.token;
        if (images.token) {
            await registerManagedMedia(actor, "token", {
                remote: images.token,
                local: tokenSource,
                entityType: "npc",
                entityId: slug,
                actor
            });
        }
    } catch (error) {
        console.warn(`${MODULE_ID} | Token NPC non esportato, uso fallback token/actor.`, error);
    }
    try {
        images.avatar = await uploadNpcActorImage(actor, actor.img, folder, "avatar.webp") || images.avatar;
        if (images.avatar) {
            await registerManagedMedia(actor, "avatar", {
                remote: images.avatar,
                local: actor.img,
                entityType: "npc",
                entityId: slug,
                actor
            });
        }
    } catch (error) {
        console.warn(`${MODULE_ID} | Avatar NPC non esportato, uso fallback actor.img.`, error);
    }

    const exported = buildWikiNpcEntryFromActor(actor, images);
    const nextEntry = existing
        ? {
            ...existing,
            ...exported,
            id: existing.id || exported.id,
            role: existing.role || exported.role,
            status: existing.status || exported.status,
            hidden: Boolean(existing.hidden),
            quote: existing.quote || exported.quote,
            images: {
                ...exported.images,
                ...existing.images,
                idle: images.idle || existing.images?.idle || exported.images.idle,
                hover: images.hover || existing.images?.hover || exported.images.hover,
                token: images.token || existing.images?.token || exported.images.token,
                avatar: images.avatar || existing.images?.avatar || exported.images.avatar
            },
            blocks: Array.isArray(existing.blocks) && existing.blocks.length ? existing.blocks : exported.blocks,
            foundry: {
                ...(existing.foundry || {}),
                ...exported.foundry
            }
        }
        : exported;

    const nextRecords = existing
        ? records.map((entry) => entry === existing ? nextEntry : entry)
        : [...records, nextEntry];
    nextRecords.sort((left, right) => String(left.name || "").localeCompare(String(right.name || ""), "it"));

    await requestNotesApi("api/data/characters", {
        method: "POST",
        body: {
            data: nextRecords,
            expectedVersion
        }
    });

    await actor.setFlag(MODULE_ID, "wikiNpcId", nextEntry.id || slug);
    await actor.setFlag(MODULE_ID, "wikiNpcName", nextEntry.name || actor.name);
    ui.notifications.info(`${actor.name} esportato come NPC wiki.`);
    console.info(`${MODULE_ID} | Actor esportato negli NPC wiki.`, { actor: actor.name, id: nextEntry.id, updated: Boolean(existing) });
    return true;
}

async function exportActorToWikiBestiary(actor, { updateExisting = false } = {}) {
    if (!game.user?.isGM) {
        ui.notifications.warn("Solo il GM puo esportare mostri nel bestiario.");
        return false;
    }
    if (!actor || actor.type !== "npc") {
        ui.notifications.warn("Apri la scheda di un mostro/NPC per esportarlo nel bestiario.");
        return false;
    }

    const loaded = await requestNotesApi("api/data/bestiary");
    const records = Array.isArray(loaded?.data) ? loaded.data : [];
    const expectedVersion = loaded?.source === "kv" ? (loaded.version ?? 0) : 0;
    const existing = findBestiaryEntryForActor(records, actor);
    if (existing && !updateExisting) {
        const confirmed = await Dialog.confirm({
            title: "Voce bestiario gia presente",
            content: `<p><strong>${escapeHtml(existing.name || actor.name)}</strong> sembra gia presente nel bestiario. Vuoi aggiornarla con i dati dell'actor Foundry?</p>`,
            yes: () => true,
            no: () => false,
            defaultYes: false
        });
        if (!confirmed) {
            ui.notifications.info("Export bestiario annullato.");
            return false;
        }
    }

    const slug = slugify(existing?.id || actor.name || actor.id || "creatura");
    let imagePath = existing?.image || "";
    let tokenImagePath = existing?.tokenImage || "";
    const tokenSource = actor.prototypeToken?.texture?.src || actor.prototypeToken?.img || "";
    try {
        imagePath = await uploadBestiaryActorImage(actor, actor.img, "creatures/bestiary", `${slug}.webp`) || imagePath;
    } catch (error) {
        console.warn(`${MODULE_ID} | Immagine bestiario non esportata, uso fallback actor.img.`, error);
    }
    try {
        tokenImagePath = await uploadBestiaryActorImage(actor, tokenSource, "creatures/bestiary/tokens", `${slug}-token.webp`) || tokenImagePath;
    } catch (error) {
        console.warn(`${MODULE_ID} | Token bestiario non esportato, uso fallback token Foundry.`, error);
    }
    await registerManagedMedia(actor, "avatar", {
        remote: imagePath,
        local: actor.img,
        entityType: "bestiary",
        entityId: slug,
        actor
    });
    await registerManagedMedia(actor, "token", {
        remote: tokenImagePath,
        local: tokenSource,
        entityType: "bestiary",
        entityId: slug,
        actor
    });

    const exported = buildWikiBestiaryEntryFromActor(actor, imagePath, tokenImagePath);
    const nextEntry = existing
        ? {
            ...existing,
            ...exported,
            id: existing.id || exported.id,
            image: imagePath || existing.image || exported.image,
            tokenImage: tokenImagePath || existing.tokenImage || exported.tokenImage,
            foundryName: Array.from(new Set([
                ...(Array.isArray(existing.foundryName) ? existing.foundryName : [existing.foundryName].filter(Boolean)),
                actor.name
            ]))
        }
        : exported;

    const nextRecords = existing
        ? records.map((entry) => entry === existing ? nextEntry : entry)
        : [...records, nextEntry];
    nextRecords.sort((left, right) => String(left.category || "").localeCompare(String(right.category || ""), "it")
        || String(left.name || "").localeCompare(String(right.name || ""), "it"));

    await requestNotesApi("api/data/bestiary", {
        method: "POST",
        body: {
            data: nextRecords,
            expectedVersion
        }
    });

    await actor.setFlag(MODULE_ID, "wikiBestiaryId", nextEntry.id || slug);
    await actor.setFlag(MODULE_ID, "wikiBestiaryName", nextEntry.name || actor.name);
    ui.notifications.info(`${actor.name} esportato nel bestiario wiki.`);
    console.info(`${MODULE_ID} | Actor esportato nel bestiario wiki.`, { actor: actor.name, id: nextEntry.id, updated: Boolean(existing) });
    return true;
}

function renderMissingWikiCreaturesDialog(creatures) {
    const rows = creatures.map((creature, index) => `
        <label class="cripta-import-item-row">
            <input type="checkbox" name="creature" value="${index}" checked>
            ${creature.image ? `<img src="${escapeHtml(resolveWikiAssetUrl(creature.image))}" alt="">` : `<span class="cripta-import-item-icon"><i class="fas fa-skull"></i></span>`}
            <span>
                <strong>${escapeHtml(creature.name || "Creatura senza nome")}</strong>
                <small>${escapeHtml([
                    creature.details?.dndType,
                    creature.details?.size,
                    creature.foundry?.abilitiesList?.length ? `${creature.foundry.abilitiesList.length} abilita` : "nessuna abilita"
                ].filter(Boolean).join(" | "))}</small>
            </span>
        </label>
    `).join("");

    return `
        <form class="cripta-import-items-form">
            <p>Mostri wiki con dati Foundry presenti ma non trovati nel mondo. Seleziona quelli da creare nella cartella <strong>Cripta Wiki Bestiario</strong>.</p>
            <div class="cripta-import-items-list">${rows}</div>
        </form>
    `;
}

async function openWikiCreaturesImporter() {
    if (!game.user?.isGM) {
        ui.notifications.warn("Solo il GM puo importare mostri dalla wiki.");
        return;
    }

    let creatures;
    try {
        creatures = getWikiMissingCreatures(await loadWikiBestiaryCatalog());
    } catch (error) {
        console.error(`${MODULE_ID} | Import mostri wiki fallito.`, error);
        ui.notifications.error(`Impossibile leggere il bestiario dalla wiki: ${error?.message || error}`);
        return;
    }

    if (!creatures.length) {
        ui.notifications.info("Nessun mostro wiki importabile mancante in Foundry.");
        return;
    }

    new Dialog({
        title: "Importa mostri dalla wiki",
        content: renderMissingWikiCreaturesDialog(creatures),
        buttons: {
            create: {
                label: "Crea selezionati",
                icon: '<i class="fas fa-dragon"></i>',
                callback: async (html) => {
                    const form = html[0]?.querySelector("form");
                    const indexes = Array.from(new FormData(form).getAll("creature")).map((value) => Number(value));
                    const selected = indexes.map((index) => creatures[index]).filter(Boolean);
                    if (!selected.length) {
                        ui.notifications.warn("Nessun mostro selezionato.");
                        return;
                    }
                    try {
                        const created = await createFoundryActorsFromWikiCreatures(selected);
                        ui.notifications.info(`Creati ${created.length} mostri dalla wiki.`);
                    } catch (error) {
                        console.error(`${MODULE_ID} | Creazione mostri wiki fallita.`, error);
                        ui.notifications.error(`Creazione mostri fallita: ${error?.message || error}`);
                    }
                }
            },
            cancel: { label: "Annulla" }
        },
        default: "create"
    }, {
        width: 760,
        height: "auto",
        classes: ["cripta-import-items-dialog"]
    }).render(true);
}

function openModuleUpdateDialog() {
    const manifestUrl = game.modules.get(MODULE_ID)?.manifest || MODULE_UPDATE_MANIFEST_URL;
    const content = `
        <form class="cripta-module-update">
            <p>Per aggiornare gli altri DM, installa il modulo usando questo manifest. Dopo l'installazione, Foundry potra controllare e scaricare gli aggiornamenti senza inviare file manualmente.</p>
            <label>
                <span>Manifest pubblico</span>
                <input type="text" value="${escapeHtml(manifestUrl)}" readonly>
            </label>
            <p class="notes">Quando pubblichi una nuova versione, aumenta <code>version</code>, esegui <code>npm run build:module</code> e pubblica <code>dist/module.json</code> + <code>dist/cripta-wiki-sync.zip</code>.</p>
        </form>
    `;
    new Dialog({
        title: "Aggiorna modulo",
        content,
        buttons: {
            copy: {
                icon: '<i class="fas fa-copy"></i>',
                label: "Copia manifest",
                callback: async () => {
                    await navigator.clipboard?.writeText(manifestUrl);
                    ui.notifications.info("Manifest modulo copiato.");
                }
            },
            packages: {
                icon: '<i class="fas fa-box-open"></i>',
                label: "Gestione moduli",
                callback: () => {
                    if (typeof game.shutDown === "function") {
                        ui.notifications.info("Apri Setup > Add-on Modules e usa il manifest copiato.");
                    } else {
                        ui.notifications.info("Apri la schermata Setup di Foundry e aggiorna il modulo dagli Add-on Modules.");
                    }
                }
            },
            close: {
                icon: '<i class="fas fa-xmark"></i>',
                label: "Chiudi"
            }
        }
    }, {
        width: 560,
        classes: ["cripta-module-update-dialog"]
    }).render(true);
}

function openWikiSyncPanel() {
    if (!game.user?.isGM) {
        ui.notifications.warn("Solo il GM puo usare il pannello Wiki Sync.");
        return;
    }

    const actions = [
        {
            id: "update-module",
            icon: "fas fa-download",
            title: "Aggiorna modulo",
            description: "Mostra il manifest pubblico da usare per installare o aggiornare Cripta Wiki Sync sugli altri client DM.",
            run: () => openModuleUpdateDialog()
        },
        {
            id: "sync-characters",
            icon: "fas fa-cloud-arrow-up",
            title: "Sincronizza personaggi",
            description: "Invia alla wiki snapshot di personaggi, inventario, incantesimi, abilita e companion.",
            run: () => syncCharactersToWorker({ notify: true })
        },
        {
            id: "bootstrap-media-fallbacks",
            icon: "fas fa-hard-drive",
            title: "Popola fallback locali",
            description: "Scarica da R2 le immagini gia referenziate e crea il mirror locale senza scrivere sul cloud.",
            run: () => bootstrapManagedMediaFallbacksFromR2({ notify: true })
        },
        {
            id: "apply-ability-overrides",
            icon: "fas fa-wand-magic-sparkles",
            title: "Applica override abilita",
            description: "Aggiorna in Foundry icone e descrizioni modificate dal sito.",
            run: () => applyAbilityOverridesFromWiki({ notify: true })
        },
        {
            id: "sync-skill-tree-abilities",
            icon: "fas fa-crown",
            title: "Aggiungi abilita alberi",
            description: "Crea sui personaggi Foundry le abilita sbloccate negli alberi della wiki, senza rimuovere quelle esistenti.",
            run: () => syncUnlockedSkillTreeAbilitiesToFoundry({ notify: true, force: true })
        },
        {
            id: "apply-item-overrides",
            icon: "fas fa-box-open",
            title: "Applica override inventario",
            description: "Aggiorna in Foundry icone e descrizioni degli oggetti modificate dal sito.",
            run: () => applyItemOverridesFromWiki({ notify: true })
        },
        {
            id: "sync-ability-icons",
            icon: "fas fa-images",
            title: "Sincronizza icone abilita",
            description: "Carica su R2 le icone abilita dei personaggi in formato WebP 256x256.",
            run: () => syncAbilityIconsToWiki({ notify: true })
        },
        {
            id: "sync-item-icons",
            icon: "fas fa-boxes-stacked",
            title: "Sincronizza icone inventario",
            description: "Carica su R2 le icone degli oggetti dei personaggi in formato WebP 256x256.",
            run: () => syncInventoryItemIconsToWiki({ notify: true })
        },
        {
            id: "sync-character-images",
            icon: "fas fa-user-circle",
            title: "Sincronizza immagini personaggi",
            description: "Carica su R2 avatar e token dei personaggi solo se non sono gia presenti in players.",
            run: () => syncCharacterImagesToWiki({ notify: true })
        },
        {
            id: "apply-character-media-overrides",
            icon: "fas fa-id-card-clip",
            title: "Applica immagini sito",
            description: "Aggiorna in Foundry avatar e token di personaggi e companion modificati dal sito.",
            run: () => applyCharacterMediaOverridesFromWiki({ notify: true })
        },
        {
            id: "apply-asset-sync-jobs",
            icon: "fas fa-list-check",
            title: "Applica richieste asset",
            description: "Applica solo le richieste selezionate dalla pagina Asset Sync della wiki.",
            run: () => applyQueuedAssetSyncJobsFromWiki({ notify: true })
        },
        {
            id: "import-items",
            icon: "fas fa-file-import",
            title: "Importa oggetti",
            description: "Crea in Foundry gli oggetti presenti sulla wiki ma mancanti nel mondo.",
            run: () => openWikiItemsImporter()
        },
        {
            id: "import-creatures",
            icon: "fas fa-dragon",
            title: "Importa mostri",
            description: "Crea in Foundry i mostri del bestiario wiki mancanti nel mondo.",
            run: () => openWikiCreaturesImporter()
        },
        {
            id: "sync-token-switcher",
            icon: "fas fa-retweet",
            title: "Sincronizza varianti token",
            description: "Aggiorna il Token Switcher con le trasformazioni configurate sulla wiki.",
            run: () => syncTransformationsToTokenSwitcher({ force: true, notify: true })
        },
        {
            id: "import-token-switcher",
            icon: "fas fa-cloud-arrow-up",
            title: "Importa varianti dal Token Switcher",
            description: "Legge le varianti manuali del Token Switcher e le pubblica come trasformazioni sulla wiki.",
            run: () => syncTokenSwitcherTransformationsToWiki({ notify: true })
        }
    ];

    const rows = actions.map((action) => `
        <button type="button" class="cripta-sync-panel-action" data-cripta-sync-action="${escapeHtml(action.id)}">
            <i class="${escapeHtml(action.icon)}" aria-hidden="true"></i>
            <span>
                <strong>${escapeHtml(action.title)}</strong>
                <small>${escapeHtml(action.description)}</small>
            </span>
        </button>
    `).join("");

    const dialog = new Dialog({
        title: "Cripta Wiki Sync",
        content: `
            <form class="cripta-sync-panel">
                <p>Azioni operative della wiki. Apri Wiki resta come pulsante separato nella toolbar.</p>
                <div class="cripta-sync-panel-actions">
                    ${rows}
                </div>
            </form>
        `,
        buttons: {
            close: {
                icon: '<i class="fas fa-xmark"></i>',
                label: "Chiudi"
            }
        },
        render: (html) => {
            const root = html instanceof HTMLElement ? html : html[0];
            root?.querySelectorAll?.("[data-cripta-sync-action]").forEach((button) => {
                button.addEventListener("click", async () => {
                    const action = actions.find((entry) => entry.id === button.dataset.criptaSyncAction);
                    if (!action) return;
                    button.disabled = true;
                    button.classList.add("is-running");
                    try {
                        await action.run();
                        if (action.id.startsWith("import-")) dialog.close();
                    } catch (error) {
                        console.error(`${MODULE_ID} | Azione Wiki Sync fallita.`, { action: action.id, error });
                        ui.notifications.error(`${action.title} fallito: ${error?.message || error}`);
                    } finally {
                        button.disabled = false;
                        button.classList.remove("is-running");
                    }
                });
            });
        }
    }, {
        width: 560,
        classes: ["cripta-sync-panel-dialog"]
    });

    dialog.render(true);
}

function parseNotesContent(content) {
    const raw = String(content || "").trim();
    if (!raw) return [];

    try {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
        if (Array.isArray(parsed?.notes)) return parsed.notes;
    } catch (_) {
        // Legacy/plain notes are not expected here, but keep them readable.
    }

    return [];
}

function serializeNotesContent(notes, ownerDiscordId) {
    return JSON.stringify({
        version: 2,
        page: "appunti",
        ownerDiscordId,
        targetDiscordId: ownerDiscordId,
        notes
    });
}

function htmlToPlainText(html) {
    const root = document.createElement("div");
    root.innerHTML = String(html || "");

    let output = "";
    const blockTags = new Set(["P", "DIV", "SECTION", "ARTICLE", "HEADER", "FOOTER", "LI", "UL", "OL", "H1", "H2", "H3", "H4", "H5", "H6", "BLOCKQUOTE"]);
    const appendNewline = (count = 1) => {
        const suffix = "\n".repeat(count);
        output = `${output.replace(/\s+$/g, "")}${suffix}`;
    };
    const walk = (node) => {
        if (node.nodeType === Node.TEXT_NODE) {
            output += node.nodeValue || "";
            return;
        }
        if (node.nodeType !== Node.ELEMENT_NODE) return;

        if (node.tagName === "BR") {
            appendNewline(1);
            return;
        }

        const isBlock = blockTags.has(node.tagName);
        if (isBlock && output.trim() && !output.endsWith("\n")) appendNewline(1);
        node.childNodes.forEach(walk);
        if (isBlock) appendNewline(2);
    };

    root.childNodes.forEach(walk);
    return output
        .replace(/\u00a0/g, " ")
        .replace(/[ \t]+\n/g, "\n")
        .replace(/\n{3,}/g, "\n\n")
        .trim();
}

function plainTextToNoteHtml(text) {
    const blocks = String(text || "")
        .replace(/\r\n/g, "\n")
        .split(/\n{2,}/)
        .map((block) => block.trim())
        .filter(Boolean);
    if (!blocks.length) return "<p></p>";
    return blocks.map((block) => `<p>${escapeHtml(block).replace(/\n/g, "<br>")}</p>`).join("");
}

function appendTextToNoteHtml(currentHtml, text) {
    const addition = plainTextToNoteHtml(text);
    if (!String(text || "").trim()) return currentHtml || "<p></p>";
    const current = String(currentHtml || "").trim();
    if (!current || current === "<p></p>") return addition;
    return `${current}${addition}`;
}

function buildCreatureNoteLink(match) {
    const creature = match?.entity || {};
    const discovered = creature.discovered !== false;
    const creatureName = creature.name || match?.id || "Creatura";
    const displayName = discovered ? creatureName : (creature.mysteryName || "Creatura Misteriosa");
    const id = match?.id || slugify(creatureName);
    return {
        key: `creature:${id}`,
        type: "creature",
        id,
        label: displayName,
        url: "bestiario.html",
        image: creature.image ? resolveWikiAssetUrl(creature.image) : "",
        icon: "fa-book-dead"
    };
}

function buildCreatureNotesSiteUrl(link) {
    const url = new URL(`${wikiDataService.getBaseUrl()}/pages/appunti.html`);
    url.searchParams.set("noteLink", link.key);
    url.searchParams.set("campaign", getCampaignId());
    return url.toString();
}

function noteHasOnlyLink(note, linkKey) {
    const links = Array.isArray(note?.links) ? note.links : [];
    return links.length === 1 && links[0]?.key === linkKey;
}

function isPersonalQuickNoteCandidate(note, linkKey) {
    return note?.shared !== true && noteHasOnlyLink(note, linkKey);
}

function createQuickCreatureNote(link, user) {
    const now = new Date().toISOString();
    return {
        id: foundry.utils.randomID(16),
        title: `Appunti: ${link.label}`,
        html: "<p></p>",
        links: [link],
        shared: false,
        ownerDiscordId: user.id,
        ownerUsername: user.username || user.global_name || user.name || game.user?.name || "Utente",
        authorDiscordId: user.id,
        authorUsername: user.username || user.global_name || user.name || game.user?.name || "Utente",
        createdAt: now,
        updatedAt: now
    };
}

function getQuickNoteDraftKey(user, link) {
    return `${user?.id || "unknown"}:${link?.key || "unknown"}`;
}

function getQuickNoteAppendText(html) {
    return String(html.find?.("[name='quickNoteAppend']").val?.() || "");
}

function cacheQuickNoteDraft(draftKey, text) {
    const value = String(text || "");
    if (value.trim()) quickNoteDraftCache.set(draftKey, value);
    else quickNoteDraftCache.delete(draftKey);
}

function bindQuickNoteWindowBehavior(html) {
    const windowElement = html?.closest?.(".app.window-app")?.[0] || html?.[0]?.closest?.(".app.window-app");
    if (!windowElement) return;

    windowElement._criptaQuickNoteCleanup?.();
    let inactiveArmed = false;
    let consumeActivationClick = false;
    const armTimer = window.setTimeout(() => {
        inactiveArmed = true;
    }, 0);
    const setInactive = () => windowElement.classList.add("cripta-quick-note-window--inactive");
    const setActive = () => windowElement.classList.remove("cripta-quick-note-window--inactive");
    const consumeEvent = (event) => {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation?.();
    };
    const handleActivationStart = (event) => {
        if (!inactiveArmed) return;

        if (!windowElement.contains(event.target)) {
            setInactive();
            return;
        }

        if (windowElement.classList.contains("cripta-quick-note-window--inactive")) {
            consumeActivationClick = true;
            consumeEvent(event);
            setActive();
        }
    };
    const handleActivationClick = (event) => {
        if (!consumeActivationClick) return;
        consumeActivationClick = false;
        consumeEvent(event);
    };

    windowElement.classList.add("cripta-quick-note-window");
    setActive();
    document.addEventListener("pointerdown", handleActivationStart, true);
    document.addEventListener("mousedown", handleActivationStart, true);
    document.addEventListener("click", handleActivationClick, true);
    windowElement._criptaQuickNoteCleanup = () => {
        window.clearTimeout(armTimer);
        document.removeEventListener("pointerdown", handleActivationStart, true);
        document.removeEventListener("mousedown", handleActivationStart, true);
        document.removeEventListener("click", handleActivationClick, true);
    };
}

function cleanupQuickNoteWindowBehavior(html) {
    const windowElement = html?.closest?.(".app.window-app")?.[0] || html?.[0]?.closest?.(".app.window-app");
    windowElement?._criptaQuickNoteCleanup?.();
}

async function openQuickCreatureNote(document) {
    const session = await getValidAuthSession();
    const user = session?.user || getStoredWikiUser();
    if (!user?.id) {
        promptDeviceLogin();
        throw new Error("Accedi alla wiki prima di scrivere appunti rapidi.");
    }

    const match = await wikiDataService.matchDocument(document);
    if (match?.source !== "wiki" || match.section !== SECTIONS.BESTIARY || !match.entity) {
        throw new Error("Questo token non e collegato a una voce del bestiario.");
    }

    const link = buildCreatureNoteLink(match);
    const data = await requestNotesApi("api/notes", {
        method: "GET",
        query: {
            page: "appunti",
            ownerDiscordId: user.id
        }
    });
    const notes = parseNotesContent(data?.note?.content || "");
    let note = notes.find((item) => isPersonalQuickNoteCandidate(item, link.key));
    if (!note) {
        note = createQuickCreatureNote(link, user);
        notes.unshift(note);
    }

    const text = htmlToPlainText(note.html || "");
    const draftKey = getQuickNoteDraftKey(user, link);
    const cachedAppendText = quickNoteDraftCache.get(draftKey) || "";
    let closeMode = "soft";
    let reopenAfterCancel = false;
    const dialog = new Dialog({
        title: `Appunti rapidi: ${link.label}`,
        content: `
            <form class="cripta-quick-note-form">
                <p class="notes-hint">Appunto personale collegato solo a <strong>${escapeHtml(link.label)}</strong>.</p>
                <label>Appunti gia salvati</label>
                <textarea name="quickNoteExisting" rows="10" readonly>${escapeHtml(text)}</textarea>
                <label>Aggiungi sotto</label>
                <textarea name="quickNoteAppend" rows="6" placeholder="Scrivi qui i nuovi appunti...">${escapeHtml(cachedAppendText)}</textarea>
            </form>
        `,
        buttons: {
            save: {
                icon: '<i class="fas fa-floppy-disk"></i>',
                label: "Salva",
                callback: (html) => {
                    closeMode = "save";
                    const appendText = getQuickNoteAppendText(html);
                    cacheQuickNoteDraft(draftKey, appendText);
                    note.html = appendTextToNoteHtml(note.html, appendText);
                    note.links = [link];
                    note.updatedAt = new Date().toISOString();
                    requestNotesApi("api/notes", {
                        method: "POST",
                        body: {
                            page: "appunti",
                            content: serializeNotesContent(notes, user.id),
                            ownerDiscordId: user.id
                        }
                    }).then(() => {
                        quickNoteDraftCache.delete(draftKey);
                        ui.notifications.info(`Appunto rapido salvato: ${link.label}`);
                    }).catch((error) => {
                        ui.notifications.error(error?.message || String(error || "Salvataggio appunto non riuscito."));
                    });
                }
            },
            cancel: {
                icon: '<i class="fas fa-xmark"></i>',
                label: "Annulla",
                callback: (html) => {
                    closeMode = "cancel";
                    const appendText = getQuickNoteAppendText(html);
                    if (appendText.trim() && !window.confirm("Scartare gli appunti non salvati?")) {
                        cacheQuickNoteDraft(draftKey, appendText);
                        reopenAfterCancel = true;
                        return;
                    }
                    quickNoteDraftCache.delete(draftKey);
                }
            }
        },
        default: "save",
        close: (html) => {
            if (closeMode === "soft") {
                cacheQuickNoteDraft(draftKey, getQuickNoteAppendText(html));
            }
            cleanupQuickNoteWindowBehavior(html);
            if (reopenAfterCancel) {
                window.setTimeout(() => openQuickCreatureNote(document), 0);
            }
        },
        render: (html) => {
            const existing = html.find?.("[name='quickNoteExisting']")?.[0];
            if (existing) existing.scrollTop = existing.scrollHeight;
            html.find?.("[name='quickNoteAppend']").on?.("input", () => {
                cacheQuickNoteDraft(draftKey, getQuickNoteAppendText(html));
            });
            bindQuickNoteWindowBehavior(html);
            html.find?.("[name='quickNoteAppend']").trigger?.("focus");
        }
    }, {
        width: 520,
        height: 560,
        resizable: true,
        classes: ["cripta-quick-note-window"]
    });
    dialog.render(true);
}

async function openCreatureNotesOnSite(document) {
    const match = await wikiDataService.matchDocument(document);
    if (match?.source !== "wiki" || match.section !== SECTIONS.BESTIARY || !match.entity) {
        throw new Error("Questo token non e collegato a una voce del bestiario.");
    }

    const link = buildCreatureNoteLink(match);
    window.open(buildCreatureNotesSiteUrl(link), "_blank", "noopener");
}

function normalizeAutoLoginKey(value) {
    return String(value || "")
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, " ")
        .replace(/\s+/g, " ")
        .trim();
}

function compactAutoLoginKey(value) {
    return normalizeAutoLoginKey(value).replace(/\s+/g, "");
}

function autoLoginKeyMatches(configKey, userKey) {
    const normalizedConfig = normalizeAutoLoginKey(configKey);
    const normalizedUser = normalizeAutoLoginKey(userKey);
    const compactConfig = compactAutoLoginKey(configKey);
    const compactUser = compactAutoLoginKey(userKey);

    if (!normalizedConfig || !normalizedUser) return false;
    if (normalizedConfig === normalizedUser) return true;
    if (compactConfig && compactConfig === compactUser) return true;
    if (normalizedUser.includes(normalizedConfig)) return true;
    if (compactConfig && compactUser.includes(compactConfig)) return true;
    return false;
}

function getConfiguredDeviceCodeForCurrentUser() {
    const configured = parseAutoDeviceLoginConfig();
    const userKeys = [
        game.user?.id,
        game.user?.name
    ].map((key) => String(key || "").trim()).filter(Boolean);

    if (!userKeys.length) return "";

    for (const [configKey, code] of configured.entries()) {
        if (code && userKeys.some((candidate) => autoLoginKeyMatches(configKey, candidate))) return code;
    }

    return "";
}

function parseAutoDeviceLoginConfig() {
    let rawConfig = "";
    try {
        rawConfig = String(game.settings.get(MODULE_ID, SETTINGS.AUTO_DEVICE_LOGIN_CODES) || "");
    } catch (_) {
        return new Map();
    }

    const entries = rawConfig
        .split(/\r?\n|;/)
        .map((entry) => entry.trim())
        .filter(Boolean);

    const configured = new Map();
    for (const entry of entries) {
        const [rawUserKey, rawCode] = entry.includes("|")
            ? entry.split("|")
            : entry.includes("=")
                ? entry.split("=")
                : entry.split(":");

        const userKey = String(rawUserKey || "").trim();
        const code = String(rawCode || "").trim();
        if (userKey && code) configured.set(userKey, code);
    }

    return configured;
}

async function tryAutomaticDeviceLogin() {
    const code = getConfiguredDeviceCodeForCurrentUser();
    if (!code) return false;

    try {
        await loginWithDeviceCode(code);
        return true;
    } catch (error) {
        ui.notifications.warn(`Login automatico con codice fallito: ${error?.message || error}`);
        return false;
    }
}

function seedDefaultAutoLoginCodes() {
    if (!game.user?.isGM) return;

    try {
        const current = String(game.settings.get(MODULE_ID, SETTINGS.AUTO_DEVICE_LOGIN_CODES) || "").trim();
        if (current) return;
        game.settings.set(MODULE_ID, SETTINGS.AUTO_DEVICE_LOGIN_CODES, DEFAULT_AUTO_DEVICE_LOGIN_CODES).catch(() => {});
    } catch (_) {
        // Ignore settings that are not ready or not writable.
    }
}

async function promptDeviceLoginIfNeeded() {
    const session = await getValidAuthSession();
    if (session?.user) return;
    const didAutoLogin = await tryAutomaticDeviceLogin();
    if (didAutoLogin) return;
    promptDeviceLogin();
}

function scheduleUnlockedSkillTreeAbilitySync({ force = true, delay = 900 } = {}) {
    if (!game.user?.isGM) return;
    window.clearTimeout(skillTreeAbilitySyncTimer);
    skillTreeAbilitySyncTimer = window.setTimeout(() => {
        skillTreeAbilitySyncTimer = null;
        syncUnlockedSkillTreeAbilitiesToFoundry({ notify: false, force }).catch((error) => {
            console.warn(`${MODULE_ID} | Sincronizzazione automatica abilita alberi fallita.`, error);
        });
    }, delay);
}

function handleEmbeddedWikiMessage(event) {
    if (event?.data?.type === "cripta-auth-token" && event?.data?.token) {
        propagateAuthToken(event.data.token);
    }
    if (event?.data?.type === "cripta-skill-tree-state-updated") {
        scheduleUnlockedSkillTreeAbilitySync({ force: true });
    }
}

function hideTokenQuickHud() {
    document.querySelector(".cripta-token-quick-hud")?.remove();
}

let lastCanvasPointerPosition = null;

function getTokenTopRightPosition(token) {
    const view = canvas?.app?.view || canvas?.app?.canvas;
    const rect = view?.getBoundingClientRect?.();
    const transform = canvas?.stage?.worldTransform;
    if (!rect || !transform || !token) {
        return { x: Math.round(window.innerWidth / 2), y: Math.round(window.innerHeight / 2) };
    }

    const bounds = token.bounds;
    const worldX = bounds?.right ?? ((token.x || 0) + (token.w ?? token.width ?? 0));
    const worldY = bounds?.top ?? (token.y || 0);
    const screenPoint = transform.apply(new PIXI.Point(worldX, worldY));

    return {
        x: Math.round(rect.left + screenPoint.x),
        y: Math.round(rect.top + screenPoint.y)
    };
}

function positionTokenQuickHud(hud, token) {
    const position = getTokenTopRightPosition(token);
    const margin = 8;
    const hudRect = hud.getBoundingClientRect();
    const left = Math.min(
        window.innerWidth - hudRect.width - margin,
        Math.max(margin, position.x - hudRect.width + 8)
    );
    const top = Math.min(
        window.innerHeight - hudRect.height - margin,
        Math.max(margin, position.y - 8)
    );

    hud.style.left = `${left}px`;
    hud.style.top = `${top}px`;
}

function showTokenQuickHud(token, event, options = {}) {
    const foundryDocument = resolveDocumentFromToken(token);
    if (!foundryDocument) return;
    if (!isTokenVisibleForCurrentUser(token)) return;

    if (options.consumeEvent !== false) {
        event?.preventDefault?.();
        event?.stopPropagation?.();
    }
    hideTokenQuickHud();
    const hud = document.createElement("div");
    hud.className = "cripta-token-quick-hud";
    hud.innerHTML = `
        <button type="button" data-action="wiki" title="Apri scheda wiki">
            <i class="fas fa-book-open"></i>
        </button>
        <button type="button" data-action="notes" title="Appunti rapidi bestiario">
            <i class="fas fa-note-sticky"></i>
        </button>
        <button type="button" data-action="site-notes" title="Apri appunti sul sito">
            <i class="fas fa-arrow-up-right-from-square"></i>
        </button>
    `;

    hud.addEventListener("click", (clickEvent) => {
        const button = clickEvent.target.closest("button[data-action]");
        if (!button) return;
        clickEvent.preventDefault();
        clickEvent.stopPropagation();
        const action = button.dataset.action;
        hideTokenQuickHud();

        if (action === "wiki") {
            wikiDataService.logDocumentSearch(foundryDocument, "right-click token").catch(error => {
                console.warn("[Cripta Wiki Sync] Impossibile loggare la ricerca wiki token.", error);
            });
            openWikiForDocument(foundryDocument);
            return;
        }

        if (action === "notes") {
            openQuickCreatureNote(foundryDocument).catch(error => {
                ui.notifications.warn(error?.message || String(error || "Appunti rapidi non disponibili."));
            });
            return;
        }

        if (action === "site-notes") {
            openCreatureNotesOnSite(foundryDocument).catch(error => {
                ui.notifications.warn(error?.message || String(error || "Appunti sul sito non disponibili."));
            });
        }
    });

    document.body.appendChild(hud);
    positionTokenQuickHud(hud, token);
}

function canUseFoundryTokenHud(token) {
    return Boolean(game.user?.isGM || token?.document?.isOwner || token?.actor?.isOwner);
}

function isTokenVisibleForCurrentUser(token) {
    if (!token || token.destroyed) return false;
    if (token.visible === false || token.renderable === false) return false;
    if (typeof token.worldVisible === "boolean" && token.worldVisible === false) return false;
    if (typeof token.isVisible === "boolean" && token.isVisible === false) return false;
    if (typeof token.isVisible === "function") {
        try {
            if (!token.isVisible()) return false;
        } catch (_error) {
            // Older Foundry versions expose visibility as a property, not a method.
        }
    }
    if (token.document?.hidden && !game.user?.isGM) return false;
    return true;
}

function openWikiFromToken(token, context = "token") {
    const foundryDocument = resolveDocumentFromToken(token);
    if (!foundryDocument) return;

    wikiDataService.logDocumentSearch(foundryDocument, context).catch(error => {
        console.warn("[Cripta Wiki Sync] Impossibile loggare la ricerca wiki token.", error);
    });
    openWikiForDocument(foundryDocument);
}

function openQuickNoteFromToken(token) {
    const foundryDocument = resolveDocumentFromToken(token);
    if (!foundryDocument) return;

    openQuickCreatureNote(foundryDocument).catch(error => {
        ui.notifications.warn(error?.message || String(error || "Appunti rapidi non disponibili."));
    });
}

function openSiteNotesFromToken(token) {
    const foundryDocument = resolveDocumentFromToken(token);
    if (!foundryDocument) return;

    openCreatureNotesOnSite(foundryDocument).catch(error => {
        ui.notifications.warn(error?.message || String(error || "Appunti sul sito non disponibili."));
    });
}

function appendTokenHudButtons(html, token) {
    if (html.find(".cripta-wiki-hud").length) return;

    const wikiButton = $(
        `<div class="control-icon cripta-wiki-hud" title="Apri scheda wiki">
            <i class="fas fa-book-open"></i>
        </div>`
    );
    const notesButton = $(
        `<div class="control-icon cripta-wiki-hud cripta-wiki-notes-hud" title="Appunti rapidi bestiario">
            <i class="fas fa-note-sticky"></i>
        </div>`
    );
    const siteNotesButton = $(
        `<div class="control-icon cripta-wiki-hud cripta-wiki-site-notes-hud" title="Apri appunti sul sito">
            <i class="fas fa-arrow-up-right-from-square"></i>
        </div>`
    );

    wikiButton.on("click", event => {
        event.preventDefault();
        event.stopPropagation();
        openWikiFromToken(token, "icona libro token");
    });

    notesButton.on("click", event => {
        event.preventDefault();
        event.stopPropagation();
        openQuickNoteFromToken(token);
    });

    siteNotesButton.on("click", event => {
        event.preventDefault();
        event.stopPropagation();
        openSiteNotesFromToken(token);
    });

    html.find(".left").append(wikiButton).append(notesButton).append(siteNotesButton);
}

function attachTokenQuickHudListener(token) {
    // Foundry's native TokenHUD must keep ownership of token right-clicks.
    // The DOM fallback below covers non-owned tokens, where Foundry does not show the HUD.
    return token;
}

function bindCanvasTokenRightClicks() {
    canvas?.tokens?.placeables?.forEach(attachTokenQuickHudListener);
}

function getTokenActor(tokenLike) {
    const document = tokenLike?.document || tokenLike;
    return document?.actor || tokenLike?.actor || null;
}

function getTokenDocument(tokenLike) {
    return tokenLike?.document || tokenLike || null;
}

function getTokenNameCandidates(tokenLike) {
    const document = getTokenDocument(tokenLike);
    const actor = getTokenActor(tokenLike);
    return [
        actor?.name,
        actor?.prototypeToken?.name,
        document?.name,
        document?.actor?.name
    ].map(normalizeWikiItemKey).filter(Boolean);
}

function getTokenOwnerAliases(tokenLike) {
    const actor = getTokenActor(tokenLike);
    if (!actor) return [];
    const aliases = [actor.name, actor.id, actor.uuid];
    game.users
        .filter((user) => !user.isGM && actor.testUserPermission?.(user, "OWNER"))
        .forEach((user) => aliases.push(user.id, user.name));
    return aliases.map(normalizeWikiItemKey).filter(Boolean);
}

function findTransformationOverrideForToken(tokenLike, overrides) {
    const names = new Set(getTokenNameCandidates(tokenLike));
    if (!names.size) return null;
    const actor = getTokenActor(tokenLike);
    if (actor) {
        const directMatch = overrides.find((entry) =>
            transformationEntryMatchesActor(entry, actor)
            && hasFuzzySetMatch(entry.names, names)
        );
        if (directMatch) return directMatch;
    }
    const ownerAliases = new Set(getTokenOwnerAliases(tokenLike));
    if (!ownerAliases.size) return null;
    return overrides.find((entry) =>
        hasFuzzySetMatch(entry.names, names)
        && hasFuzzySetMatch(entry.ownerAliases, ownerAliases)
    ) || null;
}

function hasFuzzySetMatch(leftValues, rightSet) {
    const rightValues = Array.from(rightSet || []).filter(Boolean);
    return (leftValues || []).some((left) => {
        if (!left) return false;
        return rightValues.some((right) => right === left || right.includes(left) || left.includes(right));
    });
}

function getActorOwnerAliases(actor) {
    if (!actor) return [];
    const aliases = [actor.name, actor.id, actor.uuid];
    game.users
        .filter((user) => !user.isGM && actor.testUserPermission?.(user, "OWNER"))
        .forEach((user) => aliases.push(user.id, user.name));
    return aliases.map(normalizeWikiItemKey).filter(Boolean);
}

function findPlayerActorForTransformation(entry) {
    const ownerAliases = new Set((entry?.ownerAliases || []).filter(Boolean));
    if (!ownerAliases.size) return null;
    return game.actors.find((actor) => {
        const actorAliases = getActorOwnerAliases(actor);
        return hasFuzzySetMatch(actorAliases, ownerAliases);
    }) || null;
}

function transformationEntryMatchesActor(entry, actor) {
    if (!entry || !actor) return false;
    const actorId = normalizeActorRef(entry.actorId || entry.actorRef || entry.foundryActorId || "");
    if (actorId && actor.id === actorId) return true;
    const actorAliases = new Set(getActorOwnerAliases(actor));
    return hasFuzzySetMatch(entry.ownerAliases, actorAliases);
}

function findConfiguredCompanionActorForTransformation(entry) {
    if (!entry?.isCompanion && !String(entry?.characterId || "").startsWith("companion-")) return null;
    const actorId = normalizeActorRef(entry.actorId || entry.actorRef || entry.foundryActorId || "");
    if (actorId) {
        const directActor = game.actors.get(actorId);
        if (directActor && isConfiguredCompanionActor(directActor)) return directActor;
    }
    const ownerCharacterId = slugify(entry.ownerCharacterId || "");
    if (!ownerCharacterId) return null;
    return parseCompanionMappings()
        .map((mapping) => ({
            mapping,
            actor: getConfiguredActor(mapping.actorId || mapping.actorName)
        }))
        .find(({ mapping, actor }) =>
            actor
            && slugify(mapping.ownerCharacterId || "") === ownerCharacterId
            && transformationEntryMatchesActor(entry, actor)
        )?.actor || null;
}

function findActorForTransformation(entry) {
    const actorId = normalizeActorRef(entry?.actorId || entry?.actorRef || entry?.foundryActorId || "");
    if (actorId) {
        const directActor = game.actors.get(actorId);
        if (directActor) return directActor;
    }
    return findConfiguredCompanionActorForTransformation(entry)
        || findPlayerActorForTransformation(entry);
}

async function mapTransformationToTokenSwitcherEntry(actor, entry) {
    const size = getTransformationTokenSize(entry);
    const remotePath = normalizeManagedRemotePath(entry.tokenImage);
    const effectivePath = remotePath
        ? await resolveAndRegisterManagedMedia(actor, `transformation:${entry.id}`, {
            remote: remotePath,
            entityType: "transformation",
            entityId: entry.id,
            actor,
            name: entry.label || entry.creatureName || entry.name || "Forma",
            verifyRemote: false,
            assumeRemoteAvailable: true
        })
        : "";
    return {
        path: effectivePath || entry.tokenImage,
        name: entry.label || entry.names?.[0] || "Forma",
        hpThreshold: null,
        hpAllowRevert: false,
        width: size,
        height: size
    };
}

function normalizeTokenSwitcherEntry(entry) {
    if (typeof entry === "string") {
        return {
            path: entry,
            name: "",
            hpThreshold: null,
            hpAllowRevert: false,
            width: null,
            height: null
        };
    }
    return {
        path: String(entry?.path || "").trim(),
        name: String(entry?.name || "").trim(),
        hpThreshold: entry?.hpThreshold ?? null,
        hpAllowRevert: entry?.hpAllowRevert ?? false,
        width: Number.isFinite(Number(entry?.width)) ? Number(entry.width) : null,
        height: Number.isFinite(Number(entry?.height)) ? Number(entry.height) : null
    };
}

function getTokenSwitcherBaseEntry(actor) {
    const prototypeToken = actor?.prototypeToken || {};
    const path = String(prototypeToken.texture?.src || prototypeToken.img || actor?.img || "").trim();
    if (!path) return null;
    const width = Number(prototypeToken.width || 0);
    const height = Number(prototypeToken.height || 0);
    return {
        path,
        name: "Base",
        hpThreshold: null,
        hpAllowRevert: false,
        width: Number.isFinite(width) && width > 0 ? width : null,
        height: Number.isFinite(height) && height > 0 ? height : null
    };
}

function getConfiguredTransformationSubjects() {
    const subjects = resolveConfiguredPlayerActors()
        .map(({ actor, mapping }) => ({
            actor,
            subjectId: mapping.ownerCharacterId,
            ownerCharacterId: mapping.ownerCharacterId,
            ownerAccountId: mapping.ownerAccountId,
            isCompanion: false,
            folder: `transformations/${slugify(mapping.ownerCharacterId || actor.name || actor.id)}`
        }))
        .filter((entry) => entry.actor && entry.subjectId);

    parseCompanionMappings().forEach((mapping) => {
        const actor = getConfiguredActor(mapping.actorId || mapping.actorName);
        const ownerCharacterId = slugify(mapping.ownerCharacterId || "");
        if (!actor || !ownerCharacterId) return;
        const entityId = buildCompanionMediaEntityId(ownerCharacterId, actor.id, actor.name || mapping.displayName || "companion");
        subjects.push({
            actor,
            subjectId: `companion-${entityId}`,
            ownerCharacterId,
            ownerAccountId: mapping.ownerAccountId,
            isCompanion: true,
            entityId,
            folder: `transformations/companion-${entityId}`
        });
    });

    return subjects;
}

function getTokenSwitcherEntriesForActor(actor) {
    return (actor?.getFlag?.(TOKEN_SWITCHER_MODULE_ID, TOKEN_SWITCHER_IMAGES_FLAG) || [])
        .map(normalizeTokenSwitcherEntry)
        .filter((entry) => entry.path);
}

function getTokenSwitcherEntryLabel(entry) {
    const explicit = String(entry?.name || "").trim();
    if (explicit) return explicit;
    const path = String(entry?.path || "").trim();
    const filename = path.split(/[\\/]/).pop() || "";
    return filename.replace(/\.[^.]+$/, "").replace(/[-_]+/g, " ").trim() || "Forma";
}

function buildTokenSwitcherTransformationId(subject, entry) {
    const label = getTokenSwitcherEntryLabel(entry);
    const pathKey = slugify(String(entry?.path || "").split(/[?#]/)[0].split(/[\\/]/).pop() || "");
    return `${subject.subjectId}-${slugify(label || "forma")}${pathKey ? `-${pathKey}` : ""}`;
}

async function resolveTokenSwitcherEntryMediaPath(subject, entry) {
    const rawPath = String(entry?.path || "").trim();
    const filename = `${buildTokenSwitcherTransformationId(subject, entry)}.webp`;
    const existingPath = await getReusableCampaignMediaPath(rawPath)
        || await copyLegacyMediaPathToCampaign(rawPath, subject.folder, filename);
    if (existingPath) return { path: existingPath, uploaded: false };

    const blob = await imagePathToSquareWebpBlob(rawPath, CHARACTER_IMAGE_SYNC_SIZE);
    const uploadedPath = await uploadRawMediaBlobToWorker(blob, filename, subject.folder);
    return { path: uploadedPath, uploaded: true };
}

function buildWikiTransformationFromTokenSwitcher(subject, entry, tokenImage) {
    const label = getTokenSwitcherEntryLabel(entry);
    const size = Number(entry.width || entry.height || 0) || null;
    return compactObject({
        id: buildTokenSwitcherTransformationId(subject, entry),
        characterId: subject.subjectId,
        entityType: subject.isCompanion ? "companion" : "player",
        isCompanion: subject.isCompanion || undefined,
        entityId: subject.entityId,
        actorId: subject.actor?.id,
        ownerCharacterId: subject.ownerCharacterId,
        ownerAccountId: subject.ownerAccountId,
        creatureName: label,
        name: label,
        foundryName: label,
        foundryNames: [label],
        tokenImage,
        size,
        switcher: true,
        enabled: true,
        source: "khuzoe-token-switcher"
    });
}

function mergeTransformationRecordsById(records, nextRecord) {
    const index = records.findIndex((entry) => String(entry?.id || "") === String(nextRecord?.id || ""));
    if (index >= 0) {
        const current = records[index] || {};
        const merged = { ...current, ...nextRecord };
        const comparableCurrent = { ...current, updatedAt: undefined };
        const comparableMerged = { ...merged, updatedAt: undefined };
        if (JSON.stringify(comparableCurrent) === JSON.stringify(comparableMerged)) return false;
        records[index] = { ...merged, updatedAt: new Date().toISOString() };
        return true;
    }
    records.push({ ...nextRecord, updatedAt: new Date().toISOString() });
    return true;
}

async function syncTokenSwitcherTransformationsToWiki({ notify = false } = {}) {
    if (!game.user?.isGM) {
        ui.notifications.warn("Solo il GM puo importare varianti Token Switcher verso la wiki.");
        return false;
    }
    if (!game.modules.get(TOKEN_SWITCHER_MODULE_ID)?.active) {
        ui.notifications.warn("Khuzoe Token Switcher non e attivo.");
        return false;
    }

    const subjects = getConfiguredTransformationSubjects();
    const candidates = subjects.flatMap((subject) => {
        const managedPaths = new Set(subject.actor.getFlag(MODULE_ID, TOKEN_SWITCHER_SYNCED_PATHS_FLAG) || []);
        return getTokenSwitcherEntriesForActor(subject.actor)
            .filter((entry) => !managedPaths.has(entry.path))
            .map((entry) => ({ subject, entry }));
    });
    const confirmed = await confirmBulkWikiMediaOperation({
        title: "Importa varianti dal Token Switcher",
        total: candidates.length,
        description: "Importa solo le varianti manuali degli actor configurati. Le varianti gia gestite dalla wiki vengono ignorate."
    });
    if (!confirmed) return false;

    const loaded = await requestNotesApi("api/data/transformations");
    const records = Array.isArray(loaded?.data) ? loaded.data.slice() : [];
    const expectedVersion = loaded?.source === "kv" ? (loaded.version ?? 0) : 0;
    let uploaded = 0;
    let reused = 0;
    let changed = 0;
    let skipped = 0;
    const errors = [];

    for (const { subject, entry } of candidates) {
        try {
            const media = await resolveTokenSwitcherEntryMediaPath(subject, entry);
            if (media.uploaded) uploaded += 1;
            else reused += 1;
            const nextRecord = buildWikiTransformationFromTokenSwitcher(subject, entry, media.path);
            await registerManagedMedia(subject.actor, `transformation:${nextRecord.id}`, {
                remote: media.path,
                local: entry.path,
                entityType: "transformation",
                entityId: nextRecord.id,
                actor: subject.actor,
                name: nextRecord.name || nextRecord.creatureName
            });
            if (mergeTransformationRecordsById(records, nextRecord)) changed += 1;
        } catch (error) {
            skipped += 1;
            errors.push({
                actor: subject.actor?.name,
                path: entry.path,
                error: String(error?.message || error)
            });
        }
    }

    if (changed > 0) {
        records.sort((left, right) =>
            String(left.characterId || "").localeCompare(String(right.characterId || ""), "it")
            || String(left.creatureName || left.name || "").localeCompare(String(right.creatureName || right.name || ""), "it")
        );
        await requestNotesApi("api/data/transformations", {
            method: "POST",
            body: {
                data: records,
                expectedVersion
            }
        });
        transformationOverrideCache.data = [];
        transformationOverrideCache.loadedAt = 0;
    }

    if (errors.length) console.warn(`${MODULE_ID} | Alcune varianti Token Switcher non sono state importate.`, errors);
    if (notify) ui.notifications.info(`Varianti Token Switcher importate. Caricate: ${uploaded}. Riusate: ${reused}. Saltate: ${skipped}.`);
    console.info(`${MODULE_ID} | Varianti Token Switcher importate verso wiki.`, { uploaded, reused, skipped, changed, subjects: subjects.length });
    return changed > 0;
}

async function syncTransformationsToTokenSwitcher({ force = false, notify = false } = {}) {
    if (!game.modules.get(TOKEN_SWITCHER_MODULE_ID)?.active) return false;
    const overrides = await loadWikiTransformationOverrides({ force });
    const switcherEntries = overrides.filter((entry) => entry.switcher);
    if (!switcherEntries.length) return false;

    const byActor = new Map();
    switcherEntries.forEach((entry) => {
        const actor = findActorForTransformation(entry);
        if (!actor) return;
        if (!byActor.has(actor.id)) byActor.set(actor.id, { actor, entries: [] });
        byActor.get(actor.id).entries.push(entry);
    });

    let updated = 0;
    for (const { actor, entries } of byActor.values()) {
        const current = (actor.getFlag(TOKEN_SWITCHER_MODULE_ID, TOKEN_SWITCHER_IMAGES_FLAG) || [])
            .map(normalizeTokenSwitcherEntry)
            .filter((entry) => entry.path);
        const previousManaged = new Set(actor.getFlag(MODULE_ID, TOKEN_SWITCHER_SYNCED_PATHS_FLAG) || []);
        const baseEntry = getTokenSwitcherBaseEntry(actor);
        const managed = baseEntry ? [baseEntry] : [];
        for (const entry of entries) {
            const mapped = await mapTransformationToTokenSwitcherEntry(actor, entry);
            if (mapped?.path) managed.push(mapped);
        }
        const managedPaths = new Set(managed.map((entry) => entry.path));
        const kept = current.filter((entry) => !previousManaged.has(entry.path) && !managedPaths.has(entry.path));
        const next = [...kept, ...managed];
        const currentJson = JSON.stringify(current);
        const nextJson = JSON.stringify(next);
        if (currentJson === nextJson && JSON.stringify(Array.from(previousManaged)) === JSON.stringify(Array.from(managedPaths))) continue;
        await actor.setFlag(TOKEN_SWITCHER_MODULE_ID, TOKEN_SWITCHER_IMAGES_FLAG, next);
        await actor.setFlag(MODULE_ID, TOKEN_SWITCHER_SYNCED_PATHS_FLAG, Array.from(managedPaths));
        updated += 1;
    }

    if (notify && updated) ui.notifications.info(`Varianti Token Switcher sincronizzate (${updated} actor).`);
    if (updated) console.info(`${MODULE_ID} | Varianti Token Switcher sincronizzate.`, { actors: updated });
    return updated > 0;
}

async function applyTransformationTokenOverride(tokenLike, options = {}) {
    const document = getTokenDocument(tokenLike);
    if (!document?.actor || typeof document.update !== "function") return false;

    let overrides;
    try {
        overrides = await loadWikiTransformationOverrides(options);
    } catch (error) {
        console.warn(`${MODULE_ID} | Impossibile leggere override token trasformazioni.`, error);
        return false;
    }

    const match = findTransformationOverrideForToken(tokenLike, overrides);
    if (!match?.tokenImage) return false;
    const remotePath = normalizeManagedRemotePath(match.tokenImage);
    const tokenImage = remotePath
        ? await resolveAndRegisterManagedMedia(document.actor, `transformation:${match.id}`, {
            remote: remotePath,
            entityType: "transformation",
            entityId: match.id,
            actor: document.actor,
            name: match.label || match.creatureName || match.name || "Forma",
            verifyRemote: false,
            assumeRemoteAvailable: true
        })
        : match.tokenImage;
    if (!tokenImage) return false;

    const current = String(document.texture?.src || "").trim();
    const desiredSize = getTransformationTokenSize(match);
    const updateData = {
        [`flags.${MODULE_ID}.transformationOverrideId`]: match.id
    };
    if (current !== tokenImage) updateData["texture.src"] = tokenImage;
    if (desiredSize && Number(document.width) !== desiredSize) updateData.width = desiredSize;
    if (desiredSize && Number(document.height) !== desiredSize) updateData.height = desiredSize;
    if (Object.keys(updateData).length === 1) return false;

    await document.update(updateData);
    console.info(`${MODULE_ID} | Token trasformazione applicato.`, {
        token: document.name,
        actor: document.actor?.name,
        override: match.id,
        image: tokenImage,
        size: desiredSize
    });
    return true;
}

function getTransformationTokenSize(entry) {
    const size = Number(entry?.size);
    if (Number.isFinite(size) && size > 0) return size;
    const width = Number(entry?.width);
    if (Number.isFinite(width) && width > 0) return width;
    const height = Number(entry?.height);
    return Number.isFinite(height) && height > 0 ? height : null;
}

function scheduleTransformationTokenOverride(tokenLike, options = {}) {
    window.setTimeout(() => {
        applyTransformationTokenOverride(tokenLike, options).catch((error) => {
            console.warn(`${MODULE_ID} | Applicazione token trasformazione fallita.`, error);
        });
    }, options.delay ?? 250);
}

function applyTransformationOverridesToScene(options = {}) {
    canvas?.tokens?.placeables?.forEach((token) => scheduleTransformationTokenOverride(token, options));
}

function scheduleTokenSwitcherStartupSync() {
    if (!game.user?.isGM) return;
    if (!game.modules.get(TOKEN_SWITCHER_MODULE_ID)?.active) return;
    window.setTimeout(() => {
        syncTransformationsToTokenSwitcher({ force: true, notify: false }).catch((error) => {
            console.warn(`${MODULE_ID} | Sincronizzazione iniziale Token Switcher fallita.`, error);
        });
    }, 1500);
}

function getCanvasTokenAtClientPoint(event) {
    const view = canvas?.app?.view || canvas?.app?.canvas;
    if (!view || !canvas?.stage || !canvas?.tokens?.placeables?.length) return null;

    const rect = view.getBoundingClientRect();
    const screenPoint = new PIXI.Point(event.clientX - rect.left, event.clientY - rect.top);
    const worldPoint = canvas.stage.worldTransform.applyInverse(screenPoint);
    const tokens = [...canvas.tokens.placeables].reverse().filter(isTokenVisibleForCurrentUser);

    return tokens.find((token) => {
        const bounds = token.bounds;
        if (bounds?.contains?.(worldPoint.x, worldPoint.y)) return true;
        const width = token.w ?? token.width ?? 0;
        const height = token.h ?? token.height ?? 0;
        return worldPoint.x >= token.x
            && worldPoint.x <= token.x + width
            && worldPoint.y >= token.y
            && worldPoint.y <= token.y + height;
    }) || null;
}

function rememberCanvasPointerPosition(event) {
    const view = canvas?.app?.view || canvas?.app?.canvas;
    if (!view) return;
    if (event.target !== view) {
        if (lastCanvasPointerPosition?.target === view) lastCanvasPointerPosition = null;
        return;
    }

    lastCanvasPointerPosition = {
        clientX: event.clientX,
        clientY: event.clientY,
        target: view
    };
}

function isTypingInTextInput() {
    const active = document.activeElement;
    if (!active || active === document.body) return false;
    if (active.isContentEditable) return true;
    if (active.closest?.("[contenteditable='true'], .editor, .tox, .ProseMirror, .CodeMirror")) return true;
    return ["INPUT", "SELECT", "TEXTAREA"].includes(active.tagName);
}

function handleTokenQuickHudKeydown(event) {
    if (event.key === "Escape") {
        hideTokenQuickHud();
        return;
    }

    if (event.key?.toLowerCase?.() !== "n") return;
    if (event.repeat || event.ctrlKey || event.altKey || event.metaKey || isTypingInTextInput()) return;

    const view = canvas?.app?.view || canvas?.app?.canvas;
    if (!view || !lastCanvasPointerPosition || lastCanvasPointerPosition.target !== view) return;

    const token = getCanvasTokenAtClientPoint(lastCanvasPointerPosition);
    if (!token) return;

    event.preventDefault();
    event.stopPropagation();
    showTokenQuickHud(token, event);
}

function registerMidiRiderHooks() {
    console.warn(`${MODULE_ID} | Hook Midi registrati per rider, rigenerazione, undead fortitude e assorbimento.`);
    Hooks.on("midi-qol.RollComplete", (workflow) => {
        queueWikiAbsorptionApplication(workflow, "RollComplete", 1500);
        queueWikiRiderApplication(workflow, "RollComplete", 250);
    });
    Hooks.on("midi-qol.DamageRollComplete", (workflow) => {
        queueWikiAbsorptionApplication(workflow, "DamageRollComplete", 1500);
    });
    Hooks.on("midi-qol.WorkflowComplete", (workflow) => {
        removeAdvancedEffectsBrokenByDamage(workflow).catch((error) => {
            console.warn(`${MODULE_ID} | Rimozione rider wiki su danno fallita.`, error);
        });
        suppressRegenerationFromMidiWorkflow(workflow).catch((error) => {
            console.warn(`${MODULE_ID} | Interruzione rigenerazione wiki fallita.`, error);
        });
        queueWikiAbsorptionApplication(workflow, "WorkflowComplete", 1500);
        applyUndeadFortitudeFromMidiWorkflow(workflow).catch((error) => {
            console.warn(`${MODULE_ID} | Undead Fortitude wiki fallita.`, error);
        });
        queueWikiRiderApplication(workflow, "WorkflowComplete", 0);
    });
    Hooks.on("updateCombat", (combat, changed) => {
        if (!("turn" in changed) && !("round" in changed)) return;
        queueWikiRegeneration(combat);
    });
}

function queueWikiAbsorptionApplication(workflow, source, delayMs = 0) {
    window.setTimeout(() => {
        applyAbsorptionFromMidiWorkflow(workflow, source).catch((error) => {
            console.warn(`${MODULE_ID} | Assorbimento wiki fallito da ${source}.`, error);
        });
    }, delayMs);
}

function queueWikiRiderApplication(workflow, source, delayMs = 0) {
    window.setTimeout(() => {
        applyWikiRidersFromMidiWorkflow(workflow, source).catch((error) => {
            console.warn(`${MODULE_ID} | Applicazione rider wiki fallita (${source}).`, error);
        });
    }, delayMs);
}

async function removeAdvancedEffectsBrokenByDamage(workflow) {
    const damageTypes = extractWorkflowDamageTypes(workflow);
    if (!damageTypes.size) return;
    const actors = getWorkflowDamageActors(workflow);
    for (const actor of actors) {
        const effects = actor.effects.filter((effect) => {
            const type = effect.getFlag?.(MODULE_ID, "endsOnDamageType");
            return type && damageTypes.has(String(type).toLowerCase());
        });
        if (effects.length) await actor.deleteEmbeddedDocuments("ActiveEffect", effects.map((effect) => effect.id));
    }
}

async function suppressRegenerationFromMidiWorkflow(workflow) {
    const events = getWorkflowDamageEvents(workflow);
    if (!events.length) return;
    const workflowDamageTypes = extractWorkflowDamageTypes(workflow);
    for (const event of events) {
        const actor = event.actor;
        if (!actor) continue;
        const passive = getActorWikiPassive(actor, "regeneration");
        if (!passive?.enabled) continue;
        const breakTypes = normalizeWikiDamageTypeList(passive.breakDamageTypes);
        if (!breakTypes.length) continue;
        const damageTypes = new Set([...workflowDamageTypes, ...event.damageTypes]);
        const matched = breakTypes.filter((type) => damageTypes.has(type));
        if (!matched.length) continue;
        await actor.setFlag(MODULE_ID, "regenerationSuppressed", {
            combatId: game.combat?.id || "",
            round: game.combat?.round || 0,
            turn: game.combat?.turn ?? null,
            damageTypes: matched,
            updatedAt: Date.now()
        });
    }
}

function queueWikiRegeneration(combat) {
    if (!game.user?.isGM) return;
    window.setTimeout(() => {
        applyWikiRegenerationAtTurnStart(combat).catch((error) => {
            console.warn(`${MODULE_ID} | Rigenerazione wiki fallita.`, error);
        });
    }, 100);
}

async function applyWikiRegenerationAtTurnStart(combat) {
    const combatant = combat?.combatant;
    const actor = combatant?.actor;
    if (!actor) return;
    const passive = getActorWikiPassive(actor, "regeneration");
    if (!passive?.enabled) return;
    const amount = Math.floor(Number(passive.value) || 0);
    if (amount <= 0) return;
    const key = `${combat.id || "combat"}:${combat.round || 0}:${combat.turn ?? ""}:${actor.uuid || actor.id}`;
    if (regenerationTurnKeys.has(key)) return;
    if (regenerationTurnKeys.size > 200) regenerationTurnKeys.clear();
    regenerationTurnKeys.add(key);

    const suppression = actor.getFlag?.(MODULE_ID, "regenerationSuppressed");
    if (suppression) {
        await actor.unsetFlag(MODULE_ID, "regenerationSuppressed");
        const damageLabels = normalizeWikiDamageTypeList(suppression.damageTypes).map((type) => WIKI_DAMAGE_TYPE_LABELS[type] || type).join(", ");
        await ChatMessage.create({
            speaker: ChatMessage.getSpeaker({ actor }),
            content: `<p><strong>Regeneration.</strong> ${escapeHtml(actor.name)} non rigenera${damageLabels ? ` a causa di: ${escapeHtml(damageLabels)}` : ""}.</p>`
        });
        return;
    }

    const hp = actor.system?.attributes?.hp || {};
    const current = Number(hp.value ?? 0);
    const max = Number(hp.max ?? 0);
    if (!Number.isFinite(current) || !Number.isFinite(max) || current <= 0 || max <= 0 || current >= max) return;
    const next = Math.min(max, current + amount);
    await actor.update({ "system.attributes.hp.value": next });
    await ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor }),
        content: `<p><strong>Regeneration.</strong> ${escapeHtml(actor.name)} recupera ${next - current} PF.</p>`
    });
}

function extractWorkflowDamageTypes(workflow) {
    const values = new Set();
    visitDamageTypeCandidate(workflow?.damageDetail, values);
    visitDamageTypeCandidate(workflow?.damageList, values);
    visitDamageTypeCandidate(workflow?.damageItem, values);
    visitDamageTypeCandidate(workflow?.damageRolls, values);
    visitDamageTypeCandidate(workflow?.item, values);
    visitDamageTypeCandidate(workflow?.activity, values);
    visitDamageTypeCandidate(workflow?.activity?.damage, values);
    return values;
}

function visitDamageTypeCandidate(value, values, depth = 0, seen = new Set()) {
    if (value == null || depth > 6) return;
    if (typeof value === "string") {
        addKnownDamageTypesFromString(value, values);
        return;
    }
    if (typeof value !== "object") return;
    if (seen.has(value)) return;
    seen.add(value);
    if (value instanceof Set || Array.isArray(value)) {
        Array.from(value).forEach((entry) => visitDamageTypeCandidate(entry, values, depth + 1, seen));
        return;
    }
    if (value instanceof Map) {
        Array.from(value.values()).forEach((entry) => visitDamageTypeCandidate(entry, values, depth + 1, seen));
        return;
    }
    ["type", "damageType", "damageTypeId", "damageTypeValue", "value"].forEach((key) => {
        if (typeof value[key] === "string") addKnownDamageTypesFromString(value[key], values);
    });
    ["damage", "damageDetail", "damageDetails", "parts", "rolls", "damages", "system", "activities", "activity", "base", "custom"].forEach((key) => {
        if (value[key] != null) visitDamageTypeCandidate(value[key], values, depth + 1, seen);
    });
}

function addKnownDamageTypesFromString(text, values) {
    const known = ["acid", "bludgeoning", "cold", "fire", "force", "lightning", "necrotic", "piercing", "poison", "psychic", "radiant", "slashing", "thunder"];
    const normalized = String(text).toLowerCase();
    known.forEach((type) => {
        if (normalized === type || normalized.includes(type)) values.add(type);
    });
}

async function applyAbsorptionFromMidiWorkflow(workflow, source = "") {
    if (!workflow || typeof workflow !== "object") {
        console.warn(`${MODULE_ID} | Assorbimento: workflow non valido da ${source}.`, workflow);
        return;
    }
    let events = getWorkflowDamageEvents(workflow);
    if (!events.length) {
        events = getWorkflowDamageActors(workflow).map((actor) => ({
            actor,
            raw: null,
            oldHp: null,
            newHp: null,
            damage: 0,
            damageTypes: new Set(),
            critical: Boolean(workflow?.isCritical || workflow?.criticalHit)
        }));
    }
    const workflowDamageTypes = extractWorkflowDamageTypes(workflow);
    const workflowAmount = getWorkflowTotalDamage(workflow);
    if (!events.length) {
        console.warn(`${MODULE_ID} | Assorbimento: nessun actor danneggiato trovato da ${source}.`, {
            item: workflow?.item?.name || workflow?.damageItem?.name || "",
            damageTypes: Array.from(workflowDamageTypes),
            amount: workflowAmount
        });
        return;
    }
    const appliedKey = `${MODULE_ID}AbsorptionApplied`;
    if (!workflow[appliedKey]) workflow[appliedKey] = new Set();
    for (const event of events) {
        const actor = event.actor;
        if (!actor) continue;
        const actorKey = actor.uuid || actor.id;
        if (workflow[appliedKey].has(actorKey)) continue;
        const absorbedTypes = getActorAbsorptionTypes(actor);
        const damageTypes = new Set([...workflowDamageTypes, ...event.damageTypes]);
        const matched = absorbedTypes.filter((type) => damageTypes.has(type));
        const amount = getWorkflowAbsorbedDamageAmount(workflow, event, matched, damageTypes, workflowAmount);
        console.warn(`${MODULE_ID} | Assorbimento check da ${source}`, {
            actor: actor.name,
            absorbedTypes,
            damageTypes: Array.from(damageTypes),
            matched,
            amount,
            item: workflow?.item?.name || workflow?.damageItem?.name || ""
        });
        if (!absorbedTypes.length) continue;
        if (!matched.length) continue;
        if (!amount || amount <= 0) continue;
        workflow[appliedKey].add(actorKey);
        await convertDamageToHealing(actor, amount, matched, event);
    }
}

function getWorkflowAbsorbedDamageAmount(workflow, event, matchedTypes, damageTypes, workflowAmount) {
    if (!matchedTypes.length) return 0;
    const detailSources = [
        event?.raw,
        workflow?.damageDetail,
        workflow?.damageDetails,
        workflow?.damageItem?.damageDetail,
        workflow?.damageItem?.damageDetails,
        workflow?.damageItem?.damageRolls,
        workflow?.damageRolls,
        workflow?.damageRoll
    ];
    for (const source of detailSources) {
        const directAmount = sumDamageAmountsForTypes(matchedTypes, source);
        if (directAmount > 0) return directAmount;
    }
    const nonAbsorbedTypes = Array.from(damageTypes || []).filter((type) => !matchedTypes.includes(type));
    if (!nonAbsorbedTypes.length) return event.damage > 0 ? event.damage : workflowAmount;
    console.warn(`${MODULE_ID} | Assorbimento: danno misto senza dettaglio per tipo, cura saltata per evitare sovracura.`, {
        matchedTypes,
        damageTypes: Array.from(damageTypes || []),
        workflowAmount
    });
    return 0;
}

function sumDamageAmountsForTypes(types, ...sources) {
    const wanted = new Set(types);
    let total = 0;
    const seen = new Set();
    const visit = (value) => {
        if (value == null) return;
        if (typeof value !== "object") return;
        if (seen.has(value)) return;
        seen.add(value);
        if (value instanceof Set || Array.isArray(value)) {
            Array.from(value).forEach(visit);
            return;
        }
        if (value instanceof Map) {
            Array.from(value.values()).forEach(visit);
            return;
        }
        const nodeTypes = getDirectDamageTypes(value).filter((type) => wanted.has(type));
        const amount = getDirectDamageAmount(value);
        if (nodeTypes.length && amount > 0) {
            total += amount;
            return;
        }
        ["damage", "damageDetail", "damageDetails", "parts", "rolls", "damages", "base", "custom"].forEach((key) => {
            if (value[key] != null) visit(value[key]);
        });
    };
    sources.forEach(visit);
    return total;
}

function getDirectDamageTypes(value) {
    const types = new Set();
    ["type", "damageType", "damageTypeId", "damageTypeValue"].forEach((key) => {
        if (typeof value?.[key] === "string") addKnownDamageTypesFromString(value[key], types);
    });
    if (typeof value?.options?.type === "string") addKnownDamageTypesFromString(value.options.type, types);
    if (typeof value?.options?.damageType === "string") addKnownDamageTypesFromString(value.options.damageType, types);
    return Array.from(types);
}

function getDirectDamageAmount(value) {
    return firstFiniteNumber(value?.damage, value?.total, value?.amount, value?.appliedDamage, value?.hpDamage, 0);
}

async function convertDamageToHealing(actor, amount, damageTypes, damageEvent = {}) {
    const hp = actor.system?.attributes?.hp || {};
    const current = Number(hp.value ?? 0);
    const max = Number(hp.max ?? 0);
    if (!Number.isFinite(current) || !Number.isFinite(max) || max <= 0) return;
    const healing = Math.floor(Number(amount) || 0);
    if (healing <= 0) return;
    const next = Math.min(max, current + healing);
    if (next <= current) return;
    await delayedActorHpUpdate(actor, next, "Assorbimento");
    const labels = damageTypes.map((type) => WIKI_DAMAGE_TYPE_LABELS[type] || type).join(", ");
    await ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor }),
        content: `<p><strong>Assorbimento.</strong> ${escapeHtml(actor.name)} converte ${healing} danni ${escapeHtml(labels)} in cura.</p>`
    });
}

async function delayedActorHpUpdate(actor, hpValue, reason = "") {
    const apply = () => {
        actor.update({ "system.attributes.hp.value": hpValue }).catch((error) => {
            console.warn(`${MODULE_ID} | Update PF fallito (${reason}).`, error);
        });
    };
    await actor.update({ "system.attributes.hp.value": hpValue });
    window.setTimeout(apply, 150);
    window.setTimeout(apply, 450);
}

function getActorAbsorptionTypes(actor) {
    const values = new Set();
    const flagValues = actor.getFlag?.(MODULE_ID, "damageAbsorptions") || actor.flags?.[MODULE_ID]?.damageAbsorptions;
    (Array.isArray(flagValues) ? flagValues : []).forEach((type) => {
        const normalized = String(type || "").trim().toLowerCase();
        if (Object.prototype.hasOwnProperty.call(WIKI_DAMAGE_TYPE_LABELS, normalized)) values.add(normalized);
    });
    const traitValues = actor.system?.traits?.da?.value;
    (Array.isArray(traitValues) ? traitValues : []).forEach((type) => {
        const normalized = String(type || "").trim().toLowerCase();
        if (Object.prototype.hasOwnProperty.call(WIKI_DAMAGE_TYPE_LABELS, normalized)) values.add(normalized);
    });
    actor.items?.forEach?.((item) => {
        const passive = item.getFlag?.(MODULE_ID, "passive") || item.flags?.[MODULE_ID]?.passive;
        if (passive?.enabled && passive.id === "absorption") {
            const normalized = String(passive.value || "").trim().toLowerCase();
            if (Object.prototype.hasOwnProperty.call(WIKI_DAMAGE_TYPE_LABELS, normalized)) values.add(normalized);
        }
    });
    return Array.from(values);
}

async function applyUndeadFortitudeFromMidiWorkflow(workflow) {
    const events = getWorkflowDamageEvents(workflow);
    if (!events.length) return;
    const workflowDamageTypes = extractWorkflowDamageTypes(workflow);
    const appliedKey = `${MODULE_ID}UndeadFortitudeApplied`;
    if (!workflow[appliedKey]) workflow[appliedKey] = new Set();
    for (const event of events) {
        const actor = event.actor;
        if (!actor || workflow[appliedKey].has(actor.uuid || actor.id)) continue;
        if (!actorHasWikiPassive(actor, "undead-fortitude")) continue;
        const hp = Number(actor.system?.attributes?.hp?.value ?? 0);
        if (!Number.isFinite(hp) || hp > 0) continue;
        if (event.damageTypes.has("radiant") || workflowDamageTypes.has("radiant")) continue;
        if (event.critical) continue;

        workflow[appliedKey].add(actor.uuid || actor.id);
        const damage = event.damage > 0 ? event.damage : getWorkflowTotalDamage(workflow);
        const dc = Math.max(5, 5 + Math.floor(Number(damage) || 0));
        const save = await rollUndeadFortitudeSave(actor, dc);
        if (save.total >= dc) {
            await restoreActorToOneHp(actor, "Undead Fortitude");
            await ChatMessage.create({
                speaker: ChatMessage.getSpeaker({ actor }),
                content: `<p><strong>Undead Fortitude.</strong> ${escapeHtml(actor.name)} resta a 1 PF (TS ${save.total} contro CD ${dc}).</p>`
            });
        } else {
            await ChatMessage.create({
                speaker: ChatMessage.getSpeaker({ actor }),
                content: `<p><strong>Undead Fortitude.</strong> ${escapeHtml(actor.name)} fallisce il TS ${save.total} contro CD ${dc}.</p>`
            });
        }
    }
}

async function restoreActorToOneHp(actor, reason = "") {
    const updates = [
        { delay: 0, hp: 1 },
        { delay: 150, hp: 1 },
        { delay: 450, hp: 1 }
    ];
    for (const update of updates) {
        window.setTimeout(() => {
            const current = Number(actor.system?.attributes?.hp?.value ?? 0);
            if (Number.isFinite(current) && current <= 0) {
                actor.update({ "system.attributes.hp.value": update.hp }).catch((error) => {
                    console.warn(`${MODULE_ID} | Ripristino PF fallito (${reason}).`, error);
                });
            }
        }, update.delay);
    }
    await actor.update({ "system.attributes.hp.value": 1 });
}

function getWorkflowDamageEvents(workflow) {
    const events = [];
    const visit = (value) => {
        if (value == null) return;
        if (value instanceof Set || Array.isArray(value)) {
            Array.from(value).forEach(visit);
            return;
        }
        if (value instanceof Map) {
            Array.from(value.values()).forEach(visit);
            return;
        }
        if (typeof value !== "object") return;
        const actor = normalizeWorkflowActor(value) || normalizeWorkflowActor(value.actor) || normalizeWorkflowActor(value.token) || normalizeWorkflowActor(value.target);
        if (!actor) return;
        const damageTypes = new Set();
        visitDamageTypeCandidate(value, damageTypes);
        const oldHp = firstFiniteNumber(value.oldHP, value.oldHp, value.hpOld, value.startingHP, value.startingHp);
        const newHp = firstFiniteNumber(value.newHP, value.newHp, value.hpNew, value.endingHP, value.endingHp);
        const damage = firstFiniteNumber(
            value.appliedDamage,
            value.damageApplied,
            value.hpDamage,
            value.totalDamage,
            value.damage,
            Number.isFinite(oldHp) && Number.isFinite(newHp) ? oldHp - newHp : NaN
        );
        events.push({
            actor,
            raw: value,
            oldHp: Number.isFinite(oldHp) ? oldHp : null,
            newHp: Number.isFinite(newHp) ? newHp : null,
            damage: Number.isFinite(damage) ? Math.max(0, damage) : 0,
            damageTypes,
            critical: Boolean(value.isCritical || value.critical || value.criticalHit || workflow?.isCritical || workflow?.criticalHit)
        });
    };
    visit(workflow?.damageList);
    visit(workflow?.damageItem?.damageList);
    return events;
}

function getWorkflowTotalDamage(workflow) {
    return firstFiniteNumber(workflow?.damageTotal, workflow?.damageItem?.damageTotal, workflow?.damageRoll?.total, workflow?.damageRolls?.[0]?.total, 0);
}

function firstFiniteNumber(...values) {
    for (const value of values) {
        const number = Number(value);
        if (Number.isFinite(number)) return number;
    }
    return NaN;
}

function actorHasWikiPassive(actor, passiveId) {
    return Boolean(getActorWikiPassive(actor, passiveId));
}

function getActorWikiPassive(actor, passiveId) {
    return actor.items?.find?.((item) => {
        const passive = item.getFlag?.(MODULE_ID, "passive") || item.flags?.[MODULE_ID]?.passive;
        return passive?.enabled && passive?.id === passiveId;
    })?.getFlag?.(MODULE_ID, "passive")
        || actor.items?.find?.((item) => {
            const passive = item.flags?.[MODULE_ID]?.passive;
            return passive?.enabled && passive?.id === passiveId;
        })?.flags?.[MODULE_ID]?.passive
        || null;
}

async function rollUndeadFortitudeSave(actor, dc) {
    const flavor = `Undead Fortitude CD ${dc}`;
    try {
        if (typeof actor.rollAbilitySave === "function") {
            const result = await actor.rollAbilitySave("con", { dc, flavor, fastForward: true });
            const total = extractRollTotal(result);
            if (Number.isFinite(total)) return { total };
        }
    } catch (error) {
        console.debug(`${MODULE_ID} | rollAbilitySave non disponibile per Undead Fortitude.`, error);
    }
    const roll = await new Roll("1d20 + @abilities.con.save", actor.getRollData?.() || {}).evaluate({ async: true });
    await roll.toMessage({
        speaker: ChatMessage.getSpeaker({ actor }),
        flavor
    });
    return { total: roll.total };
}

function extractRollTotal(result) {
    if (Number.isFinite(Number(result?.total))) return Number(result.total);
    if (Number.isFinite(Number(result?.roll?.total))) return Number(result.roll.total);
    if (Array.isArray(result?.rolls)) {
        const roll = result.rolls.find((entry) => Number.isFinite(Number(entry?.total)));
        if (roll) return Number(roll.total);
    }
    if (Array.isArray(result)) {
        const roll = result.find((entry) => Number.isFinite(Number(entry?.total || entry?.roll?.total)));
        if (roll) return Number(roll.total || roll.roll.total);
    }
    return NaN;
}

function getWorkflowDamageActors(workflow) {
    return collectWorkflowActors(
        workflow?.hitTargets,
        workflow?.targets,
        workflow?.damageList,
        workflow?.damageItem?.hitTargets,
        workflow?.damageItem?.targets
    );
}

async function applyWikiRidersFromMidiWorkflow(workflow, source = "") {
    const item = workflow?.item;
    const riders = item?.getFlag?.(MODULE_ID, "riders") || item?.flags?.[MODULE_ID]?.riders;
    if (!riders?.enabled) return;

    const targets = getWorkflowHitTargets(workflow);
    if (targets.length && !workflow?.[`${MODULE_ID}HitRidersApplied`]) {
        workflow[`${MODULE_ID}HitRidersApplied`] = true;
        await applyConditionsToTargets(targets, normalizeWikiConditionList(riders.alwaysConditions), item, "hit");
        await applyAdvancedEffectsToTargets(targets, getAdvancedEffectsForTiming(riders, "hit"), item, "hit");
    }

    const failedTargets = getWorkflowFailedSaveTargets(workflow);
    if (failedTargets.length && !workflow?.[`${MODULE_ID}FailedSaveRidersApplied`]) {
        workflow[`${MODULE_ID}FailedSaveRidersApplied`] = true;
        await applyConditionsToTargets(failedTargets, normalizeWikiConditionList(riders.failConditions), item, "failed-save");
        await applyAdvancedEffectsToTargets(failedTargets, getAdvancedEffectsForTiming(riders, "failed-save"), item, "failed-save");
    }
}

function getWorkflowHitTargets(workflow) {
    const candidates = workflow?.hitTargets?.size ? workflow.hitTargets : workflow?.targets;
    return Array.from(candidates || [])
        .map((target) => target?.actor ? target : target?.document?.object)
        .filter((target) => target?.actor);
}

function getWorkflowFailedSaveTargets(workflow) {
    const failed = collectWorkflowTargets(
        workflow?.failedSaves,
        workflow?.failedSaveTargets,
        workflow?.saves?.failed,
        workflow?.saveResults?.failed,
        workflow?.saveResult?.failed
    );
    const succeeded = collectWorkflowTargets(
        workflow?.succeededSaves,
        workflow?.successfulSaves,
        workflow?.saves?.succeeded,
        workflow?.saves?.success,
        workflow?.saveResults?.succeeded,
        workflow?.saveResults?.success,
        workflow?.saveResult?.succeeded,
        workflow?.saveResult?.success
    );
    if (!failed.length) return [];
    if (!succeeded.length) return failed;
    const succeededIds = new Set(succeeded.map(getWorkflowTargetIdentity).filter(Boolean));
    return failed.filter((target) => !succeededIds.has(getWorkflowTargetIdentity(target)));
}

function collectWorkflowTargets(...candidates) {
    const targets = [];
    const seen = new Set();
    const visit = (value) => {
        if (value == null) return;
        const target = normalizeWorkflowTarget(value);
        if (target) {
            const id = getWorkflowTargetIdentity(target);
            if (!seen.has(id)) {
                seen.add(id);
                targets.push(target);
            }
            return;
        }
        if (value instanceof Set || Array.isArray(value)) {
            Array.from(value).forEach(visit);
            return;
        }
        if (value instanceof Map) {
            Array.from(value.values()).forEach(visit);
        }
    };
    candidates.forEach(visit);
    return targets;
}

function normalizeWorkflowTarget(value) {
    if (!value) return null;
    if (value.actor) return value;
    if (value.document?.object?.actor) return value.document.object;
    if (value.object?.actor) return value.object;
    if (value.token?.actor) return value.token;
    if (value.target?.actor) return value.target;
    if (value.target?.document?.object?.actor) return value.target.document.object;
    return null;
}

function getWorkflowTargetIdentity(target) {
    return target?.document?.uuid || target?.uuid || target?.id || target?.actor?.uuid || target?.actor?.id || "";
}

function collectWorkflowActors(...candidates) {
    const actors = [];
    const seen = new Set();
    const visit = (value) => {
        if (value == null) return;
        const actor = normalizeWorkflowActor(value);
        if (actor) {
            const id = actor.uuid || actor.id;
            if (!seen.has(id)) {
                seen.add(id);
                actors.push(actor);
            }
            return;
        }
        if (value instanceof Set || Array.isArray(value)) {
            Array.from(value).forEach(visit);
            return;
        }
        if (value instanceof Map) {
            Array.from(value.values()).forEach(visit);
        }
    };
    candidates.forEach(visit);
    return actors;
}

function normalizeWorkflowActor(value) {
    if (!value) return null;
    if (value.effects && value.createEmbeddedDocuments) return value;
    if (value.actor?.effects) return value.actor;
    if (value.document?.actor?.effects) return value.document.actor;
    if (value.document?.object?.actor?.effects) return value.document.object.actor;
    if (value.object?.actor?.effects) return value.object.actor;
    if (value.token?.actor?.effects) return value.token.actor;
    if (value.target?.actor?.effects) return value.target.actor;
    if (value.target?.document?.object?.actor?.effects) return value.target.document.object.actor;
    return null;
}

async function applyConditionsToTargets(targets, conditions, item, reason) {
    if (!conditions.length) return;
    for (const target of targets) {
        const actor = target.actor;
        for (const condition of conditions) {
            if (hasActorStatus(actor, condition)) continue;
            await actor.toggleStatusEffect(condition, { active: true, overlay: false });
        }
    }
}

function getAdvancedEffectsForTiming(riders, timing) {
    return (Array.isArray(riders?.advancedEffects) ? riders.advancedEffects : []).filter((effect) => (effect.timing || "hit") === timing);
}

async function applyAdvancedEffectsToTargets(targets, effects, item, reason) {
    if (!effects.length) return;
    for (const target of targets) {
        const actor = target.actor;
        const toCreate = [];
        for (const effect of effects) {
            const existing = getRuntimeAdvancedEffect(actor, item, effect);
            if (existing) {
                await ensureRuntimeAdvancedEffectVisible(actor, existing, effect);
                continue;
            }
            toCreate.push(buildRuntimeAdvancedEffect(effect, item, reason));
        }
        if (toCreate.length) await actor.createEmbeddedDocuments("ActiveEffect", toCreate);
        await refreshTokenEffectIcons(target);
    }
}

function hasRuntimeAdvancedEffect(actor, item, effect) {
    return Boolean(getRuntimeAdvancedEffect(actor, item, effect));
}

function getRuntimeAdvancedEffect(actor, item, effect) {
    const key = runtimeAdvancedEffectKey(item, effect);
    return actor.effects.find((activeEffect) => activeEffect.getFlag?.(MODULE_ID, "advancedKey") === key) || null;
}

async function ensureRuntimeAdvancedEffectVisible(actor, effect, sourceEffect = null) {
    const updates = {};
    const img = sourceEffect ? runtimeAdvancedEffectImage(sourceEffect) : "";
    if (img && effect.img !== img) updates.img = img;
    if (effect.getFlag?.("dae", "showIcon") !== true) updates["flags.dae.showIcon"] = true;
    if (!Array.isArray(effect.getFlag?.("dae", "specialDuration"))) updates["flags.dae.specialDuration"] = [];
    if (effect.getFlag?.("core", "overlay") !== false) updates["flags.core.overlay"] = false;
    if (Object.keys(updates).length) await actor.updateEmbeddedDocuments("ActiveEffect", [{ _id: effect.id, ...updates }]);
}

async function refreshTokenEffectIcons(target) {
    const token = target?.document?.object || target;
    try {
        if (typeof token?.drawEffects === "function") await token.drawEffects();
        else token?.renderFlags?.set?.({ refreshEffects: true });
    } catch (error) {
        console.debug(`${MODULE_ID} | Refresh icone effetti token non riuscito.`, error);
    }
}

function runtimeAdvancedEffectKey(item, effect) {
    return `${item?.uuid || item?.id || "item"}:${effect.id || slugify(effect.name)}`;
}

function buildRuntimeAdvancedEffect(effect, item, reason) {
    const isOverTime = effect.kind === "startTurnDamage";
    const changes = (Array.isArray(effect.changes) ? effect.changes : []).map((change) => ({ ...change }));
    if (isOverTime && effect.damage?.formula) {
        changes.push({
            key: "flags.midi-qol.OverTime",
            mode: 0,
            value: `turn=start,damageRoll=${effect.damage.formula},damageType=${effect.damage.type || "cold"},label=${effect.name || "Effetto"}`,
            priority: 20
        });
    }
    return {
        name: effect.name || "Effetto avanzato",
        img: runtimeAdvancedEffectImage(effect),
        origin: item?.uuid || null,
        disabled: false,
        transfer: false,
        description: `Applicato dal modulo ${MODULE_TITLE}: ${reason}.`,
        changes,
        duration: effect.duration || {},
        flags: {
            [MODULE_ID]: {
                runtimeRider: true,
                reason,
                advancedKey: runtimeAdvancedEffectKey(item, effect),
                endsOnDamageType: effect.endsOnDamageType || ""
            },
            dae: {
                specialDuration: [],
                enableCondition: "",
                disableCondition: "",
                disableIncapacitated: false,
                showIcon: true,
                macroRepeat: "none"
            },
            dnd5e: {
                riders: { statuses: [] }
            },
            core: {
                overlay: false
            }
        },
        statuses: [],
        tint: "#ffffff",
        type: "base",
        system: {}
    };
}

function runtimeAdvancedEffectImage(effect) {
    return resolveWikiAssetUrl(effect?.iconImage) || (effect?.kind === "startTurnDamage" ? "icons/magic/water/snowflake-ice-blue.webp" : "icons/svg/aura.svg");
}

function hasActorStatus(actor, condition) {
    return actor.effects.some((effect) => effect.statuses?.has?.(condition) || Array.from(effect.statuses || []).includes(condition));
}

Hooks.once("init", () => {
    registerSettings();
});

Hooks.once("ready", () => {
    const mod = game.modules.get(MODULE_ID);
    if (mod) {
        mod.api = {
            openWikiBrowser,
            openWikiForDocument,
            openWikiItemsImporter,
            openWikiCreaturesImporter,
            loadWikiItemsCatalog,
            loadWikiBestiaryCatalog,
            getWikiMissingItems,
            getWikiMissingCreatures,
            loadWikiTransformationOverrides,
            applyTransformationOverridesToScene,
            syncTransformationsToTokenSwitcher,
            exportActorToWikiBestiary,
            applyAbilityOverridesFromWiki,
            applyItemOverridesFromWiki,
            syncAbilityIconsToWiki,
            syncInventoryItemIconsToWiki,
            syncCharacterImagesToWiki,
            syncUnlockedSkillTreeAbilitiesToFoundry,
            bootstrapManagedMediaFallbacksFromR2,
            ensureManagedRemotePathsActive,
            applyCharacterMediaOverridesFromWiki,
            applyQueuedAssetSyncJobsFromWiki,
            openWikiSyncPanel,
            propagateAuthToken,
            syncCharactersToWorker,
            buildCharacterSyncPayload,
            exportActorToWikiNpc,
            wikiDataService,
            wikiStore
        };
    }

    scheduleTokenSwitcherStartupSync();

    window.addEventListener("message", handleEmbeddedWikiMessage);
    document.addEventListener("click", (event) => {
        if (!event.target.closest?.(".cripta-token-quick-hud")) hideTokenQuickHud();
    });
    document.addEventListener("keydown", handleTokenQuickHudKeydown);
    document.addEventListener("pointermove", rememberCanvasPointerPosition, true);
    registerMidiRiderHooks();
    window.setTimeout(() => {
        seedDefaultAutoLoginCodes();
        promptDeviceLoginIfNeeded().catch(() => {});
        ensureManagedRemotePathsActive().catch((error) => {
            console.warn(`${MODULE_ID} | Attivazione path R2 gestiti fallita.`, error);
        });
        loadWikiSkillTrees()
            .then(rerenderOpenActorSheetsForSkillTreeButtons)
            .catch((error) => {
                console.warn(`${MODULE_ID} | Alberi abilita non caricati.`, error);
            });
        if (game.user?.isGM) {
            syncUnlockedSkillTreeAbilitiesToFoundry({ notify: false }).catch((error) => {
                console.warn(`${MODULE_ID} | Sincronizzazione abilita alberi fallita.`, error);
            });
        }
    }, 500);
});

Hooks.on("getSceneControlButtons", controls => {
    const tokenControls = controls.find(control => control.name === "token");
    if (!tokenControls) return;

    tokenControls.tools.push({
        name: "cripta-wiki-browser",
        title: MODULE_TITLE,
        icon: "fas fa-book-skull",
        button: true,
        onClick: () => openWikiBrowser()
    });

    tokenControls.tools.push({
        name: "cripta-wiki-sync-panel",
        title: "Wiki Sync",
        icon: "fas fa-arrows-rotate",
        button: true,
        visible: game.user?.isGM,
        onClick: () => openWikiSyncPanel()
    });
});

Hooks.on("canvasReady", () => {
    bindCanvasTokenRightClicks();
    applyTransformationOverridesToScene();
});
Hooks.on("refreshToken", (token) => {
    attachTokenQuickHudListener(token);
    scheduleTransformationTokenOverride(token);
});
Hooks.on("createToken", (tokenDocument) => {
    window.setTimeout(bindCanvasTokenRightClicks, 50);
    scheduleTransformationTokenOverride(tokenDocument, { delay: 500 });
});
Hooks.on("updateToken", (tokenDocument) => {
    scheduleTransformationTokenOverride(tokenDocument, { delay: 500 });
});

Hooks.on("updateActor", (actor) => {
    if (suppressCharacterSync) return;
    if (isConfiguredPlayerActor(actor) || isConfiguredCompanionActor(actor)) scheduleCharacterSync("updateActor");
    window.setTimeout(() => {
        canvas?.tokens?.placeables
            ?.filter((token) => token.actor?.id === actor?.id || token.document?.actor?.id === actor?.id)
            .forEach((token) => scheduleTransformationTokenOverride(token));
    }, 500);
});

Hooks.on("createItem", (item) => {
    if (suppressCharacterSync) return;
    if (isConfiguredPlayerActor(item?.actor) || isConfiguredCompanionActor(item?.actor)) scheduleCharacterSync("createItem");
});

Hooks.on("updateItem", (item) => {
    if (suppressCharacterSync) return;
    if (isConfiguredPlayerActor(item?.actor) || isConfiguredCompanionActor(item?.actor)) scheduleCharacterSync("updateItem");
});

Hooks.on("deleteItem", (item) => {
    if (suppressCharacterSync) return;
    if (isConfiguredPlayerActor(item?.actor) || isConfiguredCompanionActor(item?.actor)) scheduleCharacterSync("deleteItem");
});

Hooks.on("getActorSheetHeaderButtons", (sheet, buttons) => {
    addManagedMediaHeaderButton(sheet.actor, buttons);
    addPlayerSkillTreeHeaderButton(sheet.actor, buttons);
    if (game.user?.isGM && sheet.actor?.type === "npc") {
        buttons.unshift({
            label: "Export Bestiary",
            class: "cripta-export-bestiary",
            icon: "fas fa-dragon",
            onclick: () => exportActorToWikiBestiary(sheet.actor)
        });
        buttons.unshift({
            label: "Export NPC",
            class: "cripta-export-npc",
            icon: "fas fa-user-plus",
            onclick: () => exportActorToWikiNpc(sheet.actor)
        });
    }
    buttons.unshift({
        label: "Wiki",
        class: "cripta-open-wiki",
        icon: "fas fa-book-open",
        onclick: () => openWikiForDocument(sheet.actor)
    });
});

Hooks.on("renderActorSheet", (app, html) => {
    injectItemProgressBarsInActorSheet(app, html);
});

Hooks.on("renderActorSheet5eCharacter", (app, html) => {
    injectItemProgressBarsInActorSheet(app, html);
});

Hooks.on("renderActorSheet5eCharacter2", (app, html) => {
    injectItemProgressBarsInActorSheet(app, html);
});

Hooks.on("getItemSheetHeaderButtons", (sheet, buttons) => {
    addManagedMediaHeaderButton(sheet.item, buttons);
    addItemLoadoutRoleHeaderButton(sheet.item, buttons);
    addItemProgressHeaderButton(sheet.item, buttons);
});
