function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        "\"": "&quot;",
        "'": "&#039;"
    })[char]);
}

export function renderEmbeddedBrowserShell({ iframeUrl }) {
    return `
        <div class="cw-iframe-only">
            <iframe class="cw-direct-frame" src="${escapeHtml(iframeUrl)}" title="Cripta Wiki"></iframe>
        </div>
    `;
}

export function renderEmbeddedEntityShell({ match, iframeUrl }) {
    return `
        <div class="cw-iframe-only">
            <iframe class="cw-direct-frame" src="${escapeHtml(iframeUrl)}" title="${escapeHtml(match?.entity?.name || "Scheda Wiki")}"></iframe>
        </div>
    `;
}

export function renderEntityShell({ match, canCreateDraft }) {
    const title = match?.entity?.name || match?.unresolvedName || "Scheda Wiki";
    return `
        <div style="padding: 1rem; color: #e6e0d2; background: #090909; height: 100%; box-sizing: border-box;">
            <h2 style="margin-top: 0;">${escapeHtml(title)}</h2>
            <p>Non e stata trovata una voce wiki collegata a questa entita.</p>
            ${canCreateDraft ? '<button type="button" data-create-draft>Crea bozza wiki</button>' : ''}
        </div>
    `;
}

export function renderLoadErrorShell(error) {
    const message = error?.message || String(error || "Errore sconosciuto");
    return `
        <div style="padding: 1rem; color: #e6e0d2; background: #090909; height: 100%; box-sizing: border-box;">
            <h2 style="margin-top: 0;">Impossibile caricare la wiki</h2>
            <p>${escapeHtml(message)}</p>
        </div>
    `;
}
