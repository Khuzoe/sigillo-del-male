import { MODULE_ID, SETTINGS } from "../constants.js";
import { wikiDataService } from "../services/wiki-data-service.js";
import { renderLoadErrorShell } from "../renderers.js";

export class BaseShadowApp extends Application {
    constructor(options = {}) {
        super(options);
        this.currentIframeUrl = "";
        this._frameMessageHandler = null;
    }

    static get defaultOptions() {
        return foundry.utils.mergeObject(super.defaultOptions, {
            template: `modules/${MODULE_ID}/templates/app-shell.hbs`,
            width: 1200,
            height: 820,
            resizable: true
        });
    }

    async _render(force, options) {
        await super._render(force, options);
        await this.renderShadowRoot();
    }

    withAuthToken(url, token) {
        if (!token) return url;
        try {
            const nextUrl = new URL(url);
            nextUrl.searchParams.set("foundryJwt", token);
            return nextUrl.toString();
        } catch (_) {
            return url;
        }
    }

    _getHeaderButtons() {
        const buttons = super._getHeaderButtons();
        buttons.unshift({
            label: "Ricarica",
            class: "cripta-refresh-frame",
            icon: "fas fa-rotate-right",
            onclick: () => this.refreshEmbeddedFrame()
        });
        return buttons;
    }

    async close(options) {
        this.unbindFrameMessageHandler();
        return super.close(options);
    }

    refreshEmbeddedFrame() {
        const frame = this.getEmbeddedFrame();
        const token = game.settings.get(MODULE_ID, SETTINGS.DISCORD_TOKEN) || "";
        const currentUrl = this.currentIframeUrl || frame?.getAttribute("src") || "";

        if (frame && currentUrl) {
            frame.src = this.withAuthToken(currentUrl, token);
            return;
        }

        this.renderShadowRoot();
    }

    sendAuthToken(token) {
        if (!token) return;
        const frame = this.getEmbeddedFrame();
        frame?.contentWindow?.postMessage({
            type: "cripta-auth-token",
            token
        }, "*");
    }

    getEmbeddedFrame() {
        const host = this.element?.[0]?.querySelector(".cripta-app-host");
        return host?.shadowRoot?.querySelector(".cw-direct-frame") || null;
    }

    async renderShadowRoot() {
        const host = this.element?.[0]?.querySelector(".cripta-app-host");
        if (!host) return;

        const shadow = host.shadowRoot || host.attachShadow({ mode: "open" });
        shadow.innerHTML = "";

        const cssLinks = [
            wikiDataService.getCssUrl(),
            `modules/${MODULE_ID}/styles/module-content.css`,
            "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css",
            "https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&family=Crimson+Text:ital,wght@0,400;0,600;1,400&family=Montserrat:wght@400;600&display=swap"
        ];

        cssLinks.forEach(href => {
            const link = document.createElement("link");
            link.rel = "stylesheet";
            link.href = href;
            shadow.appendChild(link);
        });

        const container = document.createElement("div");
        container.className = "cripta-shadow-root";
        shadow.appendChild(container);

        try {
            container.innerHTML = await this.buildHtml();
            await this.activateShadowListeners(shadow, container);
            this.bindFrameMessageHandler();
        } catch (error) {
            console.error(`${MODULE_ID} render error`, error);
            container.innerHTML = renderLoadErrorShell(error);
        }
    }

    bindFrameMessageHandler() {
        this.unbindFrameMessageHandler();
        const frame = this.getEmbeddedFrame();
        if (!frame?.contentWindow) return;

        this._frameMessageHandler = (event) => {
            if (event.source !== frame.contentWindow) return;
            const data = event.data || {};
            if (data.type !== "cripta-spa-navigate" || !data.url) return;
            this.currentIframeUrl = String(data.url);
        };
        window.addEventListener("message", this._frameMessageHandler);
    }

    unbindFrameMessageHandler() {
        if (!this._frameMessageHandler) return;
        window.removeEventListener("message", this._frameMessageHandler);
        this._frameMessageHandler = null;
    }

    async buildHtml() {
        return "";
    }

    async activateShadowListeners(_shadow, _container) {}
}
