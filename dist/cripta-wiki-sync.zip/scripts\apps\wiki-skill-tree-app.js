import { MODULE_ID, SETTINGS } from "../constants.js";
import { BaseShadowApp } from "./base-shadow-app.js";
import { renderEmbeddedBrowserShell } from "../renderers.js";
import { wikiDataService } from "../services/wiki-data-service.js";

export class CriptaWikiSkillTreeApp extends BaseShadowApp {
    constructor(options = {}) {
        super({
            ...options,
            title: options.title || "Albero Abilita"
        });
        this.characterId = options.characterId || "";
    }

    static get defaultOptions() {
        return foundry.utils.mergeObject(super.defaultOptions, {
            id: "cripta-wiki-skill-tree",
            title: "Albero Abilita",
            classes: ["cripta-wiki-skill-tree", "cripta-iframe-window"],
            width: 1320,
            height: 900
        });
    }

    getSkillTreeUrl() {
        const baseUrl = wikiDataService.getBaseUrl();
        const url = new URL(`${baseUrl}/pages/characters/character.html`);
        url.searchParams.set("id", this.characterId);
        url.searchParams.set("type", "player");
        url.searchParams.set("view", "skill-tree");
        url.searchParams.set("skillTreeOnly", "1");
        url.searchParams.set("embed", "1");
        url.searchParams.set("_", String(Date.now()));
        return wikiDataService.withCampaignSiteUrl(url.toString());
    }

    async buildHtml() {
        const token = game.settings.get(MODULE_ID, SETTINGS.DISCORD_TOKEN) || "";
        return renderEmbeddedBrowserShell({
            iframeUrl: this.withAuthToken(this.getSkillTreeUrl(), token)
        });
    }
}
