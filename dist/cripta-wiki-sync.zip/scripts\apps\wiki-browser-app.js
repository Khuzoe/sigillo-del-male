import { MODULE_ID, SECTIONS, SETTINGS } from "../constants.js";
import { BaseShadowApp } from "./base-shadow-app.js";
import { renderEmbeddedBrowserShell } from "../renderers.js";
import { wikiDataService } from "../services/wiki-data-service.js";

export class CriptaWikiBrowserApp extends BaseShadowApp {
    constructor(options = {}) {
        super(options);
        this.activeSection = options.section || SECTIONS.HOME;
    }

    static get defaultOptions() {
        return foundry.utils.mergeObject(super.defaultOptions, {
            id: "cripta-wiki-browser",
            title: "Cripta Wiki Sync",
            classes: ["cripta-wiki-shell", "cripta-iframe-window"],
            width: 1500,
            height: 940
        });
    }

    async buildHtml() {
        const token = game.settings.get(MODULE_ID, SETTINGS.DISCORD_TOKEN) || "";
        return renderEmbeddedBrowserShell({
            iframeUrl: this.withAuthToken(wikiDataService.getWikiPageUrl(this.activeSection), token)
        });
    }

    async activateShadowListeners(_shadow, _container) {}
}
